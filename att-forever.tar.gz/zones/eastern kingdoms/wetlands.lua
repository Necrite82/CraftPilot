---------------------------------------------------
--          Z O N E S        M O D U L E         --
---------------------------------------------------

maproot(MAP.EASTERN_KINGDOMS, MAP.WETLANDS, {
	lore = "The Wetlands is a large, wet zone below Stonewrought Dam and north of Loch Modan, covered with small rivers, lakes, and ponds. Bordered on three sides by mountains, the Wetlands are open to the ocean to the west. Adventurers seeking a route to the Wetlands must either come through sieged Dun Algaz from Loch Modan or cross the damaged Thandol Span from Arathi Highlands. The northern slopes of Wetlands are generally classed within mountains of Khaz Modan.\n\nThe Wetlands is a vast, cold swamp. Mists cloak the ground, and the overcast sky makes the land a uniform gray. Many Ironforge strongholds once stood in this region, but war has reduced them to rubble. Wild creatures, murlocs and renegade orcs now control the land. Menethil Harbor, a city on the west coast, is the Alliance's only presence in this dreary region.",
	icon = 236853,
	groups = {
		n(ACHIEVEMENTS, {
			ach(841),	-- Explore Wetlands
		}),
		explorationHeader({
			exploration(1036),	-- Angerfang Encampment
			exploration(1018),	-- Black Channel Marsh
			exploration(1022),	-- Bluegill Marsh
			exploration(1016),	-- Direforge Hill
			exploration(1038),	-- Dragonmaw Gates
			exploration(836),	-- Dun Algaz
			exploration(205),	-- Dun Modr
			exploration(1037),	-- Grim Batol
			exploration(309),	-- Ironbeard's Tomb
			exploration(150),	-- Menethil Harbor
			exploration(1020),	-- Mosshide Fen
			exploration(1017),	-- Raptor Ridge
			exploration(1023),	-- Saltspray Glen
			exploration(1024),	-- Sundown Marsh
			visit_exploration(5304, {coord={26.3, 25.9, MAP.WETLANDS}}),	-- Swiftgear Station
			exploration(1025),	-- The Green Belt
			exploration(1021),	-- Thelgen Rock
			exploration(118),	-- Whelgar's Excavation Site
		}),
		n(FLIGHT_PATHS, {
			fp(7, {	-- Menethil Harbor, Wetlands
				cr = 1571,	-- Shellei Brondir <Gryphon Master>
				coord = { 9.6, 59.6, MAP.WETLANDS },
				races = ALLIANCE_ONLY,
			}),
		}),
		lockpicking({
			o(179488, {	-- Battered Footlocker
				coords = {
					{ 13.7, 41.6, MAP.WETLANDS },
					{ 16.5, 30.8, MAP.WETLANDS },
					{ 18.4, 39.5, MAP.WETLANDS },
				},
				requireSkill = LOCKPICKING,
				learnedAt = 110,
			}),
		}),
		n(PROFESSIONS, {
			prof(FIRST_AID, {
				n(3181, {	-- Fremal Doohickey <First Aid Trainer>
					coord = { 10.8, 61.2, MAP.WETLANDS },
					races = ALLIANCE_ONLY,
					sym = {
						SymSelector.select("FIRST_AID_APPRENTICE"),
						SymSelector.select("FIRST_AID_JOURNEYMAN"),
						SymSelector.select("FIRST_AID_EXPERT"),
						{"pop"},
					},
				}),
			}),
			prof(FISHING, {
				o(180662),	-- Schooner Wreckage
				n(3179, {	-- Harold Riggs <Fishing Trainer>
					coord = { 8.0, 58.4, MAP.WETLANDS },
					races = ALLIANCE_ONLY,
					sym = {
						SymSelector.select("FISHING_APPRENTICE"),
						SymSelector.select("FISHING_JOURNEYMAN"),
						{"pop"},
					},
				}),
			}),
			prof(HERBALISM, {
				n(1458, {	-- Telurinon Moonshadow <Herbalism Trainer>
					coord = { 8.0, 55.8, MAP.WETLANDS },
					races = ALLIANCE_ONLY,
					sym = {
						SymSelector.select("HERBALISM_APPRENTICE"),
						SymSelector.select("HERBALISM_JOURNEYMAN"),
						SymSelector.select("HERBALISM_EXPERT"),
						SymSelector.select("HERBALISM_ARTISAN"),
						{"pop"},
					},
				}),
			}),
			prof(MINING, {
				i(3340, {	-- Incendicite Ore
					provider = { "o", 1610 },	-- Incendicite Mineral Vein
				}),
			}),
			prof(SKINNING, {
				i(7287, {	-- Red Whelp Scale
					coord = { 62.1, 47.5, MAP.WETLANDS },	-- Greenwarden's Grove, southeast of it's future location.
					crs = {
						1069,	-- Crimson Whelp
						1044,	-- Flamesnorting Whelp
					},
				}),
			}),
		}),
		n(QUESTS, {
			q(98190, {	-- A Friend of the Family (1/2)
				sourceQuest = 98189,	-- Return the Statuette (2/2)
				qg = 2104,	-- Captain Stoutfist
				qi = 279595,	-- Menethil Statuette
				coord = { 9.8, 57.4, MAP.WETLANDS },
				timeline = { TIMELINE.ADDED_1_60_1 },
				maps = { MAP.STORMWIND_CITY },
				races = ALLIANCE_ONLY,
				lvl = 20,
			}),
			q(98191, {	-- A Friend of the Family (2/2)
				sourceQuest = 98190,	-- A Friend of the Family (1/2)
				qg = 1748,	-- Highlord Bolvar Fordragon
				qi = 279598,	-- Menethil Statuette (PQI!)
				coord = { 80.0, 38.6, MAP.STORMWIND_CITY },
				timeline = { TIMELINE.ADDED_1_60_1 },
				races = ALLIANCE_ONLY,
				lvl = 20,
				groups = {
					i(281296),	-- Knight's Lance
					i(281297),	-- Royal Dagger
				},
			}),
			q(304, {	-- A Grim Task
				qg = 1071,	-- Longbraid the Grim
				coord = { 49.8, 18.3, MAP.WETLANDS },
				races = ALLIANCE_ONLY,
				lvl = 26,
				groups = {
					objective(1, {	-- 0/1 Ear of Balgaras
						provider = { "i", 3639 },	-- Ear of Balgaras
						cr = 1364,	-- Balgaras the Foul
						coords = {
							{ 47.4, 15.0, MAP.WETLANDS },
							{ 46.6, 18.6, MAP.WETLANDS },
							{ 61.8, 31.0, MAP.WETLANDS },
						},
					}),
					i(2916),	-- Gold Lion Shield
					i(2917),	-- Tranquil Ring
					i(270050, {	-- Fury Ring
						timeline = { TIMELINE.ADDED_1_60_1 },
					}),
				},
			}),
			q(98459, {	-- A Lack of Virtue
				qg = 254078,	-- Tom "Half-fish" Wilson
				coord = { 50.53, 70.01, MAP.HILLSBRAD_FOOTHILLS },
				races = ALLIANCE_ONLY,
				lvl = 18,
				timeline = { TIMELINE.ADDED_1_60_1 },
				qi = 281240,	-- Tom's Gift (QI!)
			}),
			q(88757, {	-- Accessories of the Lost
				sourceQuest = 87318,	-- Hearts of the Lost
				qg = 271322,	-- Essene Villard
				coord = { 51.4, 9.0, MAP.WETLANDS },
				timeline = { TIMELINE.CREATED_1_60_1 },
				races = ALLIANCE_ONLY,
				lvl = 28,
				groups = {
					objective(1, {	-- 0/1 Essene's Necklace
						providers = {
							{ "i", 284705 },	-- Essene's Necklace
							{ "o", 687845 },	-- Essene's Necklace
						},
						coord = { 51.4, 8.2, MAP.WETLANDS },
					}),
					objective(2, {	-- 0/1 Essene's Spellbook
						providers = {
							{ "i", 284150 },	-- Essene's Spellbook
							{ "o", 678590 },	-- Essene's Spellbook
						},
						coord = { 50.8, 8.1, MAP.WETLANDS },
					}),
					objective(3, {	-- 0/1 Essene's Waterskin
						providers = {
							{ "i", 284146 },	-- Essene's Waterskin
							{ "o", 678585 },	-- Essene's Waterskin
						},
						coord = { 51.1, 8.1, MAP.WETLANDS },
					}),
				},
			}),
			q(96449, {	-- Aeonas's Secret Refuge
				qg = 3179,	-- Harold Riggs
				coord = { 8.0, 58.4, MAP.WETLANDS },
				timeline = { TIMELINE.ADDED_1_60_1 },
				classes = { PALADIN },
				races = ALLIANCE_PALADINS,
				lvl = 35,
				groups = {
					objective(1),	-- 0/1 Ride the Old Dinghy
				},
			}),
			q(98282, {	-- Alchemical Hazards
				qg = 1480,	-- Caitlin Grassman
				coord = { 11.9, 58.8, MAP.WETLANDS },
				timeline = { TIMELINE.ADDED_1_60_1 },
				races = ALLIANCE_ONLY,
				lvl = 20,
				sym = {{ "select", "itemID", 6453 }},	-- x5 Strong Anti-Venom
				groups = {
					objective(1, {	-- 0/1 Unruptured Stalker Gland
						provider = { "i", 280319 },	-- Unruptured Stalker Gland
						crs = { 1111, 4040 },	-- Leech Stalker, Cave Stalker
						coords = {
							{ 52.7, 63.0, MAP.WETLANDS },	-- Leech Stalker
							{ 48.5, 60.3, MAP.WETLANDS },	-- Cave Stalker
						},
					}),
				},
			}),
			q(471, {	-- Apprentice's Duties
				sourceQuest = 484,	-- Young Crocolisk Skins
				qg = 2094,	-- James Halloran
				coord = { 8.5, 55.7, MAP.WETLANDS },
				races = ALLIANCE_ONLY,
				lvl = 18,
				groups = {
					objective(1, {	-- 0/6 Giant Crocolisk Skin
						provider = { "i", 3348 },	-- Giant Crocolisk Skin
						cr = 2089,	-- Giant Wetlands Crocolisk
					}),
					i(2545),	-- Malleable Chain Leggings
					i(3561),	-- Resilient Poncho
					i(3681),	-- Recipe: Crocolisk Gumbo (RECIPE!)
				},
			}),
			q(275, {	-- Blisters on The Land
				sourceQuest = 277,	-- Fire Taboo
				qg = 1244,	-- Rethiel the Greenwarden
				coord = { 56.3, 40.4, MAP.WETLANDS },
				races = ALLIANCE_ONLY,
				lvl = 20,
				groups = {
					objective(1, {	-- 0/12 Fen Creeper slain
						provider = { "n", 1040 },	-- Fen Creeper
					}),
					i(3558),	-- Fen Keeper Robe
					i(1273),	-- Forest Chain
					i(2263),	-- Phytoblade
				},
			}),
			q(98208, {	-- Bloom of the Heavens (1/2)
				qg = 270844,	-- Sylessa Duskwhisper
				coord = { 8.0, 55.9, MAP.WETLANDS },
				timeline = { TIMELINE.ADDED_1_60_1 },
				races = ALLIANCE_ONLY,
				lvl = 22,
				groups = {
					objective(1, {	-- Nord'el
						providers = {
							{ "i", 279915 },	-- Nord'el
							{ "o", 670962 },	-- Nord'el
						},
						coord = { 12.2, 63.8, MAP.WETLANDS },
					}),
					i(281318),	-- Bouquet of Auberdine Flowers
				},
			}),
			q(98209, {	-- Bloom of the Heavens (2/2)
				sourceQuest = 98208,	-- Bloom of the Heavens (1/2)
				qg = 270844,	-- Sylessa Duskwhisper
				qi = 279924,	-- Nord'el
				coord = { 8.0, 55.9, MAP.WETLANDS },
				timeline = { TIMELINE.ADDED_1_60_1 },
				maps = { MAP.DARKSHORE },
				races = ALLIANCE_ONLY,
				lvl = 22,
			}),
			q(88756, {	-- Bring Back a Bang
				qg = 1073,	-- Ashlan Stonesmirk
				coord = { 50.0, 18.2, MAP.WETLANDS },
				timeline = { TIMELINE.ADDED_1_60_1 },
				races = ALLIANCE_ONLY,
				lvl = 27,
				sym = {{ "select", "itemID", 6714 }},	-- Ez-Thro Dynamite
				groups = {
					objective(1, {	-- 0/3 Stolen Explosives
						providers = {
							{ "i", 280806 },	-- Stolen Explosives
							{ "o", 673206 },	-- Stolen Explosives
						},
						coord = { 62.5, 28.2, MAP.WETLANDS },
					}),
				},
			}),
			q(94497, {	-- Call of Water
				sourceQuests = { 94495 },	-- Call of Water
				qg = 258203,	-- Hervdana Saegrund
				coord = { 65.73, 76.43, MAP.WETLANDS },
				races = ALLIANCE_SHAMANS,
				classes = { SHAMAN },
				lvl = 20,
				timeline = { TIMELINE.ADDED_1_60_1 },
				qi = 265732,	-- Unfilled Brown Waterskin (QI!)
				groups = {
					objective(1, {	-- Full Brown Waterskin
						provider = { "i", 265734 },	-- Full Brown Waterskin (QI!)
					}),
				},
			}),
			q(94499, {	-- Call of Water
				sourceQuests = { 94497 },	-- Call of Water
				qg = 258203,	-- Hervdana Saegrund
				coord = { 65.73, 76.43, MAP.WETLANDS },
				races = ALLIANCE_SHAMANS,
				classes = { SHAMAN },
				lvl = 20,
				timeline = { TIMELINE.ADDED_1_60_1 },
				qi = 265747,	-- Unfilled Red Waterskin (QI!)
				groups = {
					objective(1, {	-- Full Red Waterskin
						provider = { "i", 265748 },	-- Full Red Waterskin (QI!)
					}),
				},
			}),
			q(94500, {	-- Call of Water
				sourceQuests = { 94499 },	-- Call of Water
				qg = 258203,	-- Hervdana Saegrund
				coord = { 65.73, 76.43, MAP.WETLANDS },
				races = ALLIANCE_SHAMANS,
				classes = { SHAMAN },
				lvl = 20,
				timeline = { TIMELINE.ADDED_1_60_1 },
				qi = 265772,	-- Unfilled Blue Waterskin (QI!)
				groups = {
					objective(1, {	-- Full Blue Waterskin
						provider = { "i", 265773 },	-- Full Blue Waterskin (QI!)
					}),
				},
			}),
			q(94501, {	-- Call of Water
				sourceQuests = { 94500 },	-- Call of Water
				qg = 258203,	-- Hervdana Saegrund
				coord = { 65.73, 76.43, MAP.WETLANDS },
				races = ALLIANCE_SHAMANS,
				classes = { SHAMAN },
				lvl = 20,
				timeline = { TIMELINE.ADDED_1_60_1 },
				qi = 7810,	-- Vial of Purest Water (QI!)
				groups = { i(6637) },	-- Water Sapta (QI!)
			}),
			q(98283, {	-- Carnage
				sourceQuest = 275,	-- Blisters on The Land
				qg = 1244,	-- Rethiel the Greenwarden
				coord = { 56.2, 40.4, MAP.WETLANDS },
				timeline = { TIMELINE.ADDED_1_60_1 },
				races = ALLIANCE_ONLY,
				lvl = 22,
				groups = {
					objective(1, {	-- 0/1 Malignant Rotclaw Flesh
						provider = { "i", 280331 },	-- Malignant Rotclaw Flesh
						cr = 271334,	-- Maddened Rotclaw
						coord = { 56.6, 43.8, MAP.WETLANDS },
					}),
					objective(2, {	-- 0/1 Carnage's Head
						provider = { "i", 280330 },	-- Carnage's Head
						cr = 271336,	-- Carnage
						coord = { 69.0, 28.8, MAP.WETLANDS },
					}),
					i(281310),	-- Carnage Trousers
					i(281309),	-- Razormaw Shorts
				},
			}),
			q(279, {	-- Claws from the Deep
				qg = 1242,	-- Karl Boran
				coord = { 8.3, 58.5, MAP.WETLANDS },
				races = ALLIANCE_ONLY,
				lvl = 20,
				groups = {
					objective(1, {	-- 0/12 Bluegill Murloc slain
						provider = { "n", 1024 },	-- Bluegill Murloc
					}),
					objective(2, {	-- 0/1 Gobbler's Head
						provider = { "i", 3618 },	-- Gobbler's Head
						coord = { 17.4, 40.4, MAP.WETLANDS },
						cr = 1259,	-- Gobbler
					}),
				},
			}),
			q(293, {	-- Cleansing the Eye
				sourceQuest = 292,	-- The Eye of Paleth
				qg = 1217,	-- Glorin Steelbrow
				coord = { 10.6, 60.5, MAP.WETLANDS },
				maps = { MAP.STORMWIND_CITY },
				races = ALLIANCE_ONLY,
				lvl = 22,
				groups = {
					i(2943),	-- Eye of Paleth
				},
			}),
			q(98240, {	-- Crimson Crate Delivery
				sourceQuests = { 98072 },	-- Crocs of the Sky
				qg = 2094,	-- James Halloran
				coord = { 8.6, 55.6, MAP.WETLANDS },
				timeline = { TIMELINE.ADDED_1_60_1 },
				races = ALLIANCE_ONLY,
				isBreadcrumb = true,
				lockCriteria = { 1, "questID", 98245 },	-- Razormaw Needling
				lvl = 19,
				qi = 280099,	-- Crimson Crate (QI!)
			}),
			q(98072, {	-- Crocs of the Sky
				sourceQuest = 471,	-- Apprentice's Duties
				qg = 2094,	-- James Halloran
				coord = { 8.5, 55.7, MAP.WETLANDS },
				timeline = { TIMELINE.ADDED_1_60_1 },
				races = ALLIANCE_ONLY,
				lvl = 19,
				groups = {
					objective(1, {	-- 0/8 Pristine Crimson Scale
						provider = { "i", 279385 },	-- Pristine Crimson Scale
						coords = {
							{ 61.8, 31.2, MAP.WETLANDS },
							{ 65.4, 43.0, MAP.WETLANDS },
							{ 68.8, 45.6, MAP.WETLANDS },
						},
						crs = {
							1044,	-- Flamesnorting Whelp
							1043,	-- Lost Whelp
							1069,	-- Crimson Whelp
							1042,	-- Red Whelp
						},
					}),
				},
			}),
			q(469, {	-- Daily Delivery
				qg = 2093,	-- Einar Stonegrip
				qi = 3347,	-- Bundle of Crocolisk Skins
				coord = { 49.8, 39.4, MAP.WETLANDS },
				races = ALLIANCE_ONLY,
				isBreadcrumb = true,
				lvl = 18,
			}),
			q(98291, {	-- Death to the Dragonmaw
				qg = 270637,	-- Howin Kindfeather
				coord = { 49.3, 42.1, MAP.WETLANDS },
				timeline = { TIMELINE.ADDED_1_60_1 },
				races = ALLIANCE_ONLY,
				lvl = 22,
				groups = {
					objective(1, {	-- 0/8 Dragonmaw Reclaimer slain
						provider = { "n", 271351 },	-- Dragonmaw Reclaimer
						coord = { 59.7, 44.9, MAP.WETLANDS },
					}),
					objective(2, {	-- 0/5 Dragonmaw Soulbinder slain
						provider = { "n", 271348 },	-- Dragonmaw Soulbinder
						coord = { 62.1, 43.8, MAP.WETLANDS },
					}),
					objective(3, {	-- 0/3 Dragonmaw Infiltrator slain
						provider = { "n", 271346 },	-- Dragonmaw Infiltrator
						coord = { 58.7, 47.3, MAP.WETLANDS },
					}),
				},
			}),
			q(474, {	-- Defeat Nek'rosh
				sourceQuest = 465,	-- Nek'rosh's Gambit
				provider = { "o", 1609 },	-- Dragonmaw Catapult
				coord = { 47.5, 46.9, MAP.WETLANDS },
				races = ALLIANCE_ONLY,
				lvl = 23,
				groups = {
					objective(1, {	-- 0/1 Nek'rosh's Head
						provider = { "i", 3625 },	-- Nek'rosh's Head
						coord = { 54.2, 54.2, MAP.WETLANDS },
						cr = 2091,	-- Chieftain Nek'rosh
					}),
					i(3209),	-- Ancient War Sword
					i(6194),	-- Barreling Reaper
					i(287067, {	-- Dragonmaw Skinflayer
						timeline = { TIMELINE.ADDED_1_60_1 },
					}),
				},
			}),
			q(470, {	-- Digging Through the Ooze
				qg = 2111,	-- Sida
				coord = { 11.8, 58.0, MAP.WETLANDS },
				races = ALLIANCE_ONLY,
				lvl = 19,
				groups = {
					objective(1, {	-- 0/1 Sida's Bag
						provider = { "i", 3349 },	-- Sida's Bag
						crs = {
							1032,	-- Black Ooze
							1031,	-- Crimson Ooze
							1033,	-- Monstrous Ooze
						},
					}),
					i(3352),	-- Ooze-covered Bag
				},
			}),
			q(472, {	-- Fall of Dun Modr
				qg = 2097,	-- Harlo Barnaby
				coord = { 10.8, 55.9, MAP.WETLANDS },
				lockCriteria = { 1, "questID", 304 },	-- A Grim Task
				races = ALLIANCE_ONLY,
				isBreadcrumb = true,
				lvl = 25,
			}),
			q(277, {	-- Fire Taboo
				sourceQuest = 276,	-- Tramping Paws
				qg = 1244,	-- Rethiel the Greenwarden
				coord = { 56.3, 40.4, MAP.WETLANDS },
				races = ALLIANCE_ONLY,
				lvl = 20,
				groups = {
					objective(1, {	-- 0/9 Crude Flint
						provider = { "i", 2611 },	-- Crude Flint
						crs = {
							14425,	-- Gnawbone
							1014,	-- Mosshide Alpha
							1012,	-- Mosshide Brute
							1010,	-- Mosshide Fenrunner
							1009,	-- Mosshide Mistweaver
							1013,	-- Mosshide Mystic
							1011,	-- Mosshide Trapper
						},
					}),
				},
			}),
			q(98313, {	-- For Further Study
				sourceQuest = 98310,	-- Gleaning Our Future
				qg = 1077,	-- Prospector Whelgar
				qi = 280403,	-- Whelgar Relic Package (PQI!)
				coord = { 38.8, 52.2, MAP.WETLANDS },
				timeline = { TIMELINE.ADDED_1_60_1 },
				maps = { MAP.IRONFORGE },
				races = ALLIANCE_ONLY,
				lvl = 24,
			}),
			q(98293, {	-- Forced Disarmament
				provider = { "o", 672330 },	-- Dragonmaw Armaments
				coord = { 58.8, 45.1, MAP.WETLANDS },
				timeline = { TIMELINE.ADDED_1_60_1 },
				races = ALLIANCE_ONLY,
				lvl = 22,
				groups = {
					objective(1, {	-- 0/30 Dragonmaw Armaments
						providers = {
							{ "i", 280369 },	-- Dragonmaw Armaments
							{ "o", 672336 },	-- Dragonmaw Armaments
							{ "o", 672334 },	-- Dragonmaw Armaments
							{ "o", 672337 },	-- Dragonmaw Armaments
						},
						coord = { 64.8, 46.2, MAP.WETLANDS },
					}),
				},
			}),
			q(98221, {	-- From the Ashes
				qg = 2104,	-- Captain Stoutfist
				coord = { 9.9, 57.4, MAP.WETLANDS },
				timeline = { TIMELINE.ADDED_1_60_1 },
				races = ALLIANCE_ONLY,
				lvl = 23,
				groups = {
					objective(1, {	-- Attack Plan: Menethil Harbor destroyed
						provider = { "o", 671481 },
						coord = { 45.4, 42.7, MAP.WETLANDS },
					}),
					objective(2, {	-- Attack Plan: Thelsamar destroyed
						provider = { "o", 671486 },
						coord = { 49.3, 46.8, MAP.WETLANDS },
					}),
					objective(3, {	-- Attack Plan: Southshore destroyed
						provider = { "o", 671483 },
						coord = { 45.3, 45.6, MAP.WETLANDS },
					}),
					objective(4, {	-- Attack Plan: Ironforge destroyed
						provider = { "o", 671487 },
						coord = { 38.6, 46.2, MAP.WETLANDS },
					}),
				},
			}),
			q(98310, {	-- Gleaning Our Future
				sourceQuest = 98216,	-- Understanding Our Present
				qg = 1077,	-- Prospector Whelgar
				qi = 280394,	-- Goaz Stone (PQI!)
				coord = { 38.8, 52.2, MAP.WETLANDS },
				timeline = { TIMELINE.ADDED_1_60_1 },
				races = ALLIANCE_ONLY,
				lvl = 24,
				groups = {
					objective(1, {	-- 0/1 Heart of Ados
						provider = { "i", 280395 },	-- Heart of Ados
						coord = { 77.2, 47.4, MAP.WETLANDS },
						cr = 271338,	-- Ados
					}),
					objective(2, {	-- 0/1 Heart of Modr
						provider = { "i", 280396 },	-- Heart of Modr
						coord = { 51.6, 17.2, MAP.WETLANDS },
						cr = 271460,	-- Modr
					}),
					objective(3, {	-- 0/1 Heart of Golm
						provider = { "i", 280397 },	-- Heart of Golm
						coord = { 67.6, 71.8, MAP.WETLANDS },
						cr = 271462,	-- Golm
					}),
					objective(4, {	-- 0/1 Heart of Neru
						provider = { "i", 280398 },	-- Heart of Neru
						coord = { 60.9, 21.7, MAP.WETLANDS },
						cr = 271458,	-- Neru
					}),
					i(281319),	-- Golem War Cloak
					i(281320),	-- Rune-Etched Ring
					i(281321),	-- Giantstone Medallion
				},
			}),
			q(87318, {	-- Hearts of the Lost
				qg = 5683,	-- Corma Villard
				coord = { 49.4, 11.4, MAP.WETLANDS },
				timeline = { TIMELINE.CREATED_1_60_1 },
				races = ALLIANCE_ONLY,
				lvl = 28,
			}),
			q(305, {	-- In Search of The Excavation Team (1/2)
				sourceQuest = 98461,	-- Unrequited Love
				qg = 2096,	-- Tarrel Rockweaver
				coord = { 11.5, 52.2, MAP.WETLANDS },
				races = ALLIANCE_ONLY,
				lvl = 21,
			}),
			q(306, {	-- In Search of The Excavation Team (2/2)
				sourceQuest = 305,	-- In Search of The Excavation Team (1/2)
				qg = 1076,	-- Merrin Rockweaver
				qi = 2639,	-- Merrin's Letter
				coord = { 38.8, 52.2, MAP.WETLANDS },
				races = ALLIANCE_ONLY,
				lvl = 21,
			}),
			q(290, {	-- Lifting the Curse
				sourceQuest = 289,	-- The Cursed Crew
				qg = 1239,	-- First Mate Fitzsimmons
				coord = { 10.9, 59.6, MAP.WETLANDS },
				races = ALLIANCE_ONLY,
				lvl = 22,
				groups = {
					objective(1, {	-- 0/1 Intrepid Strongbox Key
						provider = { "i", 2629 },	-- Intrepid Strongbox Key
						coord = { 15.6, 23.4, MAP.WETLANDS },
						cr = 1160,	-- Captain Halyndor
					}),
				},
			}),
			q(526, {	-- Lightforge Ingots
				sourceQuest = 321,	-- Lightforge Iron
				altQuests = { 324 },	-- The Lost Ingots
				qg = 1217,	-- Glorin Steelbrow
				coord = { 10.6, 60.6, MAP.WETLANDS },
				races = ALLIANCE_ONLY,
				lvl = 20,
				groups = {
					objective(1, {	-- 0/5 Lightforge Ingot
						provider = { "i", 2702 },	-- Lightforge Ingot
						cr = 1418,	-- Bluegill Raider
					}),
				},
			}),
			q(321, {	-- Lightforge Iron
				sourceQuest = 270,	-- The Doomed Fleet
				qg = 1217,	-- Glorin Steelbrow
				coord = { 10.6, 60.5, MAP.WETLANDS },
				races = ALLIANCE_ONLY,
				lvl = 20,
				groups = {
					i(2702),	-- Lightforge Ingot
				},
			}),
			q(465, {	-- Nek'rosh's Gambit
				sourceQuest = 464,	-- War Banners
				qg = 2104,	-- Captain Stoutfist
				qi = 3339,	-- Dwarven Tinder
				coord = { 9.8, 57.4, MAP.WETLANDS },
				races = ALLIANCE_ONLY,
				lvl = 23,
			}),
			q(98223, {	-- Old Habits
				provider = { "o", 671518 },	-- Tattered Spellbook
				qi = 280042,	-- Tattered Spellbook (PQI!)
				coord = { 53.5, 54.5, MAP.WETLANDS },
				timeline = { TIMELINE.ADDED_1_60_1 },
				races = ALLIANCE_ONLY,
				lvl = 23,
				groups = {
					i(281306),	-- Flamescarred Spellbook
					i(281307),	-- Dragonmaw Buckler
				},
			}),
			q(294, {	-- Ormer's Revenge (1/3)
				qg = 1078,	-- Ormer Ironbraid
				coord = { 38.0, 51.2, MAP.WETLANDS },
				races = ALLIANCE_ONLY,
				lvl = 22,
				groups = {
					objective(1, {	-- 0/10 Mottled Raptor slain
						provider = { "n", 1020 },	-- Mottled Raptor
					}),
					objective(2, {	-- 0/10 Mottled Screecher slain
						provider = { "n", 1021 },	-- Mottled Screecher
					}),
				},
			}),
			q(295, {	-- Ormer's Revenge (2/3)
				sourceQuest = 294,	-- Ormer's Revenge (1/3)
				qg = 1078,	-- Ormer Ironbraid
				coord = { 38.0, 51.2, MAP.WETLANDS },
				races = ALLIANCE_ONLY,
				lvl = 22,
				groups = {
					objective(1, {	-- 0/10 Mottled Scytheclaw slain
						provider = { "n", 1022 },	-- Mottled Scytheclaw
					}),
					objective(2, {	-- 0/10 Mottled Razormaw slain
						provider = { "n", 1023 },	-- Mottled Razormaw
					}),
				},
			}),
			q(296, {	-- Ormer's Revenge (3/3)
				sourceQuest = 295,	-- Ormer's Revenge (2/3)
				qg = 1078,	-- Ormer Ironbraid
				coord = { 38.0, 51.2, MAP.WETLANDS },
				races = ALLIANCE_ONLY,
				lvl = 22,
				groups = {
					objective(1, {	-- 0/1 Sarltooth's Talon
						provider = { "i", 3638 },	-- Sarltooth's Talon
						coord = { 33.0, 51.4, MAP.WETLANDS },
						cr = 1353,	-- Sarltooth
					}),
					i(3493),	-- Raptor's End
					i(3566),	-- Raptorbane Armor
					i(5246),	-- Excavation Rod
					i(3682),	-- Recipe: Curiously Tasty Omelet (RECIPE!)
					i(270039, {	-- Raptorclaw Shoulders
						timeline = { TIMELINE.ADDED_1_60_1 },
					}),
				},
			}),
			q(634, {	-- Plea To The Alliance
				sourceQuest = 633,	-- The Thandol Span (3/3)
				qg = 1075,	-- Rhag Garmason
				coord = { 49.9, 18.2, MAP.WETLANDS },
				races = ALLIANCE_ONLY,
				lvl = 28,
			}),
			q(98245, {	-- Razormaw Needling
				qg = 270637,	-- Howin Kindfeather
				coord = { 49.3, 42.1, MAP.WETLANDS },
				timeline = { TIMELINE.ADDED_1_60_1 },
				races = ALLIANCE_ONLY,
				lvl = 21,
				groups = {
					objective(1, {	-- 0/10 Razormaw Incisor
						provider = { "i", 280103 },	-- Razormaw Incisor
						coord = { 69.6, 33.5, MAP.WETLANDS },
						crs = {
							1018,	-- Highland Razormaw
							1019,	-- Elder Razormaw
						},
					}),
				},
			}),
			q(281, {	-- Reclaiming Goods
				sourceQuest = 279,	-- Claws from the Deep
				qg = 1242,	-- Karl Boran
				coord = { 8.4, 58.6, MAP.WETLANDS },
				races = ALLIANCE_ONLY,
				lvl = 20,
			}),
			q(473, {	-- Report to Captain Stoutfist
				sourceQuest = 455,	-- The Algaz Gauntlet
				qg = 2086,	-- Valstag Ironjaw
				coord = { 10.1, 56.9, MAP.WETLANDS },
				races = ALLIANCE_ONLY,
				isBreadcrumb = true,
				lvl = 23,
			}),
			q(286, {	-- Return the Statuette (1/2)
				sourceQuest = 285,	-- Search More Hovels
				provider = { "o", 259 },	-- Half-buried Barrel
				qi = 2625,	-- Menethil Statuette
				coord = { 14.0, 34.8, MAP.WETLANDS },
				races = ALLIANCE_ONLY,
				lvl = 20,
				groups = {
					i(2950),	-- Icicle Rod
					i(2949),	-- Mariner Boots
				},
			}),
			q(98189, {	-- Return the Statuette (2/2)
				sourceQuest = 286,	-- Return the Statuette (1/2)
				qg = 1242,	-- Karl Boran
				qi = 279589,	-- Menethil Statuette
				coord = { 8.4, 58.6, MAP.WETLANDS },
				timeline = { TIMELINE.ADDED_1_60_1 },
				races = ALLIANCE_ONLY,
				lvl = 20,
			}),
			q(285, {	-- Search More Hovels
				sourceQuest = 284,	-- The Search Continues
				provider = { "o", 142151 },	-- Sealed Barrel
				coord = { 13.6, 38.2, MAP.WETLANDS },
				races = ALLIANCE_ONLY,
				lvl = 20,
			}),
			q(88758, {	-- Sentiments of the Lost
				sourceQuest = 88757,	-- Accessories of the Lost
				qg = 271322,	-- Essene Villard
				qi = 284151,	-- Essene's Note (PQI!)
				coord = { 51.4, 9.0, MAP.WETLANDS },
				timeline = { TIMELINE.CREATED_1_60_1 },
				races = ALLIANCE_ONLY,
				lvl = 28,
				groups = {
					i(281258),	-- Essene's Hope
				},
			}),
			q(87491, {	-- Spark of Freedom
				qg = 271481,	-- Captive Fire Elemental
				coord = { 45.7, 16.6, MAP.WETLANDS },
				timeline = { TIMELINE.ADDED_1_60_1 },
				races = ALLIANCE_ONLY,
				lvl = 27,
			}),
			q(98197, {	-- Spoils of War
				qg = 2086,	-- Valstag Ironjaw
				coord = { 10.1, 56.8, MAP.WETLANDS },
				timeline = { TIMELINE.ADDED_1_60_1 },
				races = ALLIANCE_ONLY,
				lvl = 18,
				groups = {
					objective(1, {	-- 0/6 Khaz Modan Timber
						providers = {
							{ "i", 279821 },	-- Khaz Modan Timber
							{ "o", 670771 },	-- Khaz Modan Timber
						},
						coord = { 6.1, 61.8, MAP.WETLANDS },
					}),
					objective(2, {	-- 0/30 Khaz Modan Iron
						providers = {
							{ "i", 279822 },	-- Khaz Modan Iron
							{ "o", 670774 },	-- Khaz Modan Iron
						},
						coord = { 4.9, 52.6, MAP.WETLANDS },
					}),
				},
			}),
			q(98297, {	-- Stopping the Cycle
				sourceQuest = 98291,	-- Death to the Dragonmaw
				qg = 270637,	-- Howin Kindfeather
				coord = { 49.3, 42.1, MAP.WETLANDS },
				timeline = { TIMELINE.ADDED_1_60_1 },
				races = ALLIANCE_ONLY,
				lvl = 24,
				groups = {
					objective(1, {	-- 0/1 Subdued Dragonspawn slain
						provider = { "n", 271373 },	-- Subdued Dragonspawn
						coord = { 77.2, 46.6, MAP.WETLANDS },
					}),
					i(281312),	-- Fallen Dragon's Scepter
					i(281313),	-- Trusty Sword
					i(281314),	-- Subdued Dragon's Fang
				},
			}),
			q(943, {	-- The Absent Minded Prospector (5/5)
				sourceQuest = 942,	-- The Absent Minded Prospector (4/5) (Darnassus)
				qg = 2911,	-- Archaeologist Flagongut
				coord = { 10.8, 60.4, MAP.WETLANDS },
				races = ALLIANCE_ONLY,
				lvl = 15,
				groups = {
					objective(1, {	-- 0/1 Stone of Relu
						provider = { "i", 5233 },	-- Stone of Relu
						crs = {
							1020,	-- Mottled Raptor
							1023,	-- Mottled Razormaw
							1021,	-- Mottled Screecher
							1022,	-- Mottled Scytheclaw
						},
					}),
					objective(2, {	-- 0/1 Flagongut's Fossil
						providers = {
							{ "i", 5234 },	-- Flagongut's Fossil
							{ "o", 9630 },	-- Flagongut's Fossil
						},
						coord = { 38.8, 52.2, MAP.WETLANDS },
					}),
					i(5627),	-- Relic Blade
					i(5626),	-- Skullchipper
					i(270022, {	-- Archaeologist's Gown
						timeline = { TIMELINE.ADDED_1_60_1 },
					}),
				},
			}),
			q(289, {	-- The Cursed Crew
				sourceQuest = 288,	-- The Third Fleet
				qg = 1239,	-- First Mate Fitzsimmons
				coord = { 10.9, 59.6, MAP.WETLANDS },
				races = ALLIANCE_ONLY,
				lvl = 22,
				groups = {
					objective(1, {	-- 0/13 Cursed Sailor
						provider = { "n", 1157 },	-- Cursed Sailor
					}),
					objective(2, {	-- 0/5 Cursed Marine
						provider = { "n", 1158 },	-- Cursed Marine
					}),
					objective(3, {	-- 0/1 Snellig's Snuffbox
						provider = { "i", 3619 },	-- Snellig's Snuffbox
						coord = { 14.0, 30.6, MAP.WETLANDS },
						cr = 1159,	-- First Mate Snellig
					}),
				},
			}),
			q(303, {	-- The Dark Iron War
				qg = 1074,	-- Motley Garmason
				coord = { 49.7, 18.3, MAP.WETLANDS },
				races = ALLIANCE_ONLY,
				lvl = 25,
				groups = {
					objective(1, {	-- 0/15 Dark Iron Dwarf
						provider = { "n", 1051 },	-- Dark Iron Dwarf
					}),
					objective(2, {	-- 0/5 Dark Iron Tunneler
						provider = { "n", 1053 },	-- Dark Iron Tunneler
					}),
					objective(3, {	-- 0/5 Dark Iron Saboteur
						provider = { "n", 1052 },	-- Dark Iron Saboteur
					}),
					objective(4, {	-- 0/5 Dark Iron Demolitionist
						provider = { "n", 1054 },	-- Dark Iron Demolitionist
					}),
				},
			}),
			q(292, {	-- The Eye of Paleth
				sourceQuest = 290,	-- Lifting the Curse
				provider = { "o", 112948 },	-- Intrepid's Locked Strongbox
				coord = { 14.5, 24.0, MAP.WETLANDS },
				races = ALLIANCE_ONLY,
				lvl = 22,
				groups = {
					i(2944),	-- Cursed Eye of Paleth
				},
			}),
			q(463, {	-- The Greenwarden
				qg = 1239,	-- First Mate Fitzsimmons
				coord = { 10.9, 59.6, MAP.WETLANDS },
				races = ALLIANCE_ONLY,
				isBreadcrumb = true,
				lvl = 20,
			}),
			q(324, {	-- The Lost Ingots
				sourceQuest = 321,	-- Lightforge Iron
				altQuests = { 526 },	-- Lightforge Ingots
				provider = { "o", 2734 },	-- Waterlogged Chest
				coord = { 12.1, 64.1, MAP.WETLANDS },
				races = ALLIANCE_ONLY,
				lvl = 20,
				groups = {
					objective(1, {	-- 0/5 Lightforge Ingot
						provider = { "i", 2702 },	-- Lightforge Ingot
						cr = 1418,	-- Bluegill Raider
					}),
				},
			}),
			q(1249, {	-- The Missing Diplomat (11/17)
				sourceQuest = 1248,	-- The Missing Diplomat (10/17)
				qg = 4963,	-- Mikhail <Bartender>
				coord = { 10.6, 60.7, MAP.WETLANDS },
				races = ALLIANCE_ONLY,
				lvl = 28,
				groups = {
					objective(1, {	-- Defeat Tapoke Jahn
						provider = { "n", 4962 },	-- Tapoke "Slim" Jahn
					}),
				},
			}),
			q(1250, {	-- The Missing Diplomat (12/17)
				sourceQuest = 1249,	-- The Missing Diplomat (11/17)
				qg = 4962,	-- Tapoke "Slim" Jahn
				coord = { 10.6, 60.3, MAP.WETLANDS },
				races = ALLIANCE_ONLY,
				lvl = 28,
			}),
			q(1264, {	-- The Missing Diplomat (13/17)
				sourceQuest = 1250,	-- The Missing Diplomat (12/17)
				qg = 4963,	-- Mikhail <Bartender>
				coord = { 10.6, 60.7, MAP.WETLANDS },
				maps = { MAP.DUSTWALLOW_MARSH },
				races = ALLIANCE_ONLY,
				lvl = 28,
			}),
			q(284, {	-- The Search Continues
				sourceQuest = 281,	-- Reclaiming Goods
				provider = { "o", 261 },	-- Damaged Crate
				coord = { 13.5, 41.4, MAP.WETLANDS },
				races = ALLIANCE_ONLY,
				lvl = 20,
			}),
			q(98219, {	-- The Shamed Lieutenant
				sourceQuest = 98191,	-- A Friend of the Family (2/2)
				qg = 928,	-- Lord Grayson Shadowbreaker <Paladin Trainer>
				coord = { 48.6, 50.0, MAP.STORMWIND_CITY },
				timeline = { TIMELINE.ADDED_1_60_1 },
				maps = { MAP.HILLSBRAD_FOOTHILLS },
				races = ALLIANCE_ONLY,
				lvl = 20,
			}),
			q(631, {	-- The Thandol Span (1/3)
				qg = 1075,	-- Rhag Garmason
				coord = { 49.9, 18.2, MAP.WETLANDS },
				races = ALLIANCE_ONLY,
				lvl = 28,
			}),
			q(632, {	-- The Thandol Span (2/3)
				sourceQuest = 631,	-- The Thandol Span (1/3)
				providers = {
					{ "o", 2652 },	-- Ebenezer Rustlocke's Corpse
					{ "i", 4429 },	-- Deepfury's Orders
				},
				coord = { 51.3, 8.0, MAP.WETLANDS },
				races = ALLIANCE_ONLY,
				lvl = 28,
			}),
			q(633, {	-- The Thandol Span (3/3)
				sourceQuest = 632,	-- The Thandol Span (2/3)
				qg = 1075,	-- Rhag Garmason
				coord = { 49.9, 18.2, MAP.WETLANDS },
				maps = { MAP.ARATHI_HIGHLANDS },
				races = ALLIANCE_ONLY,
				lvl = 28,
				groups = {
					objective(1, {	-- Cache of Explosives Destroyed
						provider = { "o", 2704 },	-- Cache of Explosives
						coord = { 48.8, 88.2, MAP.ARATHI_HIGHLANDS },
					}),
					i(4504),	-- Dwarven Guard Cloak
					i(4505),	-- Swampland Trousers
				},
			}),
			q(288, {	-- The Third Fleet
				qg = 1239,	-- First Mate Fitzsimmons
				coord = { 10.9, 59.6, MAP.WETLANDS },
				races = ALLIANCE_ONLY,
				lvl = 22,
				groups = {
					objective(1, {	-- 0/1 Flagon of Dwarven Honeymead
						cost = { { "i", 2594, 1 } },	-- Flagon of Dwarven Honeymead
						coord = { 10.6, 60.8, MAP.WETLANDS },
						cr = 1464,	-- Innkeeper Helbrek <Innkeeper>
					}),
				},
			}),
			q(98230, {	-- This Land Was Their Land
				sourceQuest = 474,	-- Defeat Nek'rosh
				qg = 2104,	-- Captain Stoutfist
				coord = { 9.8, 57.4, MAP.WETLANDS },
				timeline = { TIMELINE.ADDED_1_60_1 },
				races = ALLIANCE_ONLY,
				lvl = 22,
			}),
			q(276, {	-- Tramping Paws
				sourceQuest = 463,	-- The Greenwarden
				qg = 1244,	-- Rethiel the Greenwarden
				coord = { 56.3, 40.4, MAP.WETLANDS },
				races = ALLIANCE_ONLY,
				lvl = 20,
				groups = {
					objective(1, {	-- 0/15 Mosshide Gnoll
						provider = { "n", 1007 },	-- Mosshide Gnoll
					}),
					objective(2, {	-- 0/15 Mosshide Mongrel
						provider = { "n", 1008 },	-- Mosshide Mongrel
					}),
				},
			}),
			q(98246, {	-- Trying Times
				qg = 270637,	-- Howin Kindfeather
				coord = { 49.3, 42.1, MAP.WETLANDS },
				timeline = { TIMELINE.ADDED_1_60_1 },
				races = ALLIANCE_ONLY,
				lvl = 21,
				groups = {
					objective(1, {	-- 0/12 Perfect Razormaw Egg
						providers = {
							{ "i", 280132 },	-- Perfect Razormaw Egg
							{ "o", 671892 },	-- Razormaw Eggs
							{ "o", 671931 },	-- Razormaw Egg
						},
						coord = { 35.5, 20.2, MAP.WETLANDS },
					}),
				},
			}),
			q(299, {	-- Uncovering the Past
				description = "The quest items spawn randomly in the dig site below.",
				qg = 1077,	-- Prospector Whelgar
				coord = { 38.8, 52.2, MAP.WETLANDS },
				races = ALLIANCE_ONLY,
				lvl = 22,
				groups = {
					objective(1, {	-- 0/1 Ados Fragment
						providers = {
							{ "i", 2658 },	-- Ados Fragment
							{ "o", 35252 },	-- Ancient Relic
						},
					}),
					objective(2, {	-- 0/1 Modr Fragment
						providers = {
							{ "i", 2659 },	-- Modr Fragment
							{ "o", 334 },	-- Ancient Relic
						},
					}),
					objective(3, {	-- 0/1 Golm Fragment
						providers = {
							{ "i", 2660 },	-- Golm Fragment
							{ "o", 333 },	-- Ancient Relic
						},
					}),
					objective(4, {	-- 0/1 Neru Fragment
						providers = {
							{ "i", 2661 },	-- Neru Fragment
							{ "o", 331 },	-- Loose Soil
						},
					}),
					i(2913),	-- Silk Mantle of Gamn
				},
			}),
			q(98216, {	-- Understanding Our Present
				sourceQuest = 299,	-- Uncovering the Past
				qg = 1077,	-- Prospector Whelgar
				qi = 279996,	-- Goaz Stone (PQI!)
				coord = { 38.8, 52.2, MAP.WETLANDS },
				timeline = { TIMELINE.ADDED_1_60_1 },
				races = ALLIANCE_ONLY,
				lvl = 23,
				groups = {
					objective(1, {	-- 0/1 Ados Fragment
						provider = { "i", 279993 },	-- Titanic Keystone
						coord = { 35.3, 47.0, MAP.WETLANDS },
						cr = 270892,	-- Goaz Warder
					}),
					i(281304),	-- Prospector's Signet
					i(281305),	-- Excavation Cloak
				},
			}),
			q(98461, {	-- Unrequited Love
				qg = 2913,	-- Archaeologist Hollee <Explorers' League>
				coord = { 37.44, 41.84, MAP.DARKSHORE },
				races = ALLIANCE_ONLY,
				lvl = 18,
				timeline = { TIMELINE.ADDED_1_60_1 },
				qi = 281243,	-- Hollee's Note (QI!)
				isBreadcrumb = true,
			}),
			q(464, {	-- War Banners
				sourceQuest = 473,	-- Report to Captain Stoutfist
				qg = 2104,	-- Captain Stoutfist
				coord = { 9.8, 57.4, MAP.WETLANDS },
				races = ALLIANCE_ONLY,
				lvl = 23,
				groups = {
					objective(1, {	-- 0/8 Dragonmaw War Banner
						provider = { "i", 3337 },	-- Dragonmaw War Banner
						crs = {
							2091,	-- Chieftain Nek'rosh
							1037,	-- Dragonmaw Battlemaster
							1057,	-- Dragonmaw Bonewarder
							1036,	-- Dragonmaw Centurion
							1034,	-- Dragonmaw Raider
							1038,	-- Dragonmaw Shadowwarder
							1035,	-- Dragonmaw Swamprunner
						},
					}),
				},
			}),
			q(98300, {	-- Word to Ironforge
				sourceQuest = 98297,	-- Stopping the Cycle
				qg = 270637,	-- Howin Kindfeather
				qi = 280392,	-- Howin's Missive (PQI!)
				coord = { 49.3, 42.1, MAP.WETLANDS },
				timeline = { TIMELINE.ADDED_1_60_1 },
				maps = { MAP.IRONFORGE },
				races = ALLIANCE_ONLY,
				lvl = 24,
			}),
			q(484, {	-- Young Crocolisk Skins
				sourceQuest = 469,	-- Daily Delivery
				qg = 2094,	-- James Halloran
				coord = { 8.5, 55.7, MAP.WETLANDS },
				races = ALLIANCE_ONLY,
				lvl = 18,
				groups = {
					objective(1, {	-- 0/4 Young Crocolisk Skin
						provider = { "i", 3397 },	-- Young Crocolisk Skin
						cr = 1417,	-- Young Wetlands Crocolisk
					}),
				},
			}),
		}),
		n(RARES, {
			n(1037, {	-- Dragonmaw Battlemaster
				coords = {
					{ 42.8, 43.8, MAP.WETLANDS },
					{ 47.6, 46.0, MAP.WETLANDS },
					{ 50.0, 48.2, MAP.WETLANDS },
					{ 50.8, 50.6, MAP.WETLANDS },
					{ 53.0, 53.6, MAP.WETLANDS },
				},
			}),
			n(2108, {	-- Garneg Charskull
				coords = {
					{ 38.6, 46.2, MAP.WETLANDS },
					{ 43.2, 44.2, MAP.WETLANDS },
					{ 48.0, 47.6, MAP.WETLANDS },
				},
				groups = {
					i(6200),	-- Garneg's War Belt
					i(3392),	-- Ringed Helm
				},
			}),
			n(14425, {	-- Gnawbone
				coords = {
					{ 39.0, 30.6, MAP.WETLANDS },
					{ 30.6, 31.2, MAP.WETLANDS },
					{ 35.4, 37.2, MAP.WETLANDS },
					{ 38.4, 36.4, MAP.WETLANDS },
				},
				groups = {
					i(282654, {	-- Gnawed Bone
						timeline = { TIMELINE.ADDED_1_60_1 },
					}),
				},
			}),
			n(1112, {	-- Leech Widow
				coord = { 46.8, 61.4, MAP.WETLANDS },
				groups = {
					i(4444),	-- Black Husk Shield
					i(6199),	-- Black Widow Band
				},
			}),
			n(2090, {	-- Ma'ruk Wyrmscale <Dragonmaw Warlord>
				coord = { 47.8, 76.8, MAP.WETLANDS },
				groups = {
					i(5749),	-- Scythe Axe
					i(5750),	-- Warchief's Girdle
				},
			}),
			n(14424, {	-- Mirelow
				coords = {
					{ 18.6, 28.4, MAP.WETLANDS },
					{ 22.8, 31.4, MAP.WETLANDS },
					{ 27.8, 32.8, MAP.WETLANDS },
					{ 23.0, 21.4, MAP.WETLANDS },
					{ 24.6, 37.0, MAP.WETLANDS },
				},
				groups = {
					i(282655, {	-- Bog Pickers
						timeline = { TIMELINE.ADDED_1_60_1 },
					}),
				},
			}),
			n(1140, {	-- Razormaw Matriarch
				coord = { 70.8, 30.4, MAP.WETLANDS },
				groups = {
					i(4463),	-- Beaded Raptor Collar
					i(6198),	-- Jurassic Wristguards
				},
			}),
			n(14433, {	-- Sludginn
				coords = {
					{ 14.8, 67.2, MAP.WETLANDS },
					{ 12.0, 70.6, MAP.WETLANDS },
				},
			}),
		}),
		n(TREASURES, {
			o(409717, {	-- Scrolls
				coord = { 33.6, 47.9, MAP.WETLANDS },
				timeline = { TIMELINE.ADDED_1_60_1 },
				groups = {
					i(209848),	-- Goaz Scrolls
				},
			}),
		}),
		n(VENDORS, {
			n(265346, {	-- Aurian Highgrove <Bartender>
				coord = { 52.8, 80.2, MAP.WETLANDS },
				timeline = { TIMELINE.ADDED_1_60_1 },
				races = ALLIANCE_ONLY,
				sym = {
					SymSelector.select("VENDOR_FOOD_DRINK"),	-- Drink
					{ "pop" },
					{ "select", "itemID",
						2723,	-- Bottle of Dalaran Noir
						2594,	-- Flagon of Dwarven Honeymead/Mead
						2593,	-- Flask of Stormwind Tawny
						2595,	-- Jug of Badlands Bourbon
						2596,	-- Skin of Dwarven Stout
					},
				},
				groups = {
					i(275892, {	-- Short Stout
						isLimited = true,
					}),
				},
			}),
			n(265347, {	-- Bhalir Firebrew <Chef>
				coord = { 52.8, 80.0, MAP.WETLANDS },
				timeline = { TIMELINE.ADDED_1_60_1 },
				races = ALLIANCE_ONLY,
				sym = {{ "select", "itemID",
					4599,	-- Cured Ham Steak
					2070,	-- Darnassian Bleu
					422,	-- Dwarven Mild
					4541,	-- Freshly Baked Bread
					4542,	-- Moist Cornbread
					3770,	-- Mutton Chop
					8952,	-- Roasted Quail
					1707,	-- Stormwind Brie
					21552,	-- Striped Yellowtail
					117,	-- Tough Jerky
				}},
				groups = {
					i(278119),	-- Bread with Butter
					i(278122),	-- Carrot Salad
					i(278120),	-- Fruit Platter
					i(278117),	-- Hard Boiled Eggs
					i(278118),	-- Rich Broth
					i(278121),	-- Smoked Sausage
				},
			}),
			n(1450, {	-- Brahnmar <Armorer>
				coord = { 11.6, 59.9, MAP.WETLANDS },
				races = ALLIANCE_ONLY,
				sym = {
					SymSelector.select("VENDOR_POLISHED_SCALE"),	-- Polished Scale
					{ "pop" },
					{ "select", "itemID",
						2446,	-- Kite Shield
						17192,	-- Reinforced Targe
					},
				},
			}),
			n(1441, {	-- Brak Durnad <Weaponsmith>
				coord = { 11.6, 59.5, MAP.WETLANDS },
				races = ALLIANCE_ONLY,
				sym = {{ "select", "itemID",
					926,	-- Battle Axe
					922,	-- Dacian Falx
					927,	-- Double Axe
					925,	-- Flail
					2209,	-- Kris
					923,	-- Longsword
					928,	-- Long Staff
					924,	-- Maul
				}},
				groups = {
					i(4817, {	-- Blessed Claymore
						isLimited = true,
					}),
					i(4818, {	-- Executioner's Sword
						isLimited = true,
					}),
				},
			}),
			n(3180, {	-- Dark Iron Entrepreneur <Speciality Goods>
				coord = { 46.6, 18.2, MAP.WETLANDS },
				groups = {
					i(4824, {	-- Blurred Axe
						isLimited = true,
					}),
					i(4825, {	-- Callous Axe
						isLimited = true,
					}),
					i(4826, {	-- Marauder Axe
						isLimited = true,
					}),
					i(4835, {	-- Elite Shoulders
						isLimited = true,
					}),
					i(4833, {	-- Glorious Shoulders
						isLimited = true,
					}),
					i(4832, {	-- Mystic Sarong
						isLimited = true,
					}),
					i(4830, {	-- Saber Leggings
						isLimited = true,
					}),
					i(4831, {	-- Stalking Pants
						isLimited = true,
					}),
				},
			}),
			n(2682, {	-- Fradd Swiftgear <Engineering Supplies>
				coord = { 26.4, 25.8, MAP.WETLANDS },
				races = ALLIANCE_ONLY,
				groups = {
					i(13309, {	-- Schematic: Lovingly Crafted Boomstick (RECIPE!)
						isLimited = true,
					}),
					i(14639, {	-- Schematic: Minor Recombobulator (RECIPE!)
						isLimited = true,
					}),
				},
			}),
			n(1454, {	-- Jennabink Powerseam <Tailoring Supplies & Specialty Goods>
				coord = { 8.1, 55.8, MAP.WETLANDS },
				races = ALLIANCE_ONLY,
				groups = {
					i(6275, {	-- Pattern: Greater Adept's Robe (RECIPE!)
						isLimited = true,
					}),
					i(5772, {	-- Pattern: Red Woolen Bag (RECIPE!)
						isLimited = true,
					}),
					i(4829, {	-- Dreamer's Belt
						isLimited = true,
					}),
					i(4790, {	-- Inferno Cloak
						isLimited = true,
					}),
					i(4828, {	-- Nightwind Belt
						isLimited = true,
					}),
					i(4792, {	-- Spirit Cloak
						isLimited = true,
					}),
					i(4793, {	-- Sylvan Cloak
						isLimited = true,
					}),
					i(4827, {	-- Wizard's Belt
						isLimited = true,
					}),
				},
			}),
			n(1461, {	-- Murndan Derth <Gunsmith>
				coord = { 11.3, 59.6, MAP.WETLANDS },
				races = ALLIANCE_ONLY,
				sym = {{ "select", "itemID",
					3024,	-- BKP 2700 "Enforcer"
					3023,	-- Large Bore Blunderbuss
				}},
			}),
			n(1459, {	-- Naela Trance <Bowyer>
				coord = { 11.3, 58.4, MAP.WETLANDS },
				races = ALLIANCE_ONLY,
				sym = {{ "select", "itemID",
					2507,	-- Laminated Recurve Bow
					3026,	-- Reinforced Bow
				}},
				groups = {
					i(11304, {	-- Fine Longbow
						isLimited = true,
					}),
				},
			}),
			n(1448, {	-- Neal Allen <Engineering Supplies & General Goods>
				coord = { 10.8, 56.8, MAP.WETLANDS },
				races = ALLIANCE_ONLY,
				sym = {{ "select", "itemID",
					5956,	-- Blacksmith Hammer
					4498,	-- Brown Leather Satchel
					3137,	-- Deadly Throwing Axe
					4497,	-- Heavy Brown Bag
					2519,	-- Heavy Shot
					4400,	-- Heavy Stock
					1179,	-- Ice Cold Milk
					3107,	-- Keen Throwing Knife
					1205,	-- Melon Juice
					2901,	-- Mining Pick
					3030,	-- Razor Arrow
					159,	-- Refreshing Spring Water
					2515,	-- Sharp Arrow
					3135,	-- Sharp Throwing Axe
					4470,	-- Simple Wood
					3033,	-- Solid Shot
					11291,	-- Star Wood
					3466,	-- Strong Flux
					2880,	-- Weak Flux
					4399,	-- Wooden Stock
				}},
			}),
			n(1457, {	-- Samor Festivus <Shady Dealer>
				coord = { 10.5, 60.2, MAP.WETLANDS },
				races = ALLIANCE_ONLY,
			}),
			n(3178, {	-- Stuart Fleming <Fisherman>
				coord = { 8.0, 58.3, MAP.WETLANDS },
				races = ALLIANCE_ONLY,
				sym = {
					SymSelector.select("VENDOR_FOOD_FISH"),	-- Fish
					{ "pop" },
					{ "select", "itemID",
						6533,	-- Aquadynamic Fish Attractor
						6532,	-- Bright Baubles
						273636,	-- Chef's Knife
						6256,	-- Fishing Pole
						6530,	-- Nightcrawlers
						6368,	-- Recipe: Rainbow Fin Albacore (RECIPE!)
						6529,	-- Shiny Bauble
						6365,	-- Strong Fishing Pole
					},
				},
				groups = {
					i(17062),	-- Recipe: Mithril Head Trout (RECIPE!)
					i(6369),	-- Recipe: Rockscale Cod (RECIPE!)
				},
			}),
			n(1460, {	-- Unger Statforth <Horse Breeder>
				coord = { 8.6, 54.4, MAP.WETLANDS },
				-- Available to Humans without faction requirements.
				minReputation = { FACTION_STORMWIND, EXALTED },
				OnInit = [[function(t)
					if _.RaceIndex == ]] .. HUMAN .. [[ then
						t.minReputation = nil;
					end
					return t;
				end]],
				races = ALLIANCE_ONLY,
				groups = {
					i(2411),	-- Black Stallion (MOUNT!)
					i(5656),	-- Brown Horse (MOUNT!)
					i(5655),	-- Chestnut Mare (MOUNT!)
					i(2414),	-- Pinto (MOUNT!)
				},
			}),
			n(2679, {	-- Wenna Silkbeard <Special Goods Dealer>
				coord = { 25.6, 25.8, MAP.WETLANDS },
				races = ALLIANCE_ONLY,
				groups = {
					i(7114, {	-- Pattern: Azure Silk Gloves (RECIPE!)
						isLimited = true,
					}),
					i(7613, {	-- Pattern: Green Leather Armor (RECIPE!)
						isLimited = true,
					}),
					i(7290, {	-- Pattern: Red Whelp Gloves (RECIPE!)
						isLimited = true,
					}),
					i(4829, {	-- Dreamer's Belt
						isLimited = true,
					}),
					i(4835, {	-- Elite Shoulders
						isLimited = true,
					}),
					i(4833, {	-- Glorious Shoulders
						isLimited = true,
					}),
					i(4832, {	-- Mystic Sarong
						isLimited = true,
					}),
					i(4828, {	-- Nightwind Belt
						isLimited = true,
					}),
					i(4830, {	-- Saber Leggings
						isLimited = true,
					}),
					i(4831, {	-- Stalking Pants
						isLimited = true,
					}),
					i(4827, {	-- Wizard's Belt
						isLimited = true,
					}),
				},
			}),
		}),
		n(ZONE_DROPS, {
			i(3022, {	-- Bluegill Breeches
				coords = {
					{ 23.0, 37.2, MAP.WETLANDS },
					{ 13.0, 33.2, MAP.WETLANDS },
				},
				crs = {
					1028,	-- Bluegill Muckdweller
				},
			}),
			i(2046, {	-- Bluegill Kukri
				coords = {
					{ 18.6, 40.0, MAP.WETLANDS },
					{ 15.2, 38.4, MAP.WETLANDS },
				},
				crs = {
					1027,	-- Bluegill Warrior
				},
			}),
			i(1560, {	-- Bluegill Sandals
				coords = {
					{ 18.6, 40.0, MAP.WETLANDS },
					{ 15.2, 38.4, MAP.WETLANDS },
				},
				crs = {
					1025,	-- Bluegill Puddlejumper
				},
			}),
			i(2084, {	-- Darksteel Bastard Sword
				coords = {
					{ 62.4, 28.0, MAP.WETLANDS },
					{ 46.8, 18.0, MAP.WETLANDS },
				},
				crs = {
					1054,	-- Dark Iron Demolitionist
				},
			}),
			i(1955, {	-- Dragonmaw Chain Boots
				coords = {
					{ 50.6, 49.4, MAP.WETLANDS },
					{ 39.0, 46.6, MAP.WETLANDS },
				},
				cr = 1035,	-- Dragonmaw Swamprunner
			}),
			i(753, {	-- Dragonmaw Shortsword
				coords = {
					{ 54.2, 54.2, MAP.WETLANDS },
					{ 53.4, 56.0, MAP.WETLANDS },
					{ 45.6, 45.4, MAP.WETLANDS },
				},
				cr = 1036,	-- Dragonmaw Centurion
			}),
			i(11150, {	-- Formula: Enchant Gloves - Mining (RECIPE!)
				crs = {
					1364,	-- Balgaras the Foul
					1054,	-- Dark Iron Demolitionist
					1051,	-- Dark Iron Dwarf
					1052,	-- Dark Iron Saboteur
					1053,	-- Dark Iron Tunneler
				},
			}),
			i(892, {	-- Gnoll Casting Gloves
				coords = {
					{ 45.6, 34.6, MAP.WETLANDS },
					{ 61.0, 58.4, MAP.WETLANDS },
					{ 62.6, 69.2, MAP.WETLANDS },
				},
				crs = {
					1009,	-- Mosshide Mistweaver
				},
			}),
			i(5788, {	-- Pattern: Thick Murloc Armor (RECIPE!)
				coord = { 15.6, 23.4, MAP.WETLANDS },
				cr = 1160,	-- Captain Halyndor
			}),
			i(250187, {	-- Recipe: Tasty Raptor Bites (RECIPE!)
				coord = { 27.8, 44.6, MAP.WETLANDS },
				timeline = { TIMELINE.ADDED_1_60_1 },
				cr = 1020,	-- Mottled Raptor
			}),
			i(279537, {	-- Rotheap Innards
				timeline = { TIMELINE.ADDED_1_60_1 },
				cr = 270589,	-- Nightveiled Rotheap
				groups = {
					i(282283, {	-- Malignant Root
						description = "Bring the Rotheap Innards to Rethiel the Greenwarden and choose the extra dialogue option to trade them for this ring. No quest or reputation is required.",
						provider = { "n", 1244 },	-- Rethiel the Greenwarden
						coord = { 56.4, 41.3, MAP.WETLANDS },
						cost = { { "i", 279537, 1 } },	-- 1x Rotheap Innards
					}),
				},
			}),
			i(264208, {	-- Schematic: SAF-T Jumbo Dynamite (RECIPE!)
				cr = 1054,	-- Dark Iron Demolitionist
				timeline = { TIMELINE.ADDED_1_60_1 },
			}),
			i(3076, {	-- Smoldering Boots
				coords = {
					{ 66.8, 53.2, MAP.WETLANDS },
					{ 59.6, 43.0, MAP.WETLANDS },
				},
				crs = {
					1042,	-- Red Whelp
				},
			}),
			i(3074, {	-- Smoldering Gloves
				coords = {
					{ 60.6, 33.2, MAP.WETLANDS },
					{ 66.2, 49.0, MAP.WETLANDS },
				},
				crs = {
					1043,	-- Lost Whelp
				},
			}),
			i(3073, {	-- Smoldering Pants
				coords = {
					{ 61.8, 31.2, MAP.WETLANDS },
					{ 65.4, 43.0, MAP.WETLANDS },
					{ 68.8, 45.6, MAP.WETLANDS },
				},
				crs = {
					1069,	-- Crimson Whelp
				},
			}),
			i(3072, {	-- Smoldering Robe
				coords = {
					{ 71.8, 47.6, MAP.WETLANDS },
					{ 66.4, 40.4, MAP.WETLANDS },
					{ 63.8, 33.6, MAP.WETLANDS },
				},
				crs = {
					1044,	-- Flamesnorting Whelp
				},
			}),
			i(6315, {	-- Steelarrow Crossbow
				coords = {
					{ 48.8, 17.6, MAP.WETLANDS },
					{ 48.9, 17.6, MAP.WETLANDS },
				},
				crs = {
					6523,	-- Dark Iron Rifleman
				},
			}),
			i(8499, {	-- Tiny Crimson Whelpling (item) / Crimson Whelpling (PET!)
				crs = {
					1069,	-- Crimson Whelp
					1044,	-- Flamesnorting Whelp
					1042,	-- Red Whelp
				},
			}),
			i(756, {	-- Tunnel Pick
				coords = {
					{ 61.2, 25.4, MAP.WETLANDS },
					{ 48.0, 18.6, MAP.WETLANDS },
				},
				crs = {
					1053,	-- Dark Iron Tunneler
				},
			}),
		}),
	},
});

root(ROOTS.HiddenQuestTriggers, {
	q(98224, {	-- Completed at 59.9, 39.0 in the Wetlands (Contributor Report, trigger unknown)
		timeline = { TIMELINE.ADDED_1_60_1 },
	}),
	q(98294, {	-- Forced Disarmament? (Triggered shortly after I picked up the Dragonmaw Armaments)
		timeline = { TIMELINE.ADDED_1_60_1 },
	}),
});
