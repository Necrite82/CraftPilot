---------------------------------------------------
--          Z O N E S        M O D U L E         --
---------------------------------------------------

maproot(MAP.EASTERN_KINGDOMS, MAP.UNDERCITY, {
	lore = "The Undercity is the capital city of the Forsaken undead of the Horde.\n\nFar beneath the ruined Capital City of the kingdom of Lordaeron, its royal crypts were turned into a bastion of evil and undeath. Originally intended by Prince Arthas to be the Scourge's seat of power, the budding \"Undercity\" was abandoned when Arthas was recalled to aid the Lich King in the distant Northrend. In Arthas' absence, the Dark Lady, Sylvanas Windrunner, led the rebel Forsaken to the Undercity, and claimed it for her own. Since taking up residence, the Forsaken worked to complete the Undercity's construction by dredging the twisted maze of catacombs, tombs, and dungeons that Arthas began.",
	icon = 255133,
	isRaid = true,
	groups = {
		n(FACTIONS, {
			faction(FACTION_UNDERCITY, {	-- Undercity
				icon = 236458,
				OnTooltip = [[_.OnTooltipDB.RuneclothTurnIns]],
				races = HORDE_ONLY,
			}),
		}),
		n(FLIGHT_PATHS, {
			fp(11, {	-- Undercity, Tirisfal
				cr = 4551,	-- Michael Garrett <Bat Handler>
				coord = { 63.6, 48.6, MAP.UNDERCITY },
				races = HORDE_ONLY,
			}),
		}),
		n(PROFESSIONS, {
			prof(ALCHEMY, {
				n(4611, {	-- Doctor Herbert Halsey <Artisan Alchemist>
					coord = { 47.6, 73.0, MAP.UNDERCITY },
					races = HORDE_ONLY,
					sym = {
						SymSelector.select("ALCHEMY_EXPERT"),
						{"pop"},
					},
				}),
				n(4609, {	-- Doctor Marsh <Expert Alchemist>
					coord = { 51.2, 75.0, MAP.UNDERCITY },
					races = HORDE_ONLY,
					sym = {
						SymSelector.select("ALCHEMY_JOURNEYMAN"),
						{"pop"},
					},
				}),
				n(11044, {	-- Doctor Martin Felben <Journeyman Alchemist Trainer>
					coord = { 45.8, 73.2, MAP.UNDERCITY },
					races = HORDE_ONLY,
					sym = {
						SymSelector.select("ALCHEMY_APPRENTICE"),
						{"pop"},
					},
				}),
			}),
			prof(BLACKSMITHING, {
				n(4605, {	-- Basil Frye <Journeyman Blacksmith>
					coord = { 59.2, 29.4, MAP.UNDERCITY },
					races = HORDE_ONLY,
					sym = {
						SymSelector.select("BLACKSMITHING_APPRENTICE"),
						{"pop"},
					},
				}),
				n(4596, {	-- James Van Brunt <Expert Blacksmith>
					coord = { 61.2, 29.2, MAP.UNDERCITY },
					races = HORDE_ONLY,
					sym = {
						SymSelector.select("BLACKSMITHING_JOURNEYMAN"),
						{"pop"},
					},
				}),
			}),
			prof(COOKING, {
				n(4552, {	-- Eunice Burch <Cooking Trainer>
					coord = { 62.2, 44.4, MAP.UNDERCITY },
					races = HORDE_ONLY,
					sym = {
						SymSelector.select("COOKING_APPRENTICE"),
						SymSelector.select("COOKING_JOURNEYMAN"),
						SymSelector.select("COOKING_EXPERT"),
						SymSelector.select("COOKING_ARTISAN"),
						{"pop"},
					},
				}),
			}),
			prof(ENCHANTING, {
				n(4616, {	-- Lavinia Crowe <Expert Enchanter>
					coord = { 62.2, 61.6, MAP.UNDERCITY },
					races = HORDE_ONLY,
					sym = {
						SymSelector.select("ENCHANTING_JOURNEYMAN"),
						{"pop"},
					},
				}),
				n(11067, {	-- Malcomb Wynn <Journeyman Enchanter>
					coord = { 62.2, 60.4, MAP.UNDERCITY },
					races = HORDE_ONLY,
					sym = {
						SymSelector.select("ENCHANTING_APPRENTICE"),
						{"pop"},
					},
				}),
			}),
			prof(ENGINEERING, {
				n(11031, {	-- Franklin Lloyd <Expert Engineer>
					coord = { 75.4, 73.0, MAP.UNDERCITY },
					races = HORDE_ONLY,
					sym = {
						SymSelector.select("ENGINEERING_JOURNEYMAN"),
						{"pop"},
					},
				}),
				n(4586, {	-- Graham Van Talen <Journeyman Engineer>
					coord = { 75.2, 72.4, MAP.UNDERCITY },
					races = HORDE_ONLY,
					sym = {
						SymSelector.select("ENGINEERING_APPRENTICE"),
						{"pop"},
					},
				}),
			}),
			prof(FIRST_AID, {
				n(4591, {	-- Mary Edras <First Aid Trainer>
					coord = { 73.4, 55.4, MAP.UNDERCITY },
					races = HORDE_ONLY,
					sym = {
						SymSelector.select("FIRST_AID_APPRENTICE"),
						SymSelector.select("FIRST_AID_JOURNEYMAN"),
						SymSelector.select("FIRST_AID_EXPERT"),
						{"pop"},
					},
				}),
			}),
			prof(FISHING, {
				n(4573, {	-- Armand Cromwell <Fishing Trainer>
					coord = { 80.4, 31.2, MAP.UNDERCITY },
					races = HORDE_ONLY,
					sym = {
						SymSelector.select("FISHING_APPRENTICE"),
						SymSelector.select("FISHING_JOURNEYMAN"),
						{"pop"},
					},
				}),
			}),
			prof(HERBALISM, {
				n(4614, {	-- Martha Alliestar <Herbalism Trainer>
					coord = { 54.2, 49.4, MAP.UNDERCITY },
					races = HORDE_ONLY,
					sym = {
						SymSelector.select("HERBALISM_APPRENTICE"),
						SymSelector.select("HERBALISM_JOURNEYMAN"),
						SymSelector.select("HERBALISM_EXPERT"),
						SymSelector.select("HERBALISM_ARTISAN"),
						{"pop"},
					},
				}),
			}),
			prof(LEATHERWORKING, {
				n(4588, {	-- Arthur Moore <Expert Leatherworker>
					coord = { 70.4, 57.4, MAP.UNDERCITY },
					races = HORDE_ONLY,
					sym = {
						SymSelector.select("LEATHERWORKING_JOURNEYMAN"),
						{"pop"},
					},
				}),
				n(223, {	-- Dan Golthas <Journeyman Leatherworker>
					coord = { 70.4, 58.4, MAP.UNDERCITY },
					races = HORDE_ONLY,
					sym = {
						SymSelector.select("LEATHERWORKING_APPRENTICE"),
						{"pop"},
					},
				}),
			}),
			prof(MINING, {
				n(4598, {	-- Brom Killian <Mining Trainer>
					coord = { 55.4, 36.2, MAP.UNDERCITY },
					races = HORDE_ONLY,
					sym = {
						SymSelector.select("MINING_APPRENTICE"),
						SymSelector.select("MINING_JOURNEYMAN"),
						SymSelector.select("MINING_EXPERT"),
						SymSelector.select("MINING_ARTISAN"),
						{"pop"},
					},
				}),
			}),
			prof(POISONS, {
				n(4582, {	-- Carolyn Ward <Rogue Trainer>
					coord = { 83.0, 72.8, MAP.UNDERCITY },
					races = HORDE_ONLY,
					sym = {
						SymSelector.select("POISONS_RECIPES"),
						{"pop"},
					},
				}),
				n(4584, {	-- Gregory Charles <Rogue Trainer>
					coord = { 84.2, 72.4, MAP.UNDERCITY },
					races = HORDE_ONLY,
					sym = {
						SymSelector.select("POISONS_RECIPES"),
						{"pop"},
					},
				}),
				n(4583, {	-- Miles Dexter <Rogue Trainer>
					coord = { 84.2, 71.0, MAP.UNDERCITY },
					races = HORDE_ONLY,
					sym = {
						SymSelector.select("POISONS_RECIPES"),
						{"pop"},
					},
				}),
			}),
			prof(SKINNING, {
				n(7087, {	-- Killian Hagey <Skinning Trainer>
					coord = { 70.4, 58.4, MAP.UNDERCITY },
					races = HORDE_ONLY,
					sym = {
						SymSelector.select("SKINNING_APPRENTICE"),
						SymSelector.select("SKINNING_JOURNEYMAN"),
						SymSelector.select("SKINNING_EXPERT"),
						SymSelector.select("SKINNING_ARTISAN"),
						{"pop"},
					},
				}),
			}),
			prof(TAILORING, {
				n(4576, {	-- Josef Gregorian <Artisan Tailor>
					coord = { 70.8, 29.2, MAP.UNDERCITY },
					races = HORDE_ONLY,
					sym = {
						SymSelector.select("TAILORING_EXPERT"),
						{"pop"},
					},
				}),
				n(4578, {	-- Josephine Lister <Master Shadoweave Tailor>
					coord = { 87.0, 20.8, MAP.UNDERCITY },
					races = HORDE_ONLY,
					sym = {
						SymSelector.select("TAILORING_SHADOWEAVE"),
						{"pop"},
					},
				}),
				n(11049, {	-- Rhiannon Davis <Expert Tailor>
					coord = { 70.2, 30.2, MAP.UNDERCITY },
					races = HORDE_ONLY,
					sym = {
						SymSelector.select("TAILORING_JOURNEYMAN"),
						{"pop"},
					},
				}),
				n(11048, {	-- Victor Ward <Journeyman Tailor>
					coord = { 70.2, 29.6, MAP.UNDERCITY },
					races = HORDE_ONLY,
					sym = {
						SymSelector.select("TAILORING_APPRENTICE"),
						{"pop"},
					},
				}),
			}),
		}),
		n(QUESTS, {
			q(4294, {	-- ... and a Batch of Ooze
				qg = 10136,	-- Chemist Fuely
				coord = { 47.6, 73.0, MAP.UNDERCITY },
				maps = { MAP.UNGORO_CRATER },
				races = HORDE_ONLY,
				lvl = 48,
				groups = {
					q(4561, {	-- Testing for Impurities - Un'Goro Crater
						provider = { "o", 174848 },	-- Testing Equipment
						coord = { 47.7, 73.3, MAP.UNDERCITY },
						cost = { { "i", 12235, 1 } },	-- Un'Goro Slime Sample
						races = HORDE_ONLY,
						repeatable = true,
						lvl = 48,
						groups = {
							i(15102, {	-- Un'Goro Tested Sample
								description = "Might contain nothing. Bring way more slime samples than you need.",
								groups = {
									objective(1, {	-- 0/5 Pure Un'Goro Sample
										questID = 4294,	-- ... and a Batch of Ooze
										provider = { "i", 12236 },	-- Pure Un'Goro Sample
									}),
								},
							}),
						},
					}),
					i(12235, {	-- Un'Goro Slime Sample
						description = "Bring at least 30 of these back with you to the Undercity for testing.",
						crs = {
							6559,	-- Glutinous Ooze
							6556,	-- Muculent Ooze
							6557,	-- Primal Ooze
						},
					}),
				},
			}),
			q(7817, {	-- A Donation of Mageweave
				qg = 14729,	-- Ralston Farnsley
				coord = { 71.8, 29.0, MAP.UNDERCITY },
				cost = { { "i", 4338, 60 } },	-- Mageweave Cloth
				races = HORDE_ONLY,
				lvl = 40,
			}),
			q(7818, {	-- A Donation of Runecloth
				qg = 14729,	-- Ralston Farnsley
				coord = { 71.8, 29.0, MAP.UNDERCITY },
				cost = { { "i", 14047, 60 } },	-- Runecloth
				races = HORDE_ONLY,
				lvl = 50,
			}),
			q(7814, {	-- A Donation of Silk
				qg = 14729,	-- Ralston Farnsley
				coord = { 71.8, 29.0, MAP.UNDERCITY },
				cost = { { "i", 4306, 60 } },	-- Silk Cloth
				races = HORDE_ONLY,
				lvl = 26,
			}),
			q(7813, {	-- A Donation of Wool
				qg = 14729,	-- Ralston Farnsley
				coord = { 71.8, 29.0, MAP.UNDERCITY },
				cost = { { "i", 2592, 60 } },	-- Wool Cloth
				races = HORDE_ONLY,
				lvl = 12,
			}),
			q(4293, {	-- A Sample of Slime...
				qg = 10136,	-- Chemist Fuely
				coord = { 47.6, 73.0, MAP.UNDERCITY },
				maps = { MAP.FELWOOD },
				races = HORDE_ONLY,
				lvl = 48,
				groups = {
					q(4661, {	-- Testing for Corruption - Felwood
						provider = { "o", 174848 },	-- Testing Equipment
						coord = { 47.7, 73.3, MAP.UNDERCITY },
						cost = { { "i", 12230, 1 } },	-- Felwood Slime Sample
						races = HORDE_ONLY,
						repeatable = true,
						lvl = 48,
						groups = {
							i(15103, {	-- Corrupt Tested Sample
								description = "Might contain nothing. Bring way more slime samples than you need.",
								groups = {
									objective(1, {	-- 0/5 Corrupted Felwood Sample
										questID = 4293,	-- A Sample of Slime...
										provider = { "i", 12234 },	-- Corrupted Felwood Sample
									}),
								},
							}),
						},
					}),
					i(12230, {	-- Felwood Slime Sample
						description = "Bring at least 30 of these back with you to the Undercity for testing.",
						crs = {
							7086,	-- Cursed Ooze
							7092,	-- Tainted Ooze
							14345,	-- The Ongar
						},
					}),
				},
			}),
			q(7819, {	-- Additional Runecloth [Undercity]
				sourceQuest = 7818,	-- A Donation of Runecloth
				qg = 14729,	-- Ralston Farnsley
				coord = { 71.8, 29.0, MAP.UNDERCITY },
				maxReputation = { FACTION_UNDERCITY, EXALTED },
				cost = { { "i", 14047, 20 } },	-- Runecloth
				races = HORDE_ONLY,
				repeatable = true,
				lvl = 50,
			}),
			q(1847, {	-- Brutal Legguards
				sourceQuest = 1846,	-- Dragonmaw Shinbones
				qg = 6411,	-- Velora Nitely
				coord = { 62.4, 39.2, MAP.UNDERCITY },
				classes = { WARRIOR },
				races = HORDE_ONLY,
				lvl = 20,
				groups = {
					i(7132),	-- Brutal Legguards
				},
			}),
			q(1473, {	-- Creature of the Void [Undercity]
				sourceQuest = 1478,	-- Halgar's Summons
				altQuests = { 1501 },	-- Creature of the Void [Orgrimmar]
				qg = 5675,	-- Carendin Halgar
				coord = { 85.0, 25.6, MAP.UNDERCITY },
				maps = { MAP.TIRISFAL_GLADES },
				races = { ORC, UNDEAD },
				classes = { WARLOCK },
				lvl = 10,
				groups = {
					objective(1, {	-- 0/1 Egalin's Grimoire
						provider = { "i", 6285 },	-- Egalin's Grimoire
						coord = { 51.1, 67.6, MAP.TIRISFAL_GLADES },
					}),
				},
			}),
			q(1507, {	-- Devourer of Souls [Orgrimmar]
				altQuests = { 1472 },	-- Devourer of Souls [Undercity]
				qg = 5875,	-- Dan'rul Bloodeye
				races = { ORC, UNDEAD },
				classes = { WARLOCK },
				isBreadcrumb = true,
				lvl = 20,
			}),
			q(1472, {	-- Devourer of Souls [Undercity]
				altQuests = { 1507 },	-- Devourer of Souls [Orgrimmar]
				qg = 5675,	-- Carendin Halgar
				coord = { 85.0, 25.6, MAP.UNDERCITY },
				races = { ORC, UNDEAD },
				classes = { WARLOCK },
				isBreadcrumb = true,
				lvl = 20,
			}),
			q(5679, {	-- Devouring Plague [Undercity]
				altQuests = {
					5646,	-- Devouring Plague [Orgrimmar]
					5644,	-- Devouring Plague [Thunder Bluff]
				},
				qg = 4606,	-- Aelthalyste
				coord = { 49.01, 18.32, MAP.UNDERCITY },
				classes = { PRIEST },
				races = { UNDEAD },
				lvl = 20,
				groups = {
					{
						recipeID = 2944,	-- Devouring Plague (Rank 1)
						rank = 1,
					},
				},
			}),
			q(1846, {	-- Dragonmaw Shinbones
				sourceQuest = 1841,	-- Velora Nitely and the Brutal Legguards
				qg = 6411,	-- Velora Nitely
				coord = { 62.4, 39.2, MAP.UNDERCITY },
				maps = { MAP.WETLANDS },
				classes = { WARRIOR },
				races = HORDE_ONLY,
				lvl = 20,
				groups = {
					objective(1, {	-- 0/8 Sturdy Dragonmaw Shinbone
						provider = { "i", 7134 },	-- Sturdy Dragonmaw Shinbone
						cost = { { "i", 7131, 1 } },	-- Dragonmaw Shinbone
						crs = {
							2091,	-- Chieftain Nek'rosh
							1037,	-- Dragonmaw Battlemaster
							1057,	-- Dragonmaw Bonewarder
							1036,	-- Dragonmaw Centurion
							1034,	-- Dragonmaw Raider
							1038,	-- Dragonmaw Shadowwarder
							1035,	-- Dragonmaw Swamprunner
						},
					}),
				},
			}),
			q(232, {	-- Errand for Apothecary Zinge (1/2)
				qg = 5204,	-- Apothecary Zinge
				qi = 8525,	-- Zinge's Purchase Order
				coord = { 50.0, 68.4, MAP.UNDERCITY },
				races = HORDE_ONLY,
				lvl = 38,
			}),
			q(238, {	-- Errand for Apothecary Zinge (2/2)
				sourceQuest = 232,	-- Errand for Apothecary Zinge (1/2)
				qg = 7683,	-- Alessandro Luca
				qi = 8523,	-- Field Testing Kit
				coord = { 58.2, 55.2, MAP.UNDERCITY },
				races = HORDE_ONLY,
				lvl = 38,
			}),
			q(1998, {	-- Fenwick Thatros
				qg = 6467,	-- Mennet Carkad
				coord = { 83.6, 67.6, MAP.UNDERCITY },
				maps = { MAP.SILVERPINE_FOREST },
				races = { UNDEAD },
				classes = { ROGUE },
				lvl = 16,
				groups = {
					objective(1, {	-- 0/1 Fenwick's Head
						provider = { "i", 7306 },	-- Fenwick's Head
						coord = { 59.6, 34.2, MAP.SILVERPINE_FOREST },
						cr = 6570,	-- Fenwick Thatros
					}),
				},
			}),
			q(1961, {	-- Gathering Materials
				sourceQuest = 1960,	-- Investigate the Alchemist Shop
				qg = 4568,	-- Anastasia Hartwell <Mage Trainer>
				coord = { 85.0, 10.2, MAP.UNDERCITY },
				maps = { MAP.SILVERPINE_FOREST },
				cost = { { "i", 2589, 10 } },	-- Linen Cloth
				races = HORDE_ONLY,
				classes = { MAGE },
				lvl = 15,
				groups = {
					objective(2, {	-- 0/6 Dalaran Mana Gem
						provider = { "i", 7293 },	-- Dalaran Mana Gem
						crs = {
							1867,	-- Dalaran Apprentice
							3577,	-- Dalaran Brewmaster
							1915,	-- Dalaran Conjuror
							1914,	-- Dalaran Mage
							3578,	-- Dalaran Miner
							1912,	-- Dalaran Protector
							1913,	-- Dalaran Warder
							1888,	-- Dalaran Watcher
							1889,	-- Dalaran Wizard
						},
					}),
				},
			}),
			q(3635, {	-- Gnome Engineering [H]
				altQuests = {
					3526,	-- Goblin Engineering
					3629,	-- Goblin Engineering
					3630,	-- Gnome Engineering
					3632,	-- Gnome Engineering
					3633,	-- Goblin Engineering
					3634,	-- Gnome Engineering
					-- 3635,	-- Gnome Engineering
					3637,	-- Gnome Engineering
					4181,	-- Goblin Engineering
				},
				qg = 4586,	-- Graham Van Talen <Journeyman Engineer>
				qi = 10789,	-- Manual of Engineering Disciplines
				coord = { 75.6, 74.6, MAP.UNDERCITY },
				races = HORDE_ONLY,
				requireSkill = ENGINEERING,
				learnedAt = 200,
				lvl = 30,
			}),
			q(3526, {	-- Goblin Engineering [H]
				altQuests = {
					-- 3526,	-- Goblin Engineering
					3629,	-- Goblin Engineering
					3630,	-- Gnome Engineering
					3632,	-- Gnome Engineering
					3633,	-- Goblin Engineering
					3634,	-- Gnome Engineering
					3635,	-- Gnome Engineering
					3637,	-- Gnome Engineering
					4181,	-- Goblin Engineering
				},
				qg = 4586,	-- Graham Van Talen <Journeyman Engineer>
				qi = 10789,	-- Manual of Engineering Disciplines
				coord = { 75.6, 74.6, MAP.UNDERCITY },
				races = HORDE_ONLY,
				requireSkill = ENGINEERING,
				learnedAt = 200,
				lvl = 30,
			}),
			q(1478, {	-- Halgar's Summons
				altQuests = { 1506 },	-- Gan'rul's Summons
				qg = 5724,	-- Ageron Kargal
				coord = { 61.6, 52.6, MAP.TIRISFAL_GLADES },
				races = { ORC, UNDEAD },
				classes = { WARLOCK },
				lvl = 10,
			}),
			q(65593, {	-- Hearts of the Lovers
				sourceQuest = 1472,	-- Devourer of Souls [Undercity]
				altQuests = { 65610 },	-- Wish You Were Here
				qg = 5675,	-- Carendin Halgar
				coord = { 85.0, 25.6, MAP.UNDERCITY },
				maps = { MAP.THE_BARRENS, MAP.SILVERPINE_FOREST },
				classes = { WARLOCK },
				races = HORDE_ONLY,
				lvl = 20,
				groups = {
					objective(1, {	-- 0/1 Avelina's Heart
						provider = { "i", 190179 },	-- Avelina's Heart
						coord = { 63.6, 65.6, MAP.SILVERPINE_FOREST },
						cr = 185333,	-- Avelina Lilly
					}),
					objective(2, {	-- 0/1 Isaac's Heart
						provider = { "i", 190180 },	-- Isaac's Heart
						coord = { 61.8, 38.6, MAP.THE_BARRENS },
						cr = 185334,	-- Isaac Pearson
					}),
				},
			}),
			q(1476, {	-- Hearts of the Pure
				sourceQuests = {
					1507,	-- Devourer of Souls [Orgrimmar]
					1472,	-- Devourer of Souls [Undercity]
				},
				qg = 5693,	-- Godrick Farsan
				coord = { 85.0, 14.8, MAP.UNDERCITY },
				maps = { MAP.SILVERPINE_FOREST, MAP.WETLANDS },
				classes = { WARLOCK },
				races = { ORC, UNDEAD },
				lvl = 20,
				groups = {
					objective(1, {	-- 0/1 Dalin's Heart
						provider = { "i", 6312 },	-- Dalin's Heart
						coord = { 46.6, 84.2, MAP.SILVERPINE_FOREST },
						cr = 5682,	-- Dalin Forgewright
					}),
					objective(2, {	-- 0/1 Comar's Heart
						provider = { "i", 6313 },	-- Comar's Heart
						coord = { 50.6, 12.6, MAP.WETLANDS },
						cr = 5683,	-- Comar Villard
					}),
				},
			}),
			q(5657, {	-- Hex of Weakness [Undercity]
				altQuests = {
					5652,	-- Hex of Weakness [Orgrimmar]
					5654,	-- Hex of Weakness [Durotar]
					5655,	-- Hex of Weakness [Mulgore]
					5656,	-- Hex of Weakness [Thunder Bluff]
				},
				qg = 4606,	-- Aelthalyste <Priest Trainer>
				coord = { 49.01, 18.32, MAP.UNDERCITY },
				classes = { PRIEST },
				races = { TROLL },
				lvl = 10,
				groups = {
					{
						recipeID = 9035,	-- Hex of Weakness (Rank 1)
						rank = 1,
					},
				},
			}),
			q(243, {	-- Into the Field
				sourceQuest = 238,	-- Errand for Apothecary Zinge (2/2)
				qg = 5204,	-- Apothecary Zinge
				qi = 8523,	-- Field Testing Kit
				coord = { 50.1, 68.0, MAP.UNDERCITY },
				maps = { MAP.TANARIS },
				races = HORDE_ONLY,
				lvl = 38,
			}),
			q(1960, {	-- Investigate the Alchemist Shop
				sourceQuest = 1959,	-- Report to Anastasia
				qg = 4568,	-- Anastasia Hartwell <Mage Trainer>
				coord = { 85.0, 10.2, MAP.UNDERCITY },
				races = HORDE_ONLY,
				classes = { MAGE },
				lvl = 15,
				groups = {
					objective(1, {	-- 0/3 Filled Containment Coffer
						providers = {
							{ "i",   7292 },	-- Filled Containment Coffer
							{ "o", 103574 },	-- Filled Containment Coffer
							{ "i",   7247 },	-- Chest of Containment Coffers
							{ "i",   7308 },	-- Cantation of Manifestation
						},
						coord = { 53.9, 73.2, MAP.UNDERCITY },
						cr = 6492,	-- Rift Spawn
					}),
					objective(2, {	-- 0/1 Chest of Containment Coffers
						providers = {
							{ "i",   7247 },	-- Chest of Containment Coffers
							{ "o", 105174 },	-- Chest of Containment Coffers
						},
						coord = { 85.4, 10.2, MAP.UNDERCITY },
					}),
					objective(3, {	-- 0/1 Cantation of Manifestation
						providers = {
							{ "i",   7308 },	-- Cantation of Manifestation
							{ "o", 105175 },	-- Cantation of Manifestation
						},
						coord = { 85.4, 10.2, MAP.UNDERCITY },
					}),
				},
			}),
			q(2995, {	-- Lines of Communication
				qg = 7825,	-- Oran Snakewrithe
				coord = { 73.3, 32.4, MAP.UNDERCITY },
				maps = { MAP.THE_HINTERLANDS },
				races = HORDE_ONLY,
				lvl = 42,
				groups = {
					objective(1, {	-- Burn the Highvale Records
						coord = { 32.0, 46.9, MAP.THE_HINTERLANDS },
					}),
					objective(2, {	-- Burn the Highvale Notes
						coord = { 29.7, 48.5, MAP.THE_HINTERLANDS },
					}),
					objective(3, {	-- Burn the Highvale Report
						coord = { 28.7, 46.1, MAP.THE_HINTERLANDS },
					}),
				},
			}),
			q(4642, {	-- Melding of Influences
				sourceQuests = {
					4294,	-- ... and a Batch of Ooze
					4293,	-- A Sample of Slime...
				},
				qg = 10136,	-- Chemist Fuely
				coord = { 47.6, 73.0, MAP.UNDERCITY },
				maps = { MAP.UNGORO_CRATER },
				races = HORDE_ONLY,
				lvl = 48,
				groups = {
					objective(1, {	-- 0/1 Merged Ooze Sample
						provider = { "i", 12291 },	-- Merged Ooze Sample
						cost = { { "i", 12288, 1 } },	-- Encased Corrupt Ooze
						crs = {
							6557,	-- Primal Ooze
							9621,	-- Gargantuan Ooze
						},
					}),
					i(15702),	-- Chemist's Ring
					i(15703),	-- Chemist's Smock
				},
			}),
			q(1885, {	-- Mennet Carkad
				qg = 2130,	-- Marion Call
				coord = { 61.6, 52.0, MAP.TIRISFAL_GLADES },
				races = { UNDEAD },
				classes = { ROGUE },
				isBreadcrumb = true,
				lvl = 10,
			}),
			q(6322, {	-- Michael Garrett
				sourceQuest = 6323,	-- Ride to the Undercity
				qg = 4556,	-- Gordon Wendham
				qi = 16210,	-- Gordon's Crate
				coord = { 61.6, 41.8, MAP.UNDERCITY },
				maps = { MAP.SILVERPINE_FOREST },
				races = { UNDEAD },
				lvl = 10,
			}),
			q(8273, {	-- Oran's Gratitude
				sourceQuest = 2782,	-- Rin'ji's Secret
				qg = 7825,	-- Oran Snakewrithe
				coord = { 73.4, 32.4, MAP.UNDERCITY },
				races = HORDE_ONLY,
				lvl = 42,
				groups = {
					i(20643),	-- Undercity Reservist's Cap
					i(20642),	-- Antiquated Nobleman's Tunic
				},
			}),
			q(97891, {	-- Prompt Potion Runner
				qg = 7683,	-- Alessandro Luca <Blue Moon Odds and Ends>
				qi = 279020,	-- Unstable Potion (PQI!)
				coord = { 58.2, 55.2, MAP.UNDERCITY },
				timeline = { TIMELINE.ADDED_1_60_1 },
				races = HORDE_ONLY,
				lvl = 9,
			}),
			q(91734, {	-- Remote Contact
				qg = 6522,	-- Andron Gant
				coord = { 54.8, 75.6, MAP.UNDERCITY },
				timeline = { TIMELINE.ADDED_1_60_1 },
				races = HORDE_ONLY,
				lvl = 44,
			}),
			q(1959, {	-- Report to Anastasia
				qgs = {
					7311,	-- Uthel'nay <Mage Trainer>
					3049,	-- Thurston Xane <Mage Trainer>
				},
				coords = {
					{ 39.0, 86.0, MAP.ORGRIMMAR },
					{ 25.0, 20.6, MAP.THUNDER_BLUFF },
				},
				races = HORDE_ONLY,
				classes = { MAGE },
				isBreadcrumb = true,
				lvl = 15,
			}),
			q(97022, {	-- Report to Danitha
				qg = 260093,	-- Garen Largo
				coord = { 47.6, 14.8, MAP.UNDERCITY },
				timeline = { TIMELINE.ADDED_1_60_1 },
				races = { UNDEAD },
				classes = { PALADIN },
				lvl = 40,
			}),
			q(6324, {	-- Return to Podrig
				sourceQuest = 6322,	-- Michael Garrett
				qg = 4551,	-- Michael Garrett
				qi = 16210,	-- Gordon's Crate
				coords = {
					{ 44.9, 38.9, MAP.EASTERN_KINGDOMS },
					{ 63.4, 48.6, MAP.UNDERCITY },
				},
				maps = { MAP.SILVERPINE_FOREST },
				races = { UNDEAD },
				lvl = 10,
			}),
			q(1358, {	-- Sample for Helbrim
				sourceQuest = 1359,	-- Zinge's Delivery
				qg = 5204,	-- Apothecary Zinge
				qi = 6016,	-- Wolf Heart Sample
				coord = { 50.0, 68.4, MAP.UNDERCITY },
				maps = { MAP.THE_BARRENS },
				races = HORDE_ONLY,
				lvl = 10,
				groups = {
					i(10637),	-- Brewer's Gloves
					i(10638),	-- Long Draping Cape
				},
			}),
			q(3568, {	-- Seeping Corruption (1/3)
				qg = 8390,	-- Chemist Cuely
				coord = { 48.8, 71.7, MAP.UNDERCITY },
				maps = { MAP.AZSHARA },
				races = HORDE_ONLY,
				lvl = 45,
				groups = {
					objective(1, {	-- 0/1 Filled Vial Labeled #1
						provider = { "i", 10691 },	-- Filled Vial Labeled #1
						cost = { { "i", 10687, 1 } },	-- Empty Vial Labeled #1
						coord = { 48.0, 60.0, MAP.AZSHARA },
					}),
					objective(2, {	-- 0/1 Filled Vial Labeled #2
						provider = { "i", 10692 },	-- Filled Vial Labeled #2
						cost = { { "i", 10688, 1 } },	-- Empty Vial Labeled #2
						coord = { 47.0, 51.0, MAP.AZSHARA },
					}),
					objective(3, {	-- 0/1 Filled Vial Labeled #3
						provider = { "i", 10693 },	-- Filled Vial Labeled #3
						cost = { { "i", 10689, 1 } },	-- Empty Vial Labeled #3
						coord = { 48.0, 48.0, MAP.AZSHARA },
					}),
					objective(4, {	-- 0/1 Filled Vial Labeled #4
						provider = { "i", 10694 },	-- Filled Vial Labeled #4
						cost = { { "i", 10690, 1 } },	-- Empty Vial Labeled #4
						coord = { 47.0, 46.0, MAP.AZSHARA },
					}),
					i(10695, {	-- Box of Empty Vials
						i(10687),	-- Empty Vial Labeled #1
						i(10688),	-- Empty Vial Labeled #2
						i(10689),	-- Empty Vial Labeled #3
						i(10690),	-- Empty Vial Labeled #4
					}),
				},
			}),
			q(3569, {	-- Seeping Corruption (2/3)
				sourceQuest = 3568,	-- Seeping Corruption (1/3)
				qg = 8390,	-- Chemist Cuely
				qi = 10712,	-- Cuely's Elixir
				coord = { 48.8, 71.7, MAP.UNDERCITY },
				races = HORDE_ONLY,
				lvl = 45,
			}),
			q(3570, {	-- Seeping Corruption (3/3)
				sourceQuest = 3569,	-- Seeping Corruption (2/3)
				qg = 8390,	-- Chemist Cuely
				coord = { 48.8, 71.7, MAP.UNDERCITY },
				races = HORDE_ONLY,
				lvl = 45,
			}),
			q(5643, {	-- Shadowguard [Undercity]
				altQuests = {
					5680,	-- Shadowguard [Orgrimmar]
					5642,	-- Shadowguard [Thunder Bluff]
				},
				qg = 4606,	-- Aelthalyste
				coord = { 49.01, 18.32, MAP.UNDERCITY },
				classes = { PRIEST },
				races = { TROLL },
				lvl = 20,
				groups = {
					{
						recipeID = 18137,	-- Shadowguard (Rank 1)
						rank = 1,
					},
				},
			}),
			q(1881, {	-- Speak with Anastasia
				altQuests = { 1883 },	-- Speak with Un'thuwa
				qg = 2128,	-- Cain Firesong <Mage Trainer>
				coord = { 61.8, 52.4, MAP.TIRISFAL_GLADES },
				races = { UNDEAD, TROLL },
				classes = { MAGE },
				isBreadcrumb = true,
				lvl = 10,
			}),
			q(1962, {	-- Spellfire Robes
				sourceQuest = 1961,	-- Gathering Materials
				qg = 11049,	-- Rhiannon Davis <Expert Tailor>
				coord = { 70.2, 30.2, MAP.UNDERCITY },
				races = HORDE_ONLY,
				classes = { MAGE },
				lvl = 15,
				groups = {
					i(7510),	-- Lesser Spellfire Robes
				},
			}),
			q(1882, {	-- The Balnir Farmstead
				sourceQuests = {
					1881,	-- Speak with Anastasia
					1883,	-- Speak with Un'thuwa
				},
				qg = 4568,	-- Anastasia Hartwell <Mage Trainer>
				coord = { 85.0, 10.2, MAP.UNDERCITY },
				maps = { MAP.TIRISFAL_GLADES },
				races = { UNDEAD, TROLL },
				classes = { MAGE },
				lvl = 10,
				groups = {
					objective(1, {	-- 0/1 Balnir Snapdragons
						providers = {
							{ "i",   7227 },	-- Balnir Snapdragons
							{ "o", 102985 },	-- Balnir Snapdragons
						},
						coord = { 77.4, 62.1, MAP.TIRISFAL_GLADES },
					}),
					i(7507),	-- Arcane Orb
					i(9514),	-- Arcane Staff
				},
			}),
			q(65597, {	-- The Binding (Incubus) [Undercity]
				sourceQuest = 65593,	-- Hearts of the Lovers
				altQuests = { 65604 },	-- The Binding (Incubus) [Orgrimmar]
				qg = 5675,	-- Carendin Halgar
				coord = { 85.0, 25.6, MAP.UNDERCITY },
				classes = { WARLOCK },
				races = HORDE_ONLY,
				lvl = 20,
				groups = {
					objective(1, {	-- 0/1 Summoned Incubus slain
						provider = { "n", 185335 },	-- Summoned Incubus
						cost = { { "i", 190181, 1 } },	-- Lovers' Hearts
					}),
					recipe(713),	-- Summon Incubus
					i(22243),	-- Small Soul Pouch
				},
			}),
			q(1474, {	-- The Binding (Succubus) [Undercity]
				sourceQuest = 1476,	-- Hearts of the Pure
				altQuests = { 1513 },	-- The Binding (Succubus) [Orgrimmar]
				qg = 5675,	-- Carendin Halgar
				coord = { 85.0, 25.6, MAP.UNDERCITY },
				classes = { WARLOCK },
				races = HORDE_ONLY,
				lvl = 20,
				groups = {
					objective(1, {	-- 0/1 Summoned Succubus slain
						provider = { "n", 5677 },	-- Summoned Succubus
						cost = { { "i", 6286, 1 } },	-- Pure Hearts
					}),
					recipe(712),	-- Summon Succubus
					i(22243),	-- Small Soul Pouch
				},
			}),
			q(1471, {	-- The Binding (Voidwalker) [Undercity]
				sourceQuest = 1473,	-- Creature of the Void [Undercity]
				altQuests = { 1504 },	-- The Binding (Voidwalker) [Orgrimmar]
				qg = 5675,	-- Carendin Halgar
				coord = { 85.0, 25.6, MAP.UNDERCITY },
				classes = { WARLOCK },
				races = { ORC, UNDEAD },
				lvl = 10,
				groups = {
					objective(1, {	-- 0/1 Summoned Voidwalker slain
						provider = { "n", 5676 },	-- Summoned Voidwalker
						cost = { { "i", 6284, 1 } },	-- Runes of Summoning
					}),
					recipe(697),	-- Summon Voidwalker
				},
			}),
			q(1886, {	-- The Deathstalkers (1/4)
				sourceQuest = 1885,	-- Mennet Carkad
				qg = 6467,	-- Mennet Carkad
				coord = { 83.2, 69.0, MAP.UNDERCITY },
				maps = { MAP.SILVERPINE_FOREST },
				races = { UNDEAD },
				classes = { ROGUE },
				lvl = 10,
				groups = {
					objective(1, {	-- 0/1 Astor's Letter of Introduction
						provider = { "i", 7231 },	-- Astor's Letter of Introduction
						coords = {
							{ 67.4, 5.6, MAP.SILVERPINE_FOREST },
							{ 53.6, 19.5, MAP.SILVERPINE_FOREST },
							{ 51.0, 36.2, MAP.SILVERPINE_FOREST },
							{ 46.4, 41.4, MAP.SILVERPINE_FOREST },
						},
						cr = 6497,	-- Astor Hadren
					}),
				},
			}),
			q(1898, {	-- The Deathstalkers (2/4)
				sourceQuest = 1886,	-- The Deathstalkers (1/4)
				qg = 6467,	-- Mennet Carkad
				qi = 7231,	-- Astor's Letter of Introduction
				coord = { 83.2, 69.0, MAP.UNDERCITY },
				races = { UNDEAD },
				classes = { ROGUE },
				lvl = 10,
			}),
			q(1899, {	-- The Deathstalkers (3/4)
				sourceQuest = 1898,	-- The Deathstalkers (2/4)
				qg = 6522,	-- Andron Gant
				coord = { 54.6, 75.6, MAP.UNDERCITY },
				races = { UNDEAD },
				classes = { ROGUE },
				lvl = 10,
				groups = {
					objective(1, {	-- 0/1 Andron's Ledger
						provider = { "i", 7294 },	-- Andron's Ledger
						coord = { 55.3, 76.7, MAP.UNDERCITY },
					}),
				},
			}),
			q(1978, {	-- The Deathstalkers (4/4)
				sourceQuest = 1899,	-- The Deathstalkers (3/4)
				qg = 6467,	-- Mennet Carkad
				qi = 7294,	-- Andron's Ledger
				coord = { 83.2, 69.0, MAP.UNDERCITY },
				races = { UNDEAD },
				classes = { ROGUE },
				lvl = 10,
				groups = {
					i(7298),	-- Blade of Cunning
				},
			}),
			q(97985, {	-- Thundering Hearts
				qg = 270038,	-- Calder Gray <Understudy of the Royal Apothecary Society>
				coord = { 49.2, 70.4, MAP.UNDERCITY },
				maps = { MAP.THOUSAND_NEEDLES },
				timeline = { TIMELINE.ADDED_1_60_1 },
				races = HORDE_ONLY,
				lvl = 25,
				groups = {
					objective(1, {	-- 0/1 Stormheart's Still-beating Heart
						provider = { "i", 279186 },	-- Stormheart's Still-beating Heart
						cr = 270094,	-- Stormheart
						coord = { 51.4, 48.3, MAP.THOUSAND_NEEDLES },
					}),
				},
			}),
			q(1164, {	-- To Steal From Thieves
				qg = 4486,	-- Genavie Callow
				coord = { 64.8, 49.6, MAP.UNDERCITY },
				maps = { MAP.ARATHI_HIGHLANDS },
				races = HORDE_ONLY,
				lvl = 27,
				groups = {
					objective(1, {	-- 0/1 Kenata's Head
						provider = { "i", 5830 },	-- Kenata's Head
						coord = { 56.2, 36.0, MAP.ARATHI_HIGHLANDS },
						cr = 4480,	-- Kenata Dabyrie
					}),
					objective(2, {	-- 0/1 Marcel's Head
						provider = { "i", 5832 },	-- Marcel's Head
						coord = { 54.5, 38.6, MAP.ARATHI_HIGHLANDS },
						cr = 4481,	-- Marcel Dabyrie
					}),
					objective(3, {	-- 0/1 Fardel's Head
						provider = { "i", 5831 },	-- Fardel's Head
						coord = { 55.0, 40.0, MAP.ARATHI_HIGHLANDS },
						cr = 4479,	-- Fardel Dabyrie
					}),
					i(4443),	-- Grim Pauldrons
					i(2032),	-- Gallan Cuffs
				},
			}),
			q(1999, {	-- Tools of the Trade
				sourceQuest = 1998,	-- Fenwick Thatros
				qg = 6467,	-- Mennet Carkad
				coord = { 83.2, 69.0, MAP.UNDERCITY },
				maps = { MAP.SILVERPINE_FOREST },
				races = { UNDEAD },
				classes = { ROGUE },
				lvl = 16,
				groups = {
					objective(1, {	-- 0/1 Dalaran Status Report
						provider = { "i", 7309 },	-- Dalaran Status Report
					}),
				},
			}),
			q(5658, {	-- Touch of Weakness [Undercity]
				altQuests = {
					5660,	-- Touch of Weakness [Durotar]
					5661,	-- Touch of Weakness [Mulgore]
					5662,	-- Touch of Weakness [Orgrimmar]
					5663,	-- Touch of Weakness [Thunder Bluff]
				},
				qg = 4606,	-- Aelthalyste
				coord = { 49.0, 18.3, MAP.UNDERCITY },
				classes = { PRIEST },
				races = { UNDEAD },
				lvl = 10,
				groups = {
					{
						recipeID = 2652,	-- Touch of Weakness (Rank 1)
						rank = 1,
					},
				},
			}),
			q(1841, {	-- Velora Nitely and the Brutal Legguards
				sourceQuest = 1838,	-- Brutal Armor
				qg = 5878,	-- Thun'grim Firegaze
				coord = { 57.2, 30.2, MAP.THE_BARRENS },
				classes = { WARRIOR },
				races = HORDE_ONLY,
				lvl = 20,
			}),
			q(97583, {	-- WRIGGLE.
				description = "Spam /dance at the excitable slimes that patrol around the Undercity.",
				qg = 269452,	-- Excitable Slime
				coords = {
					{ 57.6, 63.4, MAP.UNDERCITY },
					{ 64.6, 65.0, MAP.UNDERCITY },
					{ 83.4, 45.4, MAP.UNDERCITY },
					{ 74.6, 23.2, MAP.UNDERCITY },
					{ 53.2, 29.4, MAP.UNDERCITY },
				},
				timeline = { TIMELINE.ADDED_1_60_1 },
				cost = { { "i", 278265, 1 } },	-- Nutritious Slime Sludge
				races = HORDE_ONLY,
				repeatable = true,
				groups = {
					i(275682),	-- Excitable Slime
				},
			}),
		}),
		n(TREASURES, {
			o(180666, {	-- Draconic for Dummies
				coord = { 77.0, 38.0, MAP.UNDERCITY },
				groups = {
					i(21106),	-- Draconic for Dummies [Chapter IV]
				},
			}),
			o(701788, {	-- Knife
				description = "In the debris at the sewer entrance, open the book inside the shattered barrel; the knife is tucked between its pages.",
				coords = {
					{ 23.0, 36.4, MAP.UNDERCITY },
					{ 23.6, 35.4, MAP.UNDERCITY },
					{ 23.7, 35.9, MAP.UNDERCITY },
				},
				timeline = { TIMELINE.ADDED_1_60_1 },
				groups = {
					i(281350),	-- Keystone Fragment
				},
			}),
		}),
		n(VENDORS, {
			n(4604, {	-- Abigail Sawyer <Bow Merchant>
				coord = { 54.8, 38.0, MAP.UNDERCITY },
				races = HORDE_ONLY,
				sym = {{"select","itemID",
					11303,	-- Fine Shortbow
					3027,	-- Heavy Recurve Bow
					11307,	-- Massive Longbow
					3026,	-- Reinforced Bow
					11306,	-- Sturdy Recurve
				}},
			}),
			n(4610, {	-- Algernon <Alchemy Supplies>
				coord = { 51.8, 74.6, MAP.UNDERCITY },
				races = HORDE_ONLY,
				groups = {
					i(9301, {	-- Recipe: Elixir of Shadow Power (RECIPE!)
						isLimited = true,
					}),
					i(13477, {	-- Recipe: Superior Mana Potion (RECIPE!)
						isLimited = true,
					}),
				},
			}),
			n(4602, {	-- Benijah Fenner
				coord = { 58.6, 32.6, MAP.UNDERCITY },
				races = HORDE_ONLY,
				sym = {{"select","itemID",
					15808,	-- Fine Light Crossbow
					925,	-- Flail
					1197,	-- Giant Mace
					2030,	-- Gnarled Staff
					2028,	-- Hammer
					15809,	-- Heavy Crossbow
					15807,	-- Light Crossbow
					928,	-- Long Staff
					852,	-- Mace
					924,	-- Maul
					854,	-- Quarter Staff
					2026,	-- Rock Hammer
				}},
			}),
			n(4612, {	-- Boyle <Sludge Seller>
				coord = { 56.2, 64.6, MAP.UNDERCITY },
				races = HORDE_ONLY,
				groups = {
					i(278265, {	-- Nutritious Slime Sludge
						timeline = { TIMELINE.ADDED_1_60_1 },
					}),
				},
			}),
			n(4569, {	-- Charles Seaton <Blade Merchant>
				coord = { 77.0, 50.0, MAP.UNDERCITY },
				races = HORDE_ONLY,
				sym = {{"select","itemID",
					-- added all
					1198,	-- Claymore
					851,	-- Cutlass
					922,	-- Dacian Falx
					2024,	-- Espadon
					2207,	-- Jambiya
					2209,	-- Kris
					923,	-- Longsword
					2208,	-- Poniard
					2027,	-- Scimitar
				}},
			}),
			n(4561, {	-- Daniel Bartlett <General Trade Supplier>
				coord = { 64.0, 37.4, MAP.UNDERCITY },
				races = HORDE_ONLY,
				sym = {{ "select", "itemID",
					277113,	-- Apprentice's Herb Pouch
					277115,	-- Apprentice's Mining Pack
					277114,	-- Apprentice's Skinning Satchel
					2325,	-- Black Dye
					5956,	-- Blacksmith Hammer
					2324,	-- Bleach
					6260,	-- Blue Dye
					6532,	-- Bright Baubles
					3857,	-- Coal
					2320,	-- Coarse Thread
					6217,	-- Copper Rod
					8925,	-- Crystal Vial
					3371,	-- Empty Vial
					2321,	-- Fine Thread
					6256,	-- Fishing Pole
					2605,	-- Green Dye
					4340,	-- Grey Dye
					8343,	-- Heavy Silken Thread
					4400,	-- Heavy Stock
					2692,	-- Hot Spices
					3372,	-- Leaded Vial
					2678,	-- Mild Spices
					2901,	-- Mining Pick
					6530,	-- Nightcrawlers
					4342,	-- Purple Dye
					2604,	-- Red Dye
					4289,	-- Salt
					6529,	-- Shiny Bauble
					4536,	-- Shiny Red Apple
					4291,	-- Silken Thread
					7005,	-- Skinning Knife
					3713,	-- Soothing Spices
					3466,	-- Strong Flux
					2880,	-- Weak Flux
					4399,	-- Wooden Stock
					4341,	-- Yellow Dye
				}},
				groups = {
					i(16217, {	-- Formula: Enchant Shield - Greater Stamina (RECIPE!)
						isLimited = true,
					}),
				},
			}),
			n(4555, {	-- Eleanor Rusk <General Goods>
				coord = { 69.2, 48.9, MAP.UNDERCITY },	-- Trade Quarter
				races = HORDE_ONLY,
				sym = {
					SymSelector.select("VENDOR_FOOD_DRINK"),	-- Drink
					{ "pop" },
					{ "select", "itemID",
						11284,	-- Accurate Slugs
						2946,	-- Balanced Throwing Dagger
						4498,	-- Brown Leather Satchel
						3137,	-- Deadly Throwing Axe
						15326,	-- Gleaming Throwing Axe
						4497,	-- Heavy Brown Bag
						2519,	-- Heavy Shot
						11285,	-- Jagged Arrow
						3107,	-- Keen Throwing Knife
						2516,	-- Light Shot
						3030,	-- Razor Arrow
						2512,	-- Rough Arrow
						2515,	-- Sharp Arrow
						3135,	-- Sharp Throwing Axe
						4470,	-- Simple Wood
						4496,	-- Small Brown Pouch
						3033,	-- Solid Shot
						11291,	-- Star Wood
						3131,	-- Weighted Throwing Axe
						15327,	-- Wicked Throwing Dagger
					},
				},
			}),
			n(4585, {	-- Ezekiel
				coord = { 75.6, 51.6, MAP.UNDERCITY },
				races = HORDE_ONLY,
			}),
			n(4775, {	-- Felicia Doan <Trade Supplies>
				coord = { 64.1, 50.6, MAP.UNDERCITY },
				races = HORDE_ONLY,
				sym = {{ "select", "itemID",
					277113,	-- Apprentice's Herb Pouch
					277115,	-- Apprentice's Mining Pack
					277114,	-- Apprentice's Skinning Satchel
					5956,	-- Blacksmith Hammer
					2324,	-- Bleach
					6260,	-- Blue Dye
					6532,	-- Bright Baubles
					3857,	-- Coal
					2320,	-- Coarse Thread
					6217,	-- Copper Rod
					8925,	-- Crystal Vial
					3371,	-- Empty Vial
					2321,	-- Fine Thread
					6256,	-- Fishing Pole
					2605,	-- Green Dye
					4400,	-- Heavy Stock
					2692,	-- Hot Spices
					3372,	-- Leaded Vial
					2678,	-- Mild Spices
					2901,	-- Mining Pick
					6530,	-- Nightcrawlers
					2604,	-- Red Dye
					4289,	-- Salt
					6529,	-- Shiny Bauble
					4536,	-- Shiny Red Apple
					4291,	-- Silken Thread
					7005,	-- Skinning Knife
					3713,	-- Soothing Spices
					3466,	-- Strong Flux
					2880,	-- Weak Flux
					4399,	-- Wooden Stock
				}},
			}),
			n(4601, {	-- Francis Eliot
				coord = { 58.6, 32.6, MAP.UNDERCITY },
				races = HORDE_ONLY,
				sym = {{"select","itemID",
					926,	-- Battle Axe
					2025,	-- Bearded Axe
					2029,	-- Cleaver
					927,	-- Double Axe
					853,	-- Hatchet
					15811,	-- Heavy Spear
					15810,	-- Short Spear
					1196,	-- Tabar
				}},
			}),
			n(4600, {	-- Geoffrey Hartwell
				coord = { 58.4, 32.6, MAP.UNDERCITY },
				races = HORDE_ONLY,
				sym = {{"select","itemID",
					2520,	-- Broadsword
					2523,	-- Bullova
					2528,	-- Falchion
					2521,	-- Flamberge
					2531,	-- Great Axe
					2526,	-- Main Gauche
					2534,	-- Rondel
					2525,	-- War Hammer
					2533,	-- War Maul
					2529,	-- Zweihander
				}},
			}),
			n(5820, {	-- Gillian Moore
				coord = { 70.6, 59.6, MAP.UNDERCITY },
				races = HORDE_ONLY,
				sym = {
					{ "select", "symselector",
						SymSelector.VENDOR_CUIRBOULLI,	-- Cuirboulli
						SymSelector.VENDOR_CURED_LEATHER,	-- Cured Leather
						SymSelector.VENDOR_REINFORCED_LEATHER,	-- Reinforced Leather
						SymSelector.VENDOR_ROUGH_LEATHER,	-- Rough Leather
						SymSelector.VENDOR_STUDDED,	-- Studded
						SymSelector.VENDOR_TANNED_LEATHER,	-- Tanned Leather
					},
					{ "pop" },
					{ "select", "itemID",
						2463,	-- Studded Doublet
					},
				},
			}),
			n(4556, {	-- Gordon Wendham
				coord = { 61.4, 41.2, MAP.UNDERCITY },
				races = HORDE_ONLY,
				sym = {{"select","itemID",
					1194,	-- Bastard Sword
					2479,	-- Broad Axe
					2130,	-- Club
					2492,	-- Cudgel
					2139,	-- Dirk
					2488,	-- Gladius
					2134,	-- Hand Axe
					2491,	-- Large Axe
					2480,	-- Large Club
					2132,	-- Short Staff
					2131,	-- Shortsword
					2494,	-- Stiletto
					2490,	-- Tomahawk
					2489,	-- Two-Handed Sword
					2495,	-- Walking Stick
					2493,	-- Wooden Mallet
				}},
			}),
			n(8403, {	-- Jeremiah Payson <Cockroach Vendor>
				coord = { 67.6, 44.1, MAP.UNDERCITY },
				races = HORDE_ONLY,
				groups = {
					i(280697, {	-- Plagued Cockroach (PET!)
						timeline = { TIMELINE.ADDED_1_60_1 },
					}),
					i(280699, {	-- Undercity Cockroach (PET!)
						timeline = { TIMELINE.ADDED_1_60_1 },
					}),
					i(10393),	-- Undercity Cockroach (PET!)
				},
			}),
			n(4589, {	-- Joseph Moore <Leatherworking Supplies>
				coord = { 70.1, 58.4, MAP.UNDERCITY },
				races = HORDE_ONLY,
				sym = { {"sub", "common_vendor", 5565} },	-- Jillian Tanner <Leatherworking Supplies>
				groups = {
					i(18949, {	-- Pattern: Barbaric Bracers (RECIPE!)
						isLimited = true,
					}),
					i(7451, {	-- Pattern: Green Whelp Bracers (RECIPE!)
						isLimited = true,
					}),
				},
			}),
			n(4615, {	-- Katrina Alliestar <Herbalism Supplier>
				coord = { 54.73, 48.9, MAP.UNDERCITY },
				races = HORDE_ONLY,
				sym = {{ "select", "itemID",
					22250,	-- Herb Pouch
				}},
			}),
			n(4558, {	-- Lauren Newcomb <Light Armor Merchant>
				coord = { 64.0, 38.0, MAP.UNDERCITY },
				races = HORDE_ONLY,
				sym = {
					{ "select", "symselector",
						SymSelector.VENDOR_BATTERED_LEATHER,	-- Battered Leather
						SymSelector.VENDOR_DIRTY_LEATHER,	-- Dirty Leather
						SymSelector.VENDOR_HEAVY_WEAVE,	-- Heavy Weave
						SymSelector.VENDOR_TANNED_LEATHER,	-- Tanned Leather
						SymSelector.VENDOR_TATTERED_CLOTH,	-- Tattered Cloth
						SymSelector.VENDOR_WOVEN,	-- Woven
					},
					{ "pop" },
					{ "select", "itemID",
						2370,	-- Battered Leather Harness
						16059,	-- Common Brown Shirt
						3428,	-- Common Gray Shirt
						16060,	-- Common White Shirt
					},
				},
			}),
			n(4574, {	-- Lizbeth Cromwell <Fishing Supplier>
				coord = { 81.0, 30.8, MAP.UNDERCITY },
				races = HORDE_ONLY,
				groups = {
					i(6325),	-- Recipe: Brilliant Smallfish (RECIPE!)
					i(6328),	-- Recipe: Longjaw Mud Snapper (RECIPE!)
					i(17062),	-- Recipe: Mithril Head Trout (RECIPE!)
					i(6369),	-- Recipe: Rockscale Cod (RECIPE!)
				},
			}),
			n(4557, {	-- Louis Warren
				coord = { 62.0, 41.2, MAP.UNDERCITY },
				races = HORDE_ONLY,
				sym = {{"select","itemID",
					2025,	-- Bearded Axe
					1198,	-- Claymore
					2029,	-- Cleaver
					851,	-- Cutlass
					2024,	-- Espadon
					1197,	-- Giant Mace
					2030,	-- Gnarled Staff
					2028,	-- Hammer
					853,	-- Hatchet
					2207,	-- Jambiya
					852,	-- Mace
					2208,	-- Poniard
					854,	-- Quarter Staff
					2026,	-- Rock Hammer
					2027,	-- Scimitar
					1196,	-- Tabar
				}},
			}),
			n(4580, {	-- Lucille Castleton
				coord = { 71.4, 28.4, MAP.UNDERCITY },
				races = HORDE_ONLY,
				sym = {
					SymSelector.select("VENDOR_ROBES"),	-- Robes
					{ "pop" },
				},
			}),
			n(5190, {	-- Merill Pleasance <Tabard Vendor>
				coord = { 69.3, 44.8, MAP.UNDERCITY },
				races = HORDE_ONLY,
				sym = {{ "select", "itemID", 5976 }},	-- Guild Tabard
			}),
			n(4577, {	-- Millie Gregorian <Tailoring Supplies>
				coord = { 70.6, 30.1, MAP.UNDERCITY },
				races = HORDE_ONLY,
				groups = sharedData({
					isLimited = true,
				}, {
					i(6275),	-- Pattern: Greater Adept's Robe (RECIPE!)
					i(5772),	-- Pattern: Red Woolen Bag (RECIPE!)
					i(10326),	-- Pattern: Tuxedo Jacket (RECIPE!)
					i(10323),	-- Pattern: Tuxedo Pants (RECIPE!)
					i(10321),	-- Pattern: Tuxedo Shirt (RECIPE!)
				}),
			}),
			n(5819, {	-- Mirelle Tremayne
				coord = { 61.6, 28.4, MAP.UNDERCITY },
				races = HORDE_ONLY,
				sym = {
					{ "select", "symselector",
						SymSelector.VENDOR_AUGMENTED_CHAIN,	-- Augmented Chain
						SymSelector.VENDOR_BRIGANDINE,	-- Brigandine
						SymSelector.VENDOR_CHAINMAIL,	-- Chainmail
						SymSelector.VENDOR_LIGHT_MAIL,	-- Light Mail
						SymSelector.VENDOR_PLATEMAIL,	-- Platemail
						SymSelector.VENDOR_POLISHED_SCALE,	-- Polished Scale
						SymSelector.VENDOR_SCALEMAIL,	-- Scalemail
					},
					{ "pop" },
					{ "select", "itemID",
						2451,	-- Crested Heater Shield
						2448,	-- Heavy Pavise
						2446,	-- Kite Shield
						17189,	-- Metal Buckler
						17190,	-- Ornate Buckler
						17192,	-- Reinforced Targe
					},
				},
			}),
			n(4592, {	-- Nathaniel Steenwick
				coord = { 77.2, 50.2, MAP.UNDERCITY },
				races = HORDE_ONLY,
				sym = {{"select","itemID",
					3027,	-- Heavy Recurve Bow
					2506,	-- Hornwood Recurve Bow
					2507,	-- Laminated Recurve Bow
					2505,	-- Polished Shortbow
					3026,	-- Reinforced Bow
					2504,	-- Worn Shortbow
				}},
			}),
			n(4603, {	-- Nicholas Atwood
				coord = { 62.2, 27.0, MAP.UNDERCITY },
				races = HORDE_ONLY,
				sym = {{"select","itemID",
					3024,	-- BKP 2700 "Enforcer"
					3023,	-- Large Bore Blunderbuss
					2509,	-- Ornate Blunderbuss
					2510,	-- Solid Blunderbuss
				}},
			}),
			n(4553, {	-- Ronald Burch <Cooking Supplier>
				coord = { 62.3, 43.1, MAP.UNDERCITY },
				races = HORDE_ONLY,
				sym = {{ "select", "itemID",
					2692,	-- Hot Spices
					2678,	-- Mild Spices
					6330,	-- Recipe: Bristle Whisker Catfish (RECIPE!)
					6368,	-- Recipe: Rainbow Fin Albacore (RECIPE!)
					21219,	-- Recipe: Sagefish Delight (RECIPE!)
					21099,	-- Recipe: Smoked Sagefish (RECIPE!)
					159,	-- Refreshing Spring Water
					4536,	-- Shiny Red Apple
					10284,	-- Simple Flour
					4470,	-- Simple Wood
					3713,	-- Soothing Spices
					11291,	-- Star Wood
					272941,	-- Thick Logs
				}},
			}),
			n(4597, {	-- Samuel Van Brunt <Blacksmithing Supplies>
				coord = { 61.4, 30.1, MAP.UNDERCITY },
				races = HORDE_ONLY,
			}),
			n(4599, {	-- Sarah Killan <Mining Supplies>
				coord = { 56.6, 37.3, MAP.UNDERCITY },
				races = HORDE_ONLY,
				sym = {{ "select", "itemID",
					2901,	-- Mining Pick
				}},
			}),
			n(5821, {	-- Sheldon Von Croy <Cloth Armor Merchant>
				coord = { 70.6, 28.8, MAP.UNDERCITY },
				races = HORDE_ONLY,
				sym = {
					{ "select", "symselector",
						SymSelector.VENDOR_EMBROIDERED,	-- Embroidered
						SymSelector.VENDOR_HEAVY_WEAVE,	-- Heavy Weave
						SymSelector.VENDOR_KNITTED,	-- Knitted
						SymSelector.VENDOR_PADDED,	-- Padded
						SymSelector.VENDOR_RUSSET,	-- Russet
						SymSelector.VENDOR_THICK_CLOTH,	-- Thick Cloth
					},
					{ "pop" },
				},
				groups = {
					i(13896),	-- Dark Green Wedding Hanbok
					i(13898),	-- Royal Dangui
					i(13897),	-- White Traditional Hanbok
				},
			}),
			n(4570, {	-- Sydney Upton <Staff Merchant>
				coord = { 69.8, 27.4, MAP.UNDERCITY },
				races = HORDE_ONLY,
				sym = {{"select","itemID",
					2527,	-- Battle Staff
					2535,	-- War Staff
				}},
			}),
			n(4554, {	-- Tawny Grisette <Mushroom Vendor>
				coord = { 69.7, 44.8, MAP.UNDERCITY },
				description = "Walks around the Trade Quarter, upper level.",
				races = HORDE_ONLY,
				sym = {
					SymSelector.select("VENDOR_FOOD_MUSHROOM"),	-- Mushroom
					{ "pop" },
				},
			}),
			n(4617, {	-- Thaddeus Webb <Enchanting Supplies>
				coord = { 62.0, 60.8, MAP.UNDERCITY },
				races = HORDE_ONLY,
				sym = {
					SymSelector.select("VENDOR_ENCHANTING_RECIPES"),
					{"pop"},
				},
			}),
			n(4559, {	-- Timothy Weldon
				coord = { 63.6, 39.6, MAP.UNDERCITY },
				races = HORDE_ONLY,
				sym = {
					{ "select", "symselector",
						SymSelector.VENDOR_LIGHT_CHAIN,	-- Light Chain
						SymSelector.VENDOR_RUSTED_CHAIN,	-- Rusted Chain
					},
					{ "pop" },
					{ "select", "itemID",
						17187,	-- Banded Buckler
						17183,	-- Dented Buckler
						1200,	-- Large Wooden Shield
						17185,	-- Round Buckler
						1202,	-- Wall Shield
						2376,	-- Worn Heater Shield
					},
				},
			}),
			n(4560, {	-- Walter Ellingson
				coord = { 62.8, 39.6, MAP.UNDERCITY },
				races = HORDE_ONLY,
				sym = {
					SymSelector.select("VENDOR_CHAINMAIL"),	-- Chainmail
					{ "pop" },
					{ "select", "itemID",
						17187,	-- Banded Buckler
						1202,	-- Wall Shield
					},
				},
			}),
			n(5754, {	-- Zane Bradford
				coord = { 70.0, 27.2, MAP.UNDERCITY },
				races = HORDE_ONLY,
				sym = {{"select", "itemID",
					5239,	-- Blackbone Wand
					5210,	-- Burning Wand
					5236,	-- Combustible Wand
					5211,	-- Dusk Wand
					5209,	-- Gloom Wand
					5347,	-- Pestilent Wand
					5238,	-- Pitchwood Wand
					5208,	-- Smoldering Wand
				}},
			}),
		}),
	},
});
root(ROOTS.HiddenQuestTriggers, {
	q(5659, {	-- <NYI> Touch of Weakness
		description = "Never implemented as a real quest. Likely gets marked as completed alongside any of the 'Touch of Weakness' Undead Priest quests (5658, 5660-5663).",
		timeline = { TIMELINE.ADDED_1_60_1 },
		classes = { PRIEST },
		races = { UNDEAD },
	}),
});
