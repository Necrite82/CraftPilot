---------------------------------------------------
--          Z O N E S        M O D U L E         --
---------------------------------------------------
-- CRIEVE NOTE: Don't touch this file without asking.
-- Burden of Truth: Classic & TBC.
maproot(MAP.EASTERN_KINGDOMS, DEEPRUN_TRAM, {
	lore = "The Deeprun Tram is a long, fully enclosed, underground (and partially underwater) set of double tracks upon which rolls two sets of three wagons, all credited to the gnomes' technical engineering. The service is fast and smooth, and is provided free of charge to travelers between the Alliance-aligned cities of Ironforge and Stormwind City.",
	zoneTextAreaID = 2257,	-- Deeprun Tram's mapID doesn't exist until later as well, maybe Cataclysm?
	icon = 133861,
	groups = {
		n(VENDORS, {
			n(13018, {	-- Nipsy
				races = ALLIANCE_ONLY,
				groups = {
					i(17119),	-- Deeprun Rat Kabob
				},
			}),
		}),
		n(QUESTS, {
			q(6661, {	-- Deeprun Rat Roundup
				qg = 12997,	-- Monty
				races = ALLIANCE_ONLY,
				lvl = 10,
				groups = {
					objective(1, {	-- 0/5 Rats Captured
						provider = { "i", 17117 },	-- Rat Catcher's Flute
						cr = 13016,	-- Deeprun Rat
					}),
				},
			}),
			q(6662, {	-- Me Brother, Nipsy
				sourceQuest = 6661,	-- Deeprun Rat Roundup
				qg = 12997,	-- Monty
				qi = 17118,	-- Carton of Mystery Meat
				races = ALLIANCE_ONLY,
				lvl = 10,
				sym = {{ "select", "itemID", 17119 }},	-- Deeprun Rat Kabob
			}),
		}),
	},
});
