---------------------------------------------------
--          Z O N E S        M O D U L E         --
---------------------------------------------------

maproot(MAP.KALIMDOR, MAP.DUROTAR, {
	lore = "Once the home of the savage quilboar, the Horde arrived on Kalimdor's shore and, in the aftermath of the Third War, drove the quilboar from the land and established this region as its own. Warchief Thrall named the new nation after his father, Durotan, and rules ably. Horde settlements are scattered throughout the rocky land, which is only marginally more fertile than the Barrens.\n\nThe Horde's greatest city is Orgrimmar, a warrior city that symbolizes the greatness of the orcs and their allies. Much of Durotar remains wild, and the orcs continually fend off centaur and quilboar as they attempt to tame the land.",
	icon = 236756,
	groups = {
		m(VALLEY_OF_TRIALS, {
			lore = "The Valley of Trials in southern Durotar is where all young orc adventurers begin their journey. Within the valley, they are safe from external threats while taking on challenges that enable them to get used to their new status as recruits of the Horde.",
			icon = 236452,
			zoneTextAreaIDs = {
				363,	-- Valley of Trials
				364,	-- The Den
				365,	-- Burning Blade Coven
			},
			groups = {
				n(QUESTS, {
					q(794, {	-- Burning Blade Medallion
						sourceQuests = {
							792,	-- Vile Familiars
							1499,	-- Vile Familiars (Part 2 - Warlocks only!)
						},
						qg = 3145,	-- Zureetha Fargaze
						coord = { 42.8, 69.0, MAP.DUROTAR },
						races = HORDE_ONLY,
						groups = {
							objective(1, {	-- 0/1 Burning Blade Medallion
								provider = { "i", 4859 },	-- Burning Blade Medallion
								coord = { 42.8, 52.6, MAP.DUROTAR },
								cr = 3183,	-- Yarrog Baneshadow
							}),
							i(4921),	-- Dust-covered Leggings
							i(4922),	-- Jagged Chain Vest
							i(6713),	-- Ripped Pants
						},
					}),
					q(1516, {	-- Call of Earth (1/3)
						altQuests = { 1519 },	-- Call to Earth (1/3 Mulgore)
						qg = 5887,	-- Canaga Earthcaller
						coord = { 42.4, 69.0, MAP.DUROTAR },
						races = HORDE_ONLY,
						classes = { SHAMAN },
						lvl = 4,
						groups = {
							objective(1, {	-- 0/2 Felstalker Hoof
								provider = { "i", 6640 },	-- Felstalker Hoof
								cr = 3102,	-- Felstalker
							}),
						},
					}),
					q(1517, {	-- Call of Earth (2/3)
						sourceQuest = 1516,	-- Call of Earth (1/3)
						altQuests = { 1520 },	-- Call to Earth (2/3 Mulgore)
						qg = 5887,	-- Canaga Earthcaller
						qi = 6635,	-- Earth Sapta
						coord = { 42.4, 69.0, MAP.DUROTAR },
						races = HORDE_ONLY,
						classes = { SHAMAN },
						lvl = 4,
					}),
					q(1518, {	-- Call of Earth (3/3)
						sourceQuest = 1517,	-- Call of Earth (2/3)
						altQuests = { 1521 },	-- Call to Earth (3/3 Mulgore)
						qg = 5891,	-- Minor Manifestation of Earth
						qi = 6656,	-- Rough Quartz
						coord = { 44.0, 76.0, MAP.DUROTAR },
						races = HORDE_ONLY,
						classes = { SHAMAN },
						lvl = 4,
						groups = {
							recipe(8071),	-- Stoneskin Totem
							i(5175, {	-- Earth Totem
								description = "You must keep this in your bags forever.",
							}),
						},
					}),
					q(788, {	-- Cutting Teeth
						sourceQuest = 4641,	-- Your Place In The World
						qg = 3143,	-- Gornek
						coord = { 42.0, 68.4, MAP.DUROTAR },
						races = HORDE_ONLY,
						groups = {
							objective(1, {	-- 0/10 (8 in Wrath) Mottled Boar
								provider = { "n", 3098 },	-- Mottled Boar
							}),
							i(4915),	-- Soft Wool Boots
							i(4914),	-- Battleworn Leather Gloves
						},
					}),
					q(1463, {	-- Earth Sapta
						sourceQuest = 1516,	-- Call of Earth (1/3)
						qg = 5887,	-- Canaga Earthcaller
						coord = { 42.4, 69.0, MAP.DUROTAR },
						races = HORDE_ONLY,
						classes = { SHAMAN },
						repeatable = true,
						lvl = 4,
						groups = {
							i(6635),	-- Earth Sapta
						},
					}),
					q(3088, {	-- Encrypted Parchment
						sourceQuest = 788,	-- Cutting Teeth
						qg = 3143,	-- Gornek
						qi = 9560,	-- Encrypted Parchment
						coord = { 42.0, 68.4, MAP.DUROTAR },
						races = { ORC },
						classes = { ROGUE },
					}),
					q(3083, {	-- Encrypted Tablet
						sourceQuest = 788,	-- Cutting Teeth
						qg = 3143,	-- Gornek
						qi = 9554,	-- Encrypted Tablet
						coord = { 42.0, 68.4, MAP.DUROTAR },
						races = { TROLL },
						classes = { ROGUE },
					}),
					q(3087, {	-- Etched Parchment
						sourceQuest = 788,	-- Cutting Teeth
						qg = 3143,	-- Gornek
						qi = 9553,	-- Etched Parchment
						coord = { 42.0, 68.4, MAP.DUROTAR },
						races = { ORC },
						classes = { HUNTER },
					}),
					q(3082, {	-- Etched Tablet
						sourceQuest = 788,	-- Cutting Teeth
						qg = 3143,	-- Gornek
						qi = 9564,	-- Etched Tablet
						coord = { 42.0, 68.4, MAP.DUROTAR },
						races = { TROLL },
						classes = { HUNTER },
					}),
					q(4402, {	-- Galgar's Cactus Apple Surprise
						sourceQuest = 788,	-- Cutting Teeth
						qg = 9796,	-- Galgar
						coord = { 42.6, 67.2, MAP.DUROTAR },
						races = HORDE_ONLY,
						groups = {
							objective(1, {	-- 0/10 Cactus Apple
								providers = {
									{ "i",  11583 },	-- Cactus Apple
									{ "o", 171938 },	-- Cactus Apple
								},
							}),
							i(247840, {	-- Mining for Dummies
								timeline = { TIMELINE.ADDED_1_60_1 },
							}),
							i(247841, {	-- Wild Harvest
								timeline = { TIMELINE.ADDED_1_60_1 },
							}),
							i(247846, {	-- Pelt Collecting for Beginners
								timeline = { TIMELINE.ADDED_1_60_1 },
							}),
							i(11584),	-- Cactus Apple Surprise
						},
					}),
					q(98576, {	-- Glyphic Parchment
						qg = 3143,	-- Gornek
						coord = { 42.06, 68.33, MAP.DUROTAR },
						races = { ORC },
						classes = { MAGE },
						timeline = { TIMELINE.ADDED_1_60_1 },
						qi = 282380,	-- Glyphic Parchment (QI!)
					}),
					q(3086, {	-- Glyphic Tablet
						sourceQuest = 788,	-- Cutting Teeth
						qg = 3143,	-- Gornek
						qi = 9575,	-- Glyphic Tablet
						coord = { 42.0, 68.4, MAP.DUROTAR },
						races = { TROLL },
						classes = { MAGE },
					}),
					q(3085, {	-- Hallowed Tablet
						sourceQuest = 788,	-- Cutting Teeth
						qg = 3143,	-- Gornek
						qi = 9561,	-- Hallowed Tablet
						coord = { 42.0, 68.4, MAP.DUROTAR },
						races = { TROLL },
						classes = { PRIEST },
					}),
					q(5649, {	-- In Favor of Spirituality
						qg = 3707,	-- Ken'jai
						coord = { 42.4, 68.8, MAP.DUROTAR },
						races = { TROLL },
						classes = { PRIEST },
						lvl = 5,
					}),
					q(5441, {	-- Lazy Peons
						qg = 11378,	-- Foreman Thazz'ril
						coord = { 44.6, 68.6, MAP.DUROTAR },
						races = HORDE_ONLY,
						lvl = 3,
						groups = {
							objective(1, {	-- 0/5 Peons Awoken
								provider = { "i", 16114 },	-- Foreman's Blackjack
								cr = 10556,	-- Lazy Peon
							}),
						},
					}),
					q(805, {	-- Report to Sen'jin Village
						sourceQuest = 794,	-- Burning Blade Medallion
						qg = 3145,	-- Zureetha Fargaze
						coord = { 42.8, 69.0, MAP.DUROTAR },
						races = HORDE_ONLY,
					}),
					q(3089, {	-- Rune-Inscribed Parchment
						sourceQuest = 788,	-- Cutting Teeth
						qg = 3143,	-- Gornek
						qi = 9568,	-- Rune-Inscribed Parchment
						coord = { 42.0, 68.4, MAP.DUROTAR },
						races = { ORC },
						classes = { SHAMAN },
					}),
					q(3084, {	-- Rune-Inscribed Tablet
						sourceQuest = 788,	-- Cutting Teeth
						qg = 3143,	-- Gornek
						qi = 9562,	-- Rune-Inscribed Tablet
						coord = { 42.0, 68.4, MAP.DUROTAR },
						races = { TROLL },
						classes = { SHAMAN },
					}),
					q(790, {	-- Sarkoth (1/2)
						qg = 3287,	-- Hana'zua
						coord = { 40.6, 62.6, MAP.DUROTAR },
						races = HORDE_ONLY,
						groups = {
							objective(1, {	-- 0/1 Sarkoth's Mangled Claw
								provider = { "i", 4905 },	-- Sarkoth's Mangled Claw
								coord = { 40.6, 66.6, MAP.DUROTAR },
								cr = 3281,	-- Sarkoth
							}),
						},
					}),
					q(804, {	-- Sarkoth (2/2)
						sourceQuest = 790,	-- Sarkoth (1/2)
						qg = 3287,	-- Hana'zua
						coord = { 40.6, 62.6, MAP.DUROTAR },
						races = HORDE_ONLY,
						groups = {
							i(4916),	-- Soft Wool Vest
							i(4917),	-- Battleworn Chain Leggings
						},
					}),
					q(2383, {	-- Simple Parchment
						sourceQuest = 788,	-- Cutting Teeth
						qg = 3143,	-- Gornek
						qi = 12635,	-- Simple Parchment
						coord = { 42.0, 68.4, MAP.DUROTAR },
						races = { ORC },
						classes = { WARRIOR },
					}),
					q(3065, {	-- Simple Tablet
						sourceQuest = 788,	-- Cutting Teeth
						qg = 3143,	-- Gornek
						qi = 6488,	-- Simple Tablet
						coord = { 42.0, 68.4, MAP.DUROTAR },
						races = { TROLL },
						classes = { WARRIOR },
					}),
					q(789, {	-- Sting of the Scorpid
						sourceQuest = 788,	-- Cutting Teeth
						qg = 3143,	-- Gornek
						coord = { 42.0, 68.4, MAP.DUROTAR },
						races = HORDE_ONLY,
						groups = {
							objective(1, {	-- 0/10 Scorpid Worker Tail
								provider = { "i", 4862 },	-- Scorpid Worker Tail
								crs = {
									3281,	-- Sarkoth
									3124,	-- Scorpid Worker
								},
							}),
							i(4919),	-- Soft Wool Belt
							i(4920),	-- Battleworn Cape
						},
					}),
					q(3090, {	-- Tainted Parchment
						sourceQuest = 788,	-- Cutting Teeth
						qg = 3143,	-- Gornek
						qi = 9579,	-- Tainted Parchment
						coords = { 42.0, 68.4, MAP.DUROTAR },
						races = { ORC },
						classes = { WARLOCK },
					}),
					q(98575, {	-- Tainted Tablet
						qg = 3143,	-- Gornek
						coord = { 42.06, 68.33, MAP.DUROTAR },
						races = { TROLL },
						classes = { WARLOCK },
						timeline = { TIMELINE.ADDED_1_60_1 },
						qi = 282346,	-- Tainted Tablet (QI!)
					}),
					q(6394, {	-- Thazz'ril's Pick
						sourceQuest = 5441,	-- Lazy Peons
						qg = 11378,	-- Foreman Thazz'ril
						coord = { 44.6, 68.6, MAP.DUROTAR },
						races = HORDE_ONLY,
						lvl = 3,
						groups = {
							objective(1, {	-- 0/1 Thazz'ril's Pick
								providers = {
									{ "i",  16332 },	-- Thazz'ril's Pick
									{ "o", 178087 },	-- Thazz'ril's Pick
								},
								coord = { 43.8, 53.8, MAP.DUROTAR },
							}),
						},
					}),
					q(96652, {	-- The Adventurer [Durotar]
						sourceQuest = 794,	-- Burning Blade Medallion
						altQuests = {
							96627,	-- The Adventurer [Elwynn Forest]
							96628,	-- The Adventurer [Dun Morogh]
							96630,	-- The Adventurer [Teldrassil]
							96638,	-- The Adventurer [Zephras Isle]
							96656,	-- The Adventurer [Tirisfal Glades]
							96659,	-- The Adventurer [Mulgore]
						},
						provider = { "o", 654925 },	-- Lost Journal
						coord = { 42.82, 69.14, MAP.DUROTAR },
						races = HORDE_ONLY,
						lvl = 4,
						isBreadcrumb = true,
						timeline = { TIMELINE.ADDED_1_60_1 },
						qi = 275022,	-- Lost Journal (QI!)
					}),
					q(792, {	-- Vile Familiars
						qg = 3145,	-- Zureetha Fargaze
						coord = { 42.85, 69.14, MAP.DUROTAR },
						classes = exclude(WARLOCK, ALL_CLASSES),
						races = HORDE_ONLY,
						lvl = 2,
						groups = {
							objective(1, {	-- 0/12 Vile Familiar
								provider = { "n", 3101 },	-- Vile Familiar
							}),
							i(12449, {	-- Primitive Bow
								timeline = { REMOVED_1_7_0 },	-- CRIEVE NOTE: This might be removed already, if so, get rid of it.
							}),
							i(4924),	-- Primitive Club
							i(4925),	-- Primitive Hand Blade
							i(4923),	-- Primitive Hatchet
							i(5778),	-- Primitive Walking Stick
						},
					}),
					q(1485, {	-- Vile Familiars (Part 1 - Warlocks only!)
						qg = 5765,	-- Ruzan
						coord = { 42.6, 69.0, MAP.DUROTAR },
						classes = { WARLOCK },
						races = HORDE_ONLY,
						groups = {
							objective(1, {	-- 0/8 Vile Familiar Head
								provider = { "i", 6487 },	-- Vile Familiar Head
								cr = 3101,	-- Vile Familiar
							}),
							recipe(688),	-- Summon Imp
						},
					}),
					q(1499, {	-- Vile Familiars (Part 2 - Warlocks only!)
						sourceQuest = 1485,	-- Vile Familiars (Part 1 - Warlocks only!)
						qg = 5765,	-- Ruzan
						coord = { 42.6, 69.0, MAP.DUROTAR },
						classes = { WARLOCK },
						races = HORDE_ONLY,
						groups = {
							i(4925),	-- Primitive Hand Blade
							i(5778),	-- Primitive Walking Stick
						},
					}),
					q(97279, {	-- Wayward Weapons
						qg = 3143,	-- Gornek
						coord = { 42.0, 68.4, MAP.DUROTAR },
						timeline = { TIMELINE.ADDED_1_60_1 },
						races = HORDE_ONLY,
						groups = {
							objective(1, {	-- 0/6 Abandoned Training Weapon
								providers = {
									{ "i", 277653 },	-- Abandoned Training Weapon
									{ "o", 673476 },	-- Abandoned Training Weapon
								},
							}),
						},
					}),
					q(4641, {	-- Your Place In The World
						altQuests = { 787 },	-- The New Horde
						qg = 10176,	-- Kaltunk
						coord = { 43.2, 68.4, MAP.DUROTAR },
						races = HORDE_ONLY,
						isBreadcrumb = true,
					}),
				}),
			},
		}),
		n(ACHIEVEMENTS, {
			ach(728),	-- Explore Durotar
		}),
		explorationHeader({
			exploration(370),	-- Drygulch Ravine
			exploration(368),	-- Echo Isles
			exploration(366),	-- Kolkar Crag
			exploration(1637),	-- Orgrimmar
			exploration(362),	-- Razor Hill
			exploration(816),	-- Razormane Grounds
			exploration(410),	-- Razorwind Canyon
			exploration(367),	-- Sen'jin Village
			exploration(817),	-- Skull Rock
			exploration(369),	-- Thunder Ridge
			exploration(372),	-- Tiragarde Keep
			exploration(363),	-- Valley of Trials
		}),
		n(PROFESSIONS, {
			prof(ALCHEMY, {
				n(3184, {	-- Miao'zan <Journeyman Alchemist>
					coord = { 55.4, 74.0, MAP.DUROTAR },
					races = HORDE_ONLY,
					sym = {
						SymSelector.select("ALCHEMY_APPRENTICE"),
						{"pop"},
					},
				}),
			}),
			prof(BLACKSMITHING, {
				n(3174, {	-- Dwukk <Journeyman Blacksmith>
					coord = { 52.0, 40.6, MAP.DUROTAR },
					races = HORDE_ONLY,
					sym = {
						SymSelector.select("BLACKSMITHING_APPRENTICE"),
						{"pop"},
					},
				}),
			}),
			prof(COOKING, {
				n(3191, {	-- Cook Torka
					coord = { 51.2, 42.4, MAP.DUROTAR },
					races = HORDE_ONLY,
					sym = {
						SymSelector.select("COOKING_APPRENTICE"),
						SymSelector.select("COOKING_JOURNEYMAN"),
						SymSelector.select("COOKING_EXPERT"),
						SymSelector.select("COOKING_ARTISAN"),
						{"pop"},
					},
				}),
			}),
			prof(ENCHANTING, {
				n(266881, {	-- Pa'zula <Journeyman Enchanter>
					coord = { 56.4, 73.6, MAP.DUROTAR },
					races = HORDE_ONLY,
					sym = {
						SymSelector.select("ENCHANTING_APPRENTICE"),
						{"pop"},
					},
				}),
			}),
			prof(ENGINEERING, {
				n(11025, {	-- Mukdrak <Journeyman Engineer>
					coord = { 52.2, 40.8, MAP.DUROTAR },
					races = HORDE_ONLY,
					sym = {
						SymSelector.select("ENGINEERING_APPRENTICE"),
						{"pop"},
					},
				}),
			}),
			prof(FIRST_AID, {
				n(5943, {	-- Rawrk <First Aid Trainer>
					coord = { 54.0, 42.0, MAP.DUROTAR },
					races = HORDE_ONLY,
					sym = {
						SymSelector.select("FIRST_AID_APPRENTICE"),
						SymSelector.select("FIRST_AID_JOURNEYMAN"),
						SymSelector.select("FIRST_AID_EXPERT"),
						{"pop"},
					},
				}),
			}),
			prof(FISHING, {
				n(5941, {	-- Lau'Tiki <Fisherman>
					coord = { 53.2, 81.4, MAP.DUROTAR },
					races = HORDE_ONLY,
					sym = {
						SymSelector.select("FISHING_APPRENTICE"),
						SymSelector.select("FISHING_JOURNEYMAN"),
						{"pop"},
					},
				}),
			}),
			prof(HERBALISM, {
				n(3185, {	-- Mishiki <Herbalist>
					coord = { 55.4, 75.0, MAP.DUROTAR },
					races = HORDE_ONLY,
					sym = {
						SymSelector.select("HERBALISM_APPRENTICE"),
						SymSelector.select("HERBALISM_JOURNEYMAN"),
						SymSelector.select("HERBALISM_EXPERT"),
						SymSelector.select("HERBALISM_ARTISAN"),
						{"pop"},
					},
				}),
				n(267329, {	-- Zor'la <Junior Herbalism Trainer>
					coord = { 42.6, 67.4, MAP.DUROTAR },
					races = HORDE_ONLY,
					sym = {
						SymSelector.select("HERBALISM_APPRENTICE"),
						{"pop"},
					},
				}),
			}),
			prof(MINING, {
				n(3175, {	-- Krunn <Miner>
					coord = { 51.8, 40.8, MAP.DUROTAR },
					races = HORDE_ONLY,
					sym = {
						SymSelector.select("MINING_APPRENTICE"),
						SymSelector.select("MINING_JOURNEYMAN"),
						SymSelector.select("MINING_EXPERT"),
						SymSelector.select("MINING_ARTISAN"),
						{"pop"},
					},
				}),
				n(267328, {	-- Norzsh <Junior Mining Trainer>
					coord = { 40.4, 68.0, MAP.DUROTAR },
					races = HORDE_ONLY,
					sym = {
						SymSelector.select("MINING_APPRENTICE"),
						{"pop"},
					},
				}),
			}),
			prof(POISONS, {
				n(3170, {	-- Kaplak <Rogue Trainer>
					coord = { 52.0, 43.4, MAP.DUROTAR },
					races = HORDE_ONLY,
					sym = {
						SymSelector.select("POISONS_RECIPES"),
						{"pop"},
					},
				}),
			}),
			prof(SKINNING, {
				n(267327, {	-- Kagil <Junior Skinning Trainer>
					coord = { 40.8, 67.8, MAP.DUROTAR },
					races = HORDE_ONLY,
					sym = {
						SymSelector.select("SKINNING_APPRENTICE"),
						{"pop"},
					},
				}),
			}),
		}),
		n(QUESTS, {
			q(99048, {	-- A Missing Hand
				qg = 3142,	-- Orgnil Soulscar
				coord = { 52.2, 43.2, MAP.DUROTAR },
				timeline = { TIMELINE.ADDED_1_60_1 },
				races = HORDE_ONLY,
				lvl = 9,
			}),
			q(96873, {	-- A Pain in the Neck
				qg = 266881,	-- Pa'zula
				coord = { 56.6, 73.6, MAP.DUROTAR },
				timeline = { TIMELINE.ADDED_1_60_1 },
				requireSkill = ENCHANTING,
				races = HORDE_ONLY,
				lvl = 5,
				groups = {
					objective(1, {	-- 0/3 Luminous Residue
						provider = { "i", 247884 },	-- Luminous Residue
						cost = {{ "i", 275724, 3 }},	-- Hexed Pendant
					}),
				},
			}),
			q(2161, {	-- A Peon's Burden
				qg = 6786,	-- Ukor
				qi = 7629,	-- Ukor's Burden
				coord = { 52.0, 68.2, MAP.DUROTAR },
				races = HORDE_ONLY,
			}),
			q(97281, {	-- A Simmering Storm
				qs = 277661,	-- Dull Storm Orb (QS!)
				timeline = { TIMELINE.ADDED_1_60_1 },
				races = HORDE_ONLY,
				lvl = 7,
			}),
			q(818, {	-- A Solvent Spirit
				qg = 3304,	-- Master Vornal
				coord = { 55.8, 74.4, MAP.DUROTAR },
				races = HORDE_ONLY,
				lvl = 5,
				groups = {
					objective(1, {	-- 0/4 Intact Makrura Eye
						provider = { "i", 4887 },	-- Intact Makrura Eye
						crs = {
							3103,	-- Makrura Clacker
							3104,	-- Makrura Shellhide
							3105,	-- Makrura Snapclaw
							3141,	-- Makrura Elder
						},
					}),
					objective(2, {	-- 0/8 Crawler Mucus
						provider = { "i", 4888 },	-- Crawler Mucus
						crs = {
							3228,	-- Corrupted Surf Crawler
							3108,	-- Encrusted Surf Crawler
							3106,	-- Pygmy Surf Crawler
							3107,	-- Surf Crawler
						},
					}),
					i(4941),	-- Really Sticky Glue
				},
			}),
			q(809, {	-- Ak'Zeloth
				sourceQuest = 829,	-- Neeru Fireblade
				qg = 3216,	-- Neeru Fireblade
				coord = { 49.6, 50.4, MAP.ORGRIMMAR },
				races = HORDE_ONLY,
				lvl = 4,
			}),
			q(97223, {	-- Bloodtalon Matriarch
				qg = 7953,	-- Xar'Ti
				coord = { 55.2, 75.4, MAP.DUROTAR },
				timeline = { TIMELINE.ADDED_1_60_1 },
				races = HORDE_ONLY,
				lvl = 5,
				groups = {
					objective(1, {	-- 0/1 Bloodtalon Matriarch Eggs
						provider = { "i", 277128 },	-- Bloodtalon Matriarch Eggs
						coord = { 68.7, 71.3, MAP.DUROTAR },
						cr = 268530,	-- Bloodtalon Matriarch
					}),
					i(281267),	-- Raptorscale Pants
				},
			}),
			q(815, {	-- Break a Few Eggs
				qg = 3191,	-- Cook Torka
				coord = { 51.11, 42.45, MAP.DUROTAR },
				races = HORDE_ONLY,
				lvl = 6,
				groups = {
					objective(1, {	-- 0/3 Taillasher Egg
						providers = {
							{ "i", 4890 },	-- Taillasher Egg
							{ "o", 3240 },	-- Taillasher Eggs
						},
					}),
				},
			}),
			q(1843, {	-- Brutal Gauntlets
				sourceQuest = 1842,	-- Satyr Hooves
				qg = 6408,	-- Ula'elek
				coord = { 56.2, 74.4, MAP.DUROTAR },
				races = HORDE_ONLY,
				classes = { WARRIOR },
				lvl = 20,
				groups = {
					i(7129),	-- Brutal Gauntlets
				},
			}),
			q(832, {	-- Burning Shadows
				qs = 4903,	-- Eye of Burning Shadow (QS!)
				maps = { MAP.ORGRIMMAR },
				races = HORDE_ONLY,
				lvl = 4,
			}),
			q(97899, {	-- Camping 101: Alchemy [Durotar]
				sourceQuest = 96604,	-- The Great Outdoors [Durotar]
				altQuests = {
					96045,	-- Camping 101: Alchemy [Dun Morogh]
					97915,	-- Camping 101: Alchemy [Elwynn Forest]
					97927,	-- Camping 101: Alchemy [Mulgore]
					97938,	-- Camping 101: Alchemy [Teldrassil]
					97951,	-- Camping 101: Alchemy [Tirisfal Glades]
					97963,	-- Camping 101: Alchemy
				},
				qg = 265809,	-- Brakk <Adventurer>
				coord = { 52.0, 47.4, MAP.DUROTAR },
				maps = { MAP.ORGRIMMAR },
				requireSkill = ALCHEMY,
				races = HORDE_ONLY,
				lvl = 4,
				lockCriteria = { 1, "spellID", 1230564 },
				timeline = { TIMELINE.ADDED_1_60_1 },
				groups = {
					recipe(1230564),	-- Alchemy: Mana Well
				},
			}),
			q(97900, {	-- Camping 101: Blacksmithing [Durotar]
				sourceQuest = 96604,	-- The Great Outdoors [Durotar]
				altQuests = {
					96044,	-- Camping 101: Blacksmithing [Dun Morogh]
					97916,	-- Camping 101: Blacksmithing [Elwynn Forest]
					97928,	-- Camping 101: Blacksmithing [Mulgore]
					97939,	-- Camping 101: Blacksmithing [Teldrassil]
					97952,	-- Camping 101: Blacksmithing [Tirisfal Glades]
					97964,	-- Camping 101: Blacksmithing
				},
				qg = 265809,	-- Brakk <Adventurer>
				coord = { 52.0, 47.4, MAP.DUROTAR },
				requireSkill = BLACKSMITHING,
				races = HORDE_ONLY,
				lvl = 4,
				lockCriteria = { 1, "spellID", 1230171 },
				timeline = { TIMELINE.ADDED_1_60_1 },
				groups = {
					recipe(1230171),	-- Blacksmithing: Sharpening Wheel
				},
			}),
			q(96655, {	-- Camping 101: Cooking [Durotar]
				sourceQuest = 96604,	-- The Great Outdoors [Durotar]
				altQuests = {
					96626,	-- Camping 101: Cooking [Elwynn Forest]
					96629,	-- Camping 101: Cooking [Dun Morogh]
					96634,	-- Camping 101: Cooking [Teldrassil]
					96646,	-- Camping 101: Cooking
					96658,	-- Camping 101: Cooking [Tirisfal Glades]
					96661,	-- Camping 101: Cooking [Mulgore]
				},
				qg = 265809,	-- Brakk <Adventurer>
				coord = { 52.0, 47.4, MAP.DUROTAR },
				races = HORDE_ONLY,
				lvl = 4,
				timeline = { TIMELINE.ADDED_1_60_1 },
			}),
			q(97901, {	-- Camping 101: Enchanting [Durotar]
				sourceQuest = 96604,	-- The Great Outdoors [Durotar]
				altQuests = {
					96059,	-- Camping 101: Enchanting [Dun Morogh]
					97917,	-- Camping 101: Enchanting [Elwynn Forest]
					97929,	-- Camping 101: Enchanting [Mulgore]
					97940,	-- Camping 101: Enchanting [Teldrassil]
					97953,	-- Camping 101: Enchanting [Tirisfal Glades]
					98284,	-- Camping 101: Enchanting
					98286,	-- Camping 101: Enchanting
				},
				qg = 265809,	-- Brakk <Adventurer>
				coord = { 52.0, 47.4, MAP.DUROTAR },
				maps = { MAP.ORGRIMMAR },
				requireSkill = ENCHANTING,
				races = HORDE_ONLY,
				lvl = 4,
				lockCriteria = { 1, "spellID", 1230643 },
				timeline = { TIMELINE.ADDED_1_60_1 },
				groups = {
					recipe(1230643),	-- Enchanting: Enchanted Lute
				},
			}),
			q(97902, {	-- Camping 101: Engineering [Durotar]
				sourceQuest = 96604,	-- The Great Outdoors [Durotar]
				altQuests = {
					96058,	-- Camping 101: Engineering [Dun Morogh]
					97918,	-- Camping 101: Engineering [Elwynn Forest]
					97930,	-- Camping 101: Engineering [Mulgore]
					97941,	-- Camping 101: Engineering [Teldrassil]
					97954,	-- Camping 101: Engineering [Tirisfal Glades]
					98285,	-- Camping 101: Engineering
					98287,	-- Camping 101: Engineering
				},
				qg = 265809,	-- Brakk <Adventurer>
				coord = { 52.0, 47.4, MAP.DUROTAR },
				requireSkill = ENGINEERING,
				races = HORDE_ONLY,
				lvl = 4,
				lockCriteria = { 1, "spellID", 1230656 },
				timeline = { TIMELINE.ADDED_1_60_1 },
				groups = {
					recipe(1230656),	-- Engineering: Reagent Bot
				},
			}),
			q(97903, {	-- Camping 101: First Aid [Durotar]
				sourceQuest = 96604,	-- The Great Outdoors [Durotar]
				altQuests = {
					96047,	-- Camping 101: First Aid [Dun Morogh]
					97919,	-- Camping 101: First Aid [Elwynn Forest]
					97931,	-- Camping 101: First Aid [Mulgore]
					97942,	-- Camping 101: First Aid [Teldrassil]
					97955,	-- Camping 101: First Aid [Tirisfal Glades]
					97965,	-- Camping 101: First Aid
				},
				qg = 265809,	-- Brakk <Adventurer>
				coord = { 52.0, 47.4, MAP.DUROTAR },
				requireSkill = FIRST_AID,
				races = HORDE_ONLY,
				lvl = 4,
				lockCriteria = { 1, "spellID", 1230117 },
				timeline = { TIMELINE.ADDED_1_60_1 },
				groups = {
					recipe(1230117),	-- First Aid: First Aid Kit
				},
			}),
			q(97904, {	-- Camping 101: Fishing [Durotar]
				sourceQuest = 96604,	-- The Great Outdoors [Durotar]
				altQuests = {
					96050,	-- Camping 101: Fishing [Dun Morogh]
					97920,	-- Camping 101: Fishing [Elwynn Forest]
					97932,	-- Camping 101: Fishing [Mulgore]
					97943,	-- Camping 101: Fishing [Teldrassil]
					97956,	-- Camping 101: Fishing [Tirisfal Glades]
					97967,	-- Camping 101: Fishing
				},
				qg = 265809,	-- Brakk <Adventurer>
				coord = { 52.0, 47.4, MAP.DUROTAR },
				requireSkill = FISHING,
				races = HORDE_ONLY,
				lvl = 4,
				lockCriteria = { 1, "spellID", 1229745 },
				timeline = { TIMELINE.ADDED_1_60_1 },
				groups = {
					recipe(1229745),	-- Fishing: Fish Bowl
				},
			}),
			q(97905, {	-- Camping 101: Herbalism [Durotar]
				sourceQuest = 96604,	-- The Great Outdoors [Durotar]
				altQuests = {
					96055,	-- Camping 101: Herbalism [Dun Morogh]
					97921,	-- Camping 101: Herbalism [Elwynn Forest]
					97933,	-- Camping 101: Herbalism [Mulgore]
					97944,	-- Camping 101: Herbalism [Teldrassil]
					97957,	-- Camping 101: Herbalism [Tirisfal Glades]
					97968,	-- Camping 101: Herbalism
				},
				qg = 265809,	-- Brakk <Adventurer>
				coord = { 52.0, 47.4, MAP.DUROTAR },
				maps = { MAP.ORGRIMMAR },
				requireSkill = HERBALISM,
				races = HORDE_ONLY,
				lvl = 4,
				lockCriteria = { 1, "spellID", 1229705 },
				timeline = { TIMELINE.ADDED_1_60_1 },
				groups = {
					recipe(1229705),	-- Herbalism: Incense Candle
				},
			}),
			q(97906, {	-- Camping 101: Leatherworking [Durotar]
				sourceQuest = 96604,	-- The Great Outdoors [Durotar]
				altQuests = {
					96031,	-- Camping 101: Leatherworking [Dun Morogh]
					97922,	-- Camping 101: Leatherworking [Elwynn Forest]
					97934,	-- Camping 101: Leatherworking [Mulgore]
					97946,	-- Camping 101: Leatherworking [Teldrassil]
					97958,	-- Camping 101: Leatherworking [Tirisfal Glades]
					97969,	-- Camping 101: Leatherworking
				},
				qg = 265809,	-- Brakk <Adventurer>
				coord = { 52.0, 47.4, MAP.DUROTAR },
				maps = { MAP.ORGRIMMAR },
				requireSkill = LEATHERWORKING,
				races = HORDE_ONLY,
				lvl = 4,
				lockCriteria = { 1, "spellID", 1229432 },
				timeline = { TIMELINE.ADDED_1_60_1 },
				groups = {
					recipe(1229432),	-- Leatherworking: Camp Tent
				},
			}),
			q(97907, {	-- Camping 101: Mining [Durotar]
				sourceQuest = 96604,	-- The Great Outdoors [Durotar]
				altQuests = {
					96046,	-- Camping 101: Mining [Dun Morogh]
					97923,	-- Camping 101: Mining [Elwynn Forest]
					97935,	-- Camping 101: Mining [Mulgore]
					97948,	-- Camping 101: Mining [Teldrassil]
					97959,	-- Camping 101: Mining [Tirisfal Glades]
					97970,	-- Camping 101: Mining
				},
				qg = 265809,	-- Brakk <Adventurer>
				coord = { 52.0, 47.4, MAP.DUROTAR },
				requireSkill = MINING,
				races = HORDE_ONLY,
				lvl = 4,
				lockCriteria = { 1, "spellID", 1230161 },
				timeline = { TIMELINE.ADDED_1_60_1 },
				groups = {
					recipe(1230161),	-- Mining: Lodestone
				},
			}),
			q(97908, {	-- Camping 101: Skinning [Durotar]
				sourceQuest = 96604,	-- The Great Outdoors [Durotar]
				altQuests = {
					96056,	-- Camping 101: Skinning [Dun Morogh]
					97924,	-- Camping 101: Skinning [Elwynn Forest]
					97936,	-- Camping 101: Skinning [Mulgore]
					97949,	-- Camping 101: Skinning [Teldrassil]
					97960,	-- Camping 101: Skinning [Tirisfal Glades]
					97971,	-- Camping 101: Skinning
				},
				qg = 265809,	-- Brakk <Adventurer>
				coord = { 52.0, 47.4, MAP.DUROTAR },
				maps = { MAP.ORGRIMMAR },
				requireSkill = SKINNING,
				races = HORDE_ONLY,
				lvl = 4,
				lockCriteria = { 1, "spellID", 1229517 },
				timeline = { TIMELINE.ADDED_1_60_1 },
				groups = {
					recipe(1229517),	-- Skinning: Camp Chair
				},
			}),
			q(96102, {	-- Camping 101: Tailoring [Durotar]
				sourceQuest = 96604,	-- The Great Outdoors [Durotar]
				altQuests = {
					96057,	-- Camping 101: Tailoring [Dun Morogh]
					97925,	-- Camping 101: Tailoring [Elwynn Forest]
					97937,	-- Camping 101: Tailoring [Mulgore]
					97950,	-- Camping 101: Tailoring [Teldrassil]
					97961,	-- Camping 101: Tailoring [Tirisfal Glades]
					97972,	-- Camping 101: Tailoring
					97973,	-- Camping 101: Tailoring
				},
				qg = 265809,	-- Brakk <Adventurer>
				coord = { 52.0, 47.4, MAP.DUROTAR },
				maps = { MAP.ORGRIMMAR },
				requireSkill = TAILORING,
				races = HORDE_ONLY,
				lvl = 4,
				lockCriteria = { 1, "spellID", 1229504 },
				timeline = { TIMELINE.ADDED_1_60_1 },
				groups = {
					recipe(1229504),	-- Faction Banner (Horde)
				},
			}),
			q(791, {	-- Carry Your Weight
				qg = 3147,	-- Furl Scornbrow
				coord = { 49.8, 40.4, MAP.DUROTAR },
				races = HORDE_ONLY,
				lvl = 4,
				groups = {
					objective(1, {	-- 0/8 Canvas Scraps
						provider = { "i", 4870 },	-- Canvas Scraps
						crs = {
							3119,	-- Kolkar Drudge
							3120,	-- Kolkar Outrunner
							3129,	-- Kul Tiras Marine
							3128,	-- Kul Tiras Sailor
							3192,	-- Lieutenant Benedict
							5808,	-- Warlord Kolkanis
							5809,	-- Watch Commander Zalaphil
						},
					}),
					i(11845),	-- Handmade Leather Bag
				},
			}),
			q(840, {	-- Conscript of the Horde
				qg = 3336,	-- Takrin Pathseeker
				qi = 4992,	-- Recruitment Letter
				coord = { 50.8, 43.5, MAP.DUROTAR },
				races = HORDE_ONLY,
				isBreadcrumb = true,
				lvl = 10,
			}),
			q(842, {	-- Crossroads Conscription
				sourceQuest = 840,	-- Conscript of the Horde
				qg = 3337,	-- Kargal Battlescar
				qi = 4995,	-- Signed Recruitment Letter
				coord = { 62.26, 19.37, MAP.THE_BARRENS },
				races = HORDE_ONLY,
				lvl = 10,
			}),
			q(806, {	-- Dark Storms
				sourceQuest = 823,	-- Report to Orgnil
				qg = 3142,	-- Orgnil Soulscar
				coord = { 52.2, 43.2, MAP.DUROTAR },
				races = HORDE_ONLY,
				lvl = 4,
				groups = {
					objective(1, {	-- 0/1 Fizzle's Claw
						provider = { "i", 4869 },	-- Fizzle's Claw
						coord = { 42.6, 26.4, MAP.DUROTAR },
						cr = 3203,	-- Fizzle Darkstorm
					}),
					i(4942),	-- Tiger Hide Boots
				},
			}),
			q(837, {	-- Encroachment
				qg = 3139,	-- Gar'Thok
				coord = { 52.0, 43.4, MAP.DUROTAR },
				races = HORDE_ONLY,
				lvl = 6,
				groups = {
					objective(1, {	-- 0/4 Razormane Quilboar slain
						provider = { "n", 3111 },	-- Razormane Quilboar
					}),
					objective(2, {	-- 0/4 Razormane Scout slain
						provider = { "n", 3112 },	-- Razormane Scout
					}),
					objective(3, {	-- 0/4 Razormane Dustrunner slain
						provider = { "n", 3113 },	-- Razormane Dustrunner
					}),
					objective(4, {	-- 0/4 Razormane Battleguard slain
						provider = { "n", 3114 },	-- Razormane Battleguard
					}),
				},
			}),
			q(1464, {	-- Fire Sapta
				sourceQuest = 1525,	-- Call of Fire (3/5)
				qg = 5900,	-- Telf Joolam
				coord = { 38.6, 58.8, MAP.DUROTAR },
				races = HORDE_ONLY,
				classes = { SHAMAN },
				repeatable = true,
				lvl = 10,
				groups = {
					i(6636),	-- Fire Sapta
				},
			}),
			q(96822, {	-- For Honor
				qg = 266940,	-- Turroc
				coord = { 54.0, 42.6, MAP.DUROTAR },
				timeline = { TIMELINE.ADDED_1_60_1 },
				races = HORDE_ONLY,
				lvl = 3,
				groups = {
					objective(1, {	-- 0/1 Raider's Bow
						providers = {
							{ "i", 275713 },	-- Raider's Bow
							{ "o", 656180 },	-- Raider's Bow
						},
					}),
					objective(2, {	-- 0/1 Raider's Battleaxe
						providers = {
							{ "i", 275716 },	-- Raider's Battleaxe
							{ "o", 656181 },	-- Raider's Battleaxe
						},
					}),
					objective(3, {	-- 0/1 Raider's Shield
						providers = {
							{ "i", 275717 },	-- Raider's Shield
							{ "o", 656182 },	-- Raider's Shield
						},
					}),
				},
			}),
			q(97225, {	-- Forgotten Loa Idols
				qg = 3304,	-- Master Vornal
				coord = { 55.8, 74.4, MAP.DUROTAR },
				timeline = { TIMELINE.ADDED_1_60_1 },
				races = HORDE_ONLY,
				lvl = 4,
				groups = {
					objective(1, {	-- 0/8 Forgotten Loa Idol
						providers = {
							{ "i", 277135 },	-- Forgotten Loa Idol
							{ "o", 660647 },	-- Forgotten Loa Idol
						},
					}),
					i(281268),	-- Depleted Ritual Band
				},
			}),
			q(825, {	-- From The Wreckage....
				sourceQuest = 784,	-- Vanquish the Betrayers
				qg = 3139,	-- Gar'Thok
				coord = { 52.0, 43.4, MAP.DUROTAR },
				races = HORDE_ONLY,
				lvl = 3,
				groups = {
					objective(1, {	-- 0/3 Gnomish Tools
						providers = {
							{ "i", 4863 },	-- Gnomish Tools
							{ "o", 3236 },	-- Gnomish Toolbox
						},
					}),
					i(4936),	-- Dirt-trodden Boots
					i(4928),	-- Sandrunner Wristguards
					i(4935),	-- Wide Metal Girdle
				},
			}),
			q(1506, {	-- Gan'rul's Summons
				altQuests = { 1478 },	-- Halgar's Summons
				qg = 3294,	-- Ophek
				coord = { 54.2, 41.2, MAP.DUROTAR },
				races = { ORC, TROLL, UNDEAD },
				classes = { WARLOCK },
				lvl = 10,
			}),
			q(5648, {	-- Garments of Spirituality
				sourceQuest = 5649,	-- In Favor of Spirituality
				qg = 3706,	-- Tai'jin
				coord = { 54.2, 42.8, MAP.DUROTAR },
				races = { TROLL },
				classes = { PRIEST },
				lvl = 5,
				groups = {
					i(16606),	-- Juju Hex Robes
				},
			}),
			q(96877, {	-- Halikor's Hoof
				qs = 275723,	-- Halikor's Hoof (QS!)
				coords = {
					{ 40.3, 30.0, MAP.DUROTAR },
					{ 42.9, 23.2, MAP.DUROTAR },
				},
				cr = 266852,	-- Halikor
				timeline = { TIMELINE.ADDED_1_60_1 },
				races = HORDE_ONLY,
				lvl = 6,
			}),
			q(5654, {	-- Hex of Weakness [Durotar]
				altQuests = {
					5652,	-- Hex of Weakness [Orgrimmar]
					5655,	-- Hex of Weakness [Mulgore]
					5656,	-- Hex of Weakness [Thunder Bluff]
					5657,	-- Hex of Weakness [Undercity]
				},
				qg = 3706,	-- Tai'jin <Priest Trainer>
				coord = { 54.2, 42.8, MAP.DUROTAR },
				races = { TROLL },
				classes = { PRIEST },
				lvl = 10,
				groups = {
					{
						recipeID = 9035,	-- Hex of Weakness (Rank 1)
						rank = 1,
					},
				},
			}),
			q(1884, {	-- Ju-Ju Heaps
				sourceQuests = {
					1881,	-- Speak with Anastasia
					1883,	-- Speak with Un'thuwa
				},
				qg = 5880,	-- Un'Thuwa <Mage Trainer>
				coord = { 56.2, 75.0, MAP.DUROTAR },
				races = { UNDEAD, TROLL },
				classes = { MAGE },
				lvl = 10,
				groups = {
					i(7508),	-- Ley Orb
					i(9513),	-- Ley Staff
				},
			}),
			q(97200, {	-- Learning to Ride
				qg = 7953,	-- Xar'Ti <Raptor Riding Trainer>
				coord = { 55.2, 75.4, MAP.DUROTAR },
				races = { TROLL },
				lvl = 40,
				timeline = { TIMELINE.ADDED_1_60_1 },
			}),
			q(96821, {	-- Legging It
				qg = 3194,	-- Vel'rin Fang
				coord = { 55.95, 73.92, MAP.DUROTAR },
				timeline = { TIMELINE.ADDED_1_60_1 },
				races = HORDE_ONLY,
				groups = {
					objective(1, {	-- 0/6 Ridgeshade Creeper slain
						provider = { "n", 266850 },	-- Ridgeshade Creeper
						coord = { 51.4, 53.0, MAP.DUROTAR },
					}),
					objective(2, {	-- 0/6 Ridgeshade Lurker slain
						provider = { "n", 266849 },	-- Ridgeshade Lurker
						coord = { 50.4, 51.8, MAP.DUROTAR },
					}),
				},
			}),
			q(816, {	-- Lost But Not Forgotten
				qg = 3193,	-- Misha Tor'kren
				coord = { 43.10, 30.24, MAP.DUROTAR },
				races = HORDE_ONLY,
				lvl = 8,
				groups = {
					objective(1, {	-- 0/1 Kron's Amulet
						provider = { "i", 4891 },	-- Kron's Amulet
						crs = {
							3231,	-- Corrupted Dreadmaw Crocolisk
							3110,	-- Dreadmaw Crocolisk
						},
					}),
					i(4944),	-- Handsewn Cloak
				},
			}),
			q(99123, {	-- Lost in the Shadows
				qg = 275811,	-- Pal'juh
				coord = { 46.2, 78.6, MAP.DUROTAR },
				timeline = { TIMELINE.ADDED_1_60_1 },
				races = HORDE_ONLY,
				lvl = 4,
				groups = {
					objective(1, {	-- Escort Pal'juh out of Kolkar Crag
						provider = { "n", 275811 },	-- Pal'juh
					}),
					i(286728),	-- Kolkar Hammer
					i(286729),	-- Kolkar Bow
				},
			}),
			q(828, {	-- Margoz
				sourceQuest = 806,	-- Dark Storms
				qg = 3142,	-- Orgnil Soulscar
				coord = { 52.2, 43.2, MAP.DUROTAR },
				races = HORDE_ONLY,
				lvl = 4,
			}),
			q(808, {	-- Minshina's Skull
				sourceQuest = 805,	-- Report to Sen'jin Village
				qg = 3188,	-- Master Gadrin
				coord = { 56.0, 74.6, MAP.DUROTAR },
				races = HORDE_ONLY,
				lvl = 4,
				groups = {
					objective(1, {	-- 0/1 Minshina's Skull
						providers = {
							{ "i", 4864 },	-- Minshina's Skull
							{ "o", 3237 },	-- Imprisoned Darkspear
						},
						coord = { 67.4, 87.7, MAP.DUROTAR },
					}),
					i(4945),	-- Faintly Glowing Skull
				},
			}),
			q(812, {	-- Need for a Cure
				qg = 3190,	-- Rhinag
				coord = { 41.54, 18.61, MAP.DUROTAR },
				maps = { MAP.ORGRIMMAR },
				races = HORDE_ONLY,
				lvl = 7,
				groups = {
					q(813, {	-- Finding the Antidote
						qg = 3189,	-- Kor'ghan
						coord = { 47.0, 53.4, MAP.ORGRIMMAR },
						races = HORDE_ONLY,
						repeatable = true,
						lvl = 7,
						groups = {
							objective(1, {	-- 0/4 Venomtail Poison Sac
								cost = { { "i", 4886, 4 } },	-- Venomtail Poison Sac
								crs = {
									3226,	-- Corrupted Scorpid
									5823,	-- Death Flayer
									3127,	-- Venomtail Scorpid
								},
							}),
							objective(1, {	-- 0/1 Venomtail Antidote
								questID = 812,	-- Need for a Cure
								provider = { "i", 4904 },	-- Venomtail Antidote
							}),
						},
					}),
					i(4937),	-- Charging Buckler
					i(4929),	-- Light Scorpid Armor
				},
			}),
			q(829, {	-- Neeru Fireblade
				sourceQuest = 827,	-- Skull Rock
				qg = 3208,	-- Margoz
				qi = 6658,	-- Example Collar
				coord = { 56.4, 20.0, MAP.DUROTAR },
				races = HORDE_ONLY,
				lvl = 4,
			}),
			q(817, {	-- Practical Prey
				qg = 3194,	-- Vel'rin Fang
				coord = { 55.95, 73.92, MAP.DUROTAR },
				races = HORDE_ONLY,
				lvl = 5,
				groups = {
					objective(1, {	-- 0/4 Durotar Tiger Fur
						provider = { "i", 4892 },	-- Durotar Tiger Fur
						cr = 3121,	-- Durotar Tiger
					}),
				},
			}),
			q(823, {	-- Report to Orgnil
				sourceQuest = 805,	-- Report to Sen'jin Village
				qg = 3188,	-- Master Gadrin
				coord = { 56.0, 74.6, MAP.DUROTAR },
				races = HORDE_ONLY,
				lvl = 4,
			}),
			q(1842, {	-- Satyr Hooves
				sourceQuest = 1839,	-- Ula'elek and the Brutal Gauntlets
				qg = 6408,	-- Ula'elek
				coord = { 56.2, 74.4, MAP.DUROTAR },
				maps = { MAP.ASHENVALE },
				races = HORDE_ONLY,
				classes = { WARRIOR },
				lvl = 20,
				groups = {
					objective(1, {	-- 0/7 Uncloven Satyr Hoof
						provider = { "i", 7128 },	-- Uncloven Satyr Hoof
						crs = {
							3771,	-- Bleakheart Hellcaller
							3770,	-- Bleakheart Shadowstalker
							3767,	-- Bleakheart Trickster
							3765,	-- Bleakheart Satyr
							3755,	-- Xavian Felsworn
							3754,	-- Xavian Betrayer
							3757,	-- Xavian Hellcaller
							3752,	-- Xavian Rogue
							10647,	-- Prince Raze
							3758,	-- Felmusk Satyr
							3762,	-- Felmusk Felsworn
							3763,	-- Felmusk Shadowstalker
							3759,	-- Felmusk Rogue
						},
					}),
				},
			}),
			q(835, {	-- Securing the Lines
				sourceQuest = 834,	-- Winds in the Desert
				qg = 3293,	-- Rezlak
				coord = { 46.4, 23.0, MAP.DUROTAR },
				--races = ALL_RACES,	-- Crieve: Yes, doable on Alliance.
				lvl = 7,
				groups = {
					objective(1, {	-- 0/12 Dustwind Savage
						provider = { "n", 3117 },	-- Dustwind Savage
					}),
					objective(2, {	-- 0/8 Dustwind Storm Witch
						provider = { "n", 3118 },	-- Dustwind Storm Witch
					}),
					i(4932),	-- Harpy Wing Clipper
					i(4931),	-- Hickory Shortbow
					i(4938),	-- Blemished Wooden Staff
				},
			}),
			q(827, {	-- Skull Rock
				sourceQuest = 828,	-- Margoz
				qg = 3208,	-- Margoz
				coord = { 56.4, 20.0, MAP.DUROTAR },
				races = HORDE_ONLY,
				lvl = 4,
				groups = {
					objective(1, {	-- 0/6 Searing Collar
						provider = { "i", 4871 },	-- Searing Collar
						crs = {
							3198,	-- Burning Blade Apprentice
							3199,	-- Burning Blade Cultist
							3197,	-- Burning Blade Fanatic
							3196,	-- Burning Blade Neophyte
							3195,	-- Burning Blade Thug
						},
					}),
					i(4947),	-- Jagged Dagger
					i(4939),	-- Steady Bastard Sword
					i(4948),	-- Stinging Mace
				},
			}),
			q(1883, {	-- Speak with Un'thuwa
				altQuests = { 1881 },	-- Speak with Anastasia
				qgs = {
					3049,	-- Thurston Xane <Mage Trainer>
					7311,	-- Uthel'nay <Mage Trainer>
				},
				coords = {
					{ 39.0, 86.0, MAP.ORGRIMMAR },
					{ 25.0, 20.6, MAP.THUNDER_BLUFF },
				},
				races = { UNDEAD, TROLL },
				classes = { MAGE },
				isBreadcrumb = true,
				lvl = 10,
			}),
			q(97282, {	-- Stormy Potential
				sourceQuest = 97281,	-- A Simmering Storm
				qg = 3293,	-- Rezlak
				coord = { 46.4, 23.0, MAP.DUROTAR },
				timeline = { TIMELINE.ADDED_1_60_1 },
				races = HORDE_ONLY,
				lvl = 7,
				groups = {
					objective(1, {	-- 0/5 Charged Thunder Lizard Organ
						provider = { "i", 277665 },	-- Charged Thunder Lizard Organ
						crs = {
							3130,	-- Thunder Lizard
							3131,	-- Lightning Hide
						},
					}),
					i(281274),	-- Makeshift Stormcaller
					i(287060),	-- Rezlak's Spare Knife
				},
			}),
			q(6062, {	-- Taming the Beast (1/3)
				sourceQuests = {
					6068,	-- The Hunter's Path [Orgrimmar]
					6069,	-- The Hunter's Path [Durotar]
					6070,	-- The Hunter's Path [Thunder Bluff]
				},
				qg = 3171,	-- Thotar <Hunter Trainer>
				coord = { 51.8, 43.4, MAP.DUROTAR },
				races = { ORC, UNDEAD, TROLL },
				classes = { HUNTER },
				lvl = 10,
				groups = {
					objective(1, {	-- Tame a Dire Mottled Boar
						provider = { "i", 15917 },	-- Taming Rod
						cr = 3099,	-- Dire Mottled Boar
					}),
				},
			}),
			q(6083, {	-- Taming the Beast (2/3)
				sourceQuest = 6062,	-- Taming the Beast (1/3)
				qg = 3171,	-- Thotar <Hunter Trainer>
				coord = { 51.8, 43.4, MAP.DUROTAR },
				races = { ORC, UNDEAD, TROLL },
				classes = { HUNTER },
				lvl = 10,
				groups = {
					objective(1, {	-- Tame a Surf Crawler
						provider = { "i", 15919 },	-- Taming Rod
						cr = 3107,	-- Surf Crawler
					}),
				},
			}),
			q(6082, {	-- Taming the Beast (3/3)
				sourceQuest = 6083,	-- Taming the Beast (2/3)
				qg = 3171,	-- Thotar <Hunter Trainer>
				coord = { 51.8, 43.4, MAP.DUROTAR },
				races = { ORC, UNDEAD, TROLL },
				classes = { HUNTER },
				lvl = 10,
				groups = {
					objective(1, {	-- Tame an Armored Scorpid
						provider = { "i", 15920 },	-- Taming Rod
						cr = 3126,	-- Armored Scorpid
					}),
					recipe(883),	-- Call Pet
					recipe(2641),	-- Dismiss Pet
					recipe(1515),	-- Tame Beast
				},
			}),
			q(830, {	-- The Admiral's Orders (1/2)
				qs = 4881,	-- Aged Envelope (QS!)
				races = HORDE_ONLY,
			}),
			q(831, {	-- The Admiral's Orders (2/2)
				sourceQuest = 830,	-- The Admiral's Orders (1/2)
				qg = 3139,	-- Gar'Thok
				qi = 4883,	-- Admiral Proudmoore's Orders
				coord = { 52.0, 43.4, MAP.DUROTAR },
				races = HORDE_ONLY,
			}),
			q(924, {	-- The Demon Seed
				sourceQuest = 809,	-- Ak'Zeloth
				qg = 3521,	-- Ak'Zeloth
				coord = { 62.4, 20.0, MAP.THE_BARRENS },
				races = HORDE_ONLY,
				lvl = 9,
				groups = {
					q(926, {	-- Flawed Power Stone
						sourceQuest = 924,	-- The Demon Seed
						provider = { "o", 5620 },	-- Flawed Power Stones
						coord = { 62.4, 20.0, MAP.THE_BARRENS },
						races = HORDE_ONLY,
						repeatable = true,
						groups = {
							objective(1, {	-- Destroy the Demon Seed
								questID = 924,	-- The Demon Seed
								providers = {
									{ "o", 3525 },	-- The Altar of Fire
									{ "i", 4986 },	-- Flawed Power Stone
								},
								coord = { 47.0, 19.0, MAP.THE_BARRENS },
							}),
						},
					}),
					i(5420),	-- Banshee Armor
				},
			}),
			q(96604, {	-- The Great Outdoors [Durotar]
				sourceQuest = 96652,	-- The Adventurer [Durotar]
				altQuests = {
					95998,	-- The Great Outdoors [Elwynn Forest]
					96101,	-- The Great Outdoors [Zephras Isle]
					96605,	-- The Great Outdoors [Mulgore]
					96606,	-- The Great Outdoors [Teldrassil]
					96607,	-- The Great Outdoors [Tirisfal Glades]
					96608,	-- The Great Outdoors [Dun Morogh]
				},
				qg = 265809,	-- Brakk <Adventurer>
				coord = { 52.0, 47.4, MAP.DUROTAR },
				races = HORDE_ONLY,
				lvl = 4,
				timeline = { TIMELINE.ADDED_1_60_1 },
			}),
			q(6069, {	-- The Hunter's Path [Durotar]
				qg = 11814,	-- Kali Remik
				coord = { 6.2, 74.2, MAP.DUROTAR },
				races = { ORC, UNDEAD, TROLL },
				classes = { HUNTER },
				isBreadcrumb = true,
				lvl = 10,
			}),
			q(6068, {	-- The Hunter's Path [Orgrimmar]
				qg = 3407,	-- Sian'dur <Hunter Trainer>
				coord = { 67.8, 17.8, MAP.ORGRIMMAR },
				races = { ORC, UNDEAD, TROLL },
				classes = { HUNTER },
				isBreadcrumb = true,
				lvl = 10,
			}),
			q(6070, {	-- The Hunter's Path [Thunder Bluff]
				qg = 3038,	-- Kary Thunderhorn <Hunter Trainer>
				coord = { 58.4, 88.0, MAP.THUNDER_BLUFF },
				races = { ORC, UNDEAD, TROLL },
				classes = { HUNTER },
				isBreadcrumb = true,
				lvl = 10,
			}),
			q(1859, {	-- Therzok
				qg = 3170,	-- Kaplak
				coord = { 51.98, 43.70, MAP.DUROTAR },
				races = { ORC, TROLL },
				classes = { ROGUE },
				isBreadcrumb = true,
				lvl = 10,
			}),
			q(96825, {	-- This Fruit Could Bite Back
				qg = 3191,	-- Cook Torka
				coord = { 51.11, 42.45, MAP.DUROTAR },
				timeline = { TIMELINE.ADDED_1_60_1 },
				races = HORDE_ONLY,
				lvl = 3,
				groups = {
					objective(1, {	-- 0/8 Prickly Pear Fruit
						providers = {
							{ "i", 275718 },	-- Prickly Pear Fruit
							{ "o", 656177 },	-- Prickly Pear Fruit
						},
					}),
				},
			}),
			q(96874, {	-- This Is Spinal Axe
				qg = 10266,	-- Ug'thok
				coord = { 80.6, 23.4, MAP.ORGRIMMAR },
				timeline = { TIMELINE.ADDED_1_60_1 },
				requireSkill = BLACKSMITHING,
				races = HORDE_ONLY,
				lvl = 6,
				groups = {
					objective(1, {	-- 0/5 Weathered Spine
						provider = { "i", 275719 },	-- Weathered Spine
						crs = {
							3130,	-- Thunder Lizard
							3131,	-- Lightning Hide
						},
					}),
					objective(2, {	-- 0/5 Rough Grinding Stone
						provider = { "i", 3470 },	-- Rough Grinding Stone
					}),
					i(277673),	-- Plans: Rough Copper Chain Boots
				},
			}),
			q(99049, {	-- Threat from Below
				sourceQuest = 99048,	-- A Missing Hand
				qg = 275657,	-- Heglan Shadeeye
				coord = { 58.6, 45.6, MAP.DUROTAR },
				timeline = { TIMELINE.ADDED_1_60_1 },
				races = HORDE_ONLY,
				lvl = 9,
				groups = {
					objective(1, {	-- 0/1 Orcish Dagger
						providers = {
							{ "i", 286012 },	-- Orcish Dagger
							{ "o", 693674 },	-- Abandoned Dagger
						},
					}),
					objective(2, {	-- 0/1 Banner Scrap
						providers = {
							{ "i", 286011 },	-- Banner Scrap
							{ "o", 693670 },	-- Strange Debris
						},
					}),
					objective(3, {	-- 0/1 Broken Bone Trident
						providers = {
							{ "i", 286010 },	-- Broken Bone Trident
							{ "o", 693669 },	-- Weapon Piece
						},
					}),
				},
			}),
			q(99051, {	-- Threat from Below
				sourceQuest = 99049,	-- Threat from Below
				qg = 3142,	-- Orgnil Soulscar
				coord = { 52.2, 43.2, MAP.DUROTAR },
				timeline = { TIMELINE.ADDED_1_60_1 },
				races = HORDE_ONLY,
				lvl = 9,
				groups = {
					objective(1, {	-- 0/9 Naga Spinefin
						provider = { "i", 286008 },	-- Naga Spinefin
						crs = {
							275662,	-- Spitelash Scout
							275663,	-- Spitelash Attendant
						},
					}),
				},
			}),
			q(99052, {	-- Threat from Below
				sourceQuest = 99051,	-- Threat from Below
				qg = 3142,	-- Orgnil Soulscar
				coord = { 52.2, 43.2, MAP.DUROTAR },
				timeline = { TIMELINE.ADDED_1_60_1 },
				races = HORDE_ONLY,
				lvl = 10,
				groups = {
					objective(1, {	-- 0/1 Aggor's Belt
						provider = { "i", 286009 },	-- Aggor's Belt
						coord = { 58.9, 16.9, MAP.DUROTAR },
						cr = 275666,	-- Aggor the Young
					}),
					i(286730),	-- Pristine Orcish Dagger
					i(286731),	-- Aggor's Refitted Belt
				},
			}),
			q(786, {	-- Thwarting Kolkar Aggression
				sourceQuests = { 785 },	-- A Strategic Alliance
				qg = 3140,	-- Lar Prowltusk
				coord = { 54.52, 75.20, MAP.DUROTAR },
				races = HORDE_ONLY,
				lvl = 5,
				groups = {
					objective(1, {	-- 0/1 Attack Plan: Valley of Trials
						provider = { "o", 3189 },	-- Attack Plan: Valley of Trials
						coord = { 49.8, 81.3, MAP.DUROTAR },
					}),
					objective(2, {	-- 0/1 Attack Plan: Sen'jin Village
						provider = { "o", 3190 },	-- Attack Plan: Sen'jin Village
						coord = { 47.6, 77.4, MAP.DUROTAR },
					}),
					objective(3, {	-- 0/1 Attack Plan: Orgrimmar
						provider = { "o", 3192 },	-- Attack Plan: Orgrimmar
						coord = { 46.3, 79.0, MAP.DUROTAR },
					}),
					i(4933),	-- Seasoned Fighter's Cloak
					i(6062),	-- Heavy Cord Bracers
				},
			}),
			q(5660, {	-- Touch of Weakness [Durotar]
				altQuests = {
					5658,	-- Touch of Weakness [Undercity]
					5661,	-- Touch of Weakness [Mulgore]
					5662,	-- Touch of Weakness [Orgrimmar]
					5663,	-- Touch of Weakness [Thunder Bluff]
				},
				qg = 3706,	-- Tai'jin <Priest Trainer>
				coord = { 54.2, 42.8, MAP.DUROTAR },
				classes = { PRIEST },
				races = { UNDEAD },
				lvl = 10,
				groups = {
					{
						recipeID = 2652,	-- Touch of Weakness (Rank 1)
						rank = 1,
					},
				},
			}),
			q(6081, {	-- Training the Beast
				sourceQuest = 6082,	-- Taming the Beast (3/3)
				qg = 3171,	-- Thotar <Hunter Trainer>
				coord = { 51.8, 43.4, MAP.DUROTAR },
				races = { ORC, UNDEAD, TROLL },
				classes = { HUNTER },
				lvl = 10,
				groups = {
					recipe(6991),	-- Feed Pet
					recipe(982),	-- Revive Pet
				},
			}),
			q(96876, {	-- Ukor's Lost Pack
				qs = 275722,	-- Ukor's Lost Pack (QS!)
				timeline = { TIMELINE.ADDED_1_60_1 },
				races = HORDE_ONLY,
				lvl = 5,
			}),
			q(784, {	-- Vanquish the Betrayers
				qg = 3139,	-- Gar'Thok
				coord = { 52.0, 43.4, MAP.DUROTAR },
				races = HORDE_ONLY,
				lvl = 3,
				groups = {
					objective(1, {	-- 0/10 Kul Tiras Sailor
						provider = { "n", 3128 },	-- Kul Tiras Sailor
					}),
					objective(2, {	-- 0/8 Kul Tiras Marine
						provider = { "n", 3129 },	-- Kul Tiras Marine
					}),
					objective(3, {	-- 0/1 Lieutenant Benedict
						provider = { "n", 3192 },	-- Lieutenant Benedict
					}),
				},
			}),
			q(834, {	-- Winds in the Desert
				qg = 3293,	-- Rezlak
				coord = { 46.4, 23.0, MAP.DUROTAR },
				--races = ALL_RACES,	-- Crieve: Yes, doable on Alliance.
				lvl = 7,
				groups = {
					objective(1, {	-- 0/5 Sack of Supplies
						providers = {
							{ "i", 4918 },	-- Sack of Supplies
							{ "o", 3290 },	-- Stolen Supply Sack
						},
					}),
				},
			}),
			q(826, {	-- Zalazane
				sourceQuest = 805,	-- Report to Sen'jin Village
				qg = 3188,	-- Master Gadrin
				coord = { 56.0, 74.6, MAP.DUROTAR },
				races = HORDE_ONLY,
				lvl = 4,
				groups = {
					objective(1, {	-- 0/8 Hexed Troll
						provider = { "n", 3207 },	-- Hexed Troll
					}),
					objective(2, {	-- 0/8 Voodoo Troll
						provider = { "n", 3206 },	-- Voodoo Troll
					}),
					objective(3, {	-- 0/1 Zalazane's Head
						provider = { "i", 4866 },	-- Zalazane's Head
						coord = { 67.6, 87.8, MAP.DUROTAR },
						cr = 3205,	-- Zalazane
					}),
					i(4946),	-- Lightweight Boots
					i(4940),	-- Veiled Grips
				},
			}),
		}),
		n(RARES, {
			n(5824, {	-- Captain Flat Tusk <Captain of the Battleguard>
				coords = {
					{ 38.6, 53.8, MAP.DUROTAR },
					{ 44.8, 50.6, MAP.DUROTAR },
					{ 42.4, 38.6, MAP.DUROTAR },
				},
				groups = {
					i(284286, {	-- Battleguard Captain's Sticker
						timeline = { TIMELINE.ADDED_1_60_1 },
					}),
				},
			}),
			n(5823, {	-- Death Flayer
				coords = {
					{ 38.8, 46.2, MAP.DUROTAR },
					{ 35.2, 48.2, MAP.DUROTAR },
					{ 35.4, 53.0, MAP.DUROTAR },
					{ 36.0, 55.6, MAP.DUROTAR },
					{ 37.8, 53.4, MAP.DUROTAR },
					{ 39.2, 51.0, MAP.DUROTAR },
				},
				groups = {
					i(284320, {	-- Flayed Scorpid Bands
						timeline = { TIMELINE.ADDED_1_60_1 },
					}),
				},
			}),
			n(276194, {	-- Dustwind Eggtender
				coords = {
					{ 51.2, 19.8, MAP.DUROTAR },
					{ 51.2, 23.4, MAP.DUROTAR },
				},
				timeline = { TIMELINE.ADDED_1_60_1 },
				groups = {
					i(286745),	-- Furlfeather Ring
				},
			}),
			n(5822, {	-- Felweaver Scornn
				coords = {
					{ 51.6, 9.6, MAP.DUROTAR },
					{ 53.0, 7.2, MAP.DUROTAR },
				},
				groups = {
					i(284287, {	-- Felweaver's Staff
						timeline = { TIMELINE.ADDED_1_60_1 },
					}),
				},
			}),
			n(5826, {	-- Geolord Mottle
				coords = {
					{ 43.6, 40.8, MAP.DUROTAR },
					{ 49.6, 45.0, MAP.DUROTAR },
					{ 47.6, 50.0, MAP.DUROTAR },
					{ 44.6, 48.4, MAP.DUROTAR },
					{ 43.8, 50.0, MAP.DUROTAR },
				},
				groups = {
					i(284323, {	-- Geolord's Mitts
						timeline = { TIMELINE.ADDED_1_60_1 },
					}),
				},
			}),
			n(276198, {	-- Shal'ma
				coords = {
					{ 69.0, 71.6, MAP.DUROTAR },
					{ 60.6, 89.6, MAP.DUROTAR },
					{ 63.6, 95.6, MAP.DUROTAR },
				},
				timeline = { TIMELINE.ADDED_1_60_1 },
				groups = {
					i(286746),	-- Shal'ma's Shawl
				},
			}),
			n(5808, {	-- Warlord Kolkanis
				coords = {
					{ 46.6, 79.8, MAP.DUROTAR },
					{ 48.2, 78.2, MAP.DUROTAR },
					{ 49.6, 80.6, MAP.DUROTAR },
				},
				groups = {
					i(284321, {	-- Centaur Raider's Axe
						timeline = { TIMELINE.ADDED_1_60_1 },
					}),
				},
			}),
			n(5809, {	-- Watch Commander Zalaphil
				coord = { 59.6, 59.0, MAP.DUROTAR },
				groups = {
					i(284322, {	-- Invading Marine's Shield
						timeline = { TIMELINE.ADDED_1_60_1 },
					}),
				},
			}),
		}),
		n(RIDING_TRAINER, {
			n(7953, {	-- Xar'Ti <Raptor Riding Trainer>
				coord = { 55.3, 75.5, MAP.DUROTAR },
				races = { ORC, TROLL, UNDEAD },
				-- Available to Trolls without faction requirements.
				minReputation = { FACTION_DARKSPEAR_TROLLS, EXALTED },
				OnInit = [[function(t)
					if _.RaceIndex == ]] .. TROLL .. [[ then
						t.minReputation = nil;
					end
					return t;
				end]],
				groups = {
					recipe(10861, {	-- Raptor Riding
						cost = 200000,
						lvl = 40,
					}),
				},
			}),
		}),
		n(TREASURES, {
			o(3239, {	-- Benedict's Chest
				coord = { 59.3, 57.7, MAP.DUROTAR },
				cost = { { "i", 4882, 1 } },	-- Benedict's Key
				groups = {
					i(4881),	-- Aged Envelope
				},
			}),
		}),
		n(VENDORS, {
			n(3166, {	-- Cutac <Cloth & Leather Armor Merchant>
				coord = { 53.0, 40.8, MAP.DUROTAR },
				races = HORDE_ONLY,
				sym = {
					{ "select", "symselector",
						SymSelector.VENDOR_BATTERED_LEATHER,	-- Battered Leather
						SymSelector.VENDOR_WOVEN,	-- Woven
					},
					{ "pop" },
				},
			}),
			n(3165, {	-- Ghrawt <Bowyer>
				coord = { 52.0, 41.1, MAP.DUROTAR },
				races = HORDE_ONLY,
				sym = {{ "select", "itemID",
					2506,	-- Hornwood Recurve Bow
					2507,	-- Laminated Recurve Bow
					11362,	-- Medium Quiver
					5439,	-- Small Quiver
				}},
			}),
			n(3881, {	-- Grimtak
				coord = { 51.2, 42.6, MAP.DUROTAR },
				races = HORDE_ONLY,
				sym = {
					{ "select", "symselector",
						SymSelector.VENDOR_FOOD_DRINK,	-- Drink
						SymSelector.VENDOR_FOOD_MEAT,	-- Meat
					},
					{ "pop" },
				},
				groups = {
					i(5483),	-- Recipe: Scorpid Surprise (RECIPE!)
				},
			}),
			n(3160, {	-- Huklah <Cloth & Leather Armor Merchant>
				coord = { 40.6, 67.8, MAP.DUROTAR },
				races = HORDE_ONLY,
				sym = {
					{ "select", "symselector",
						SymSelector.VENDOR_DIRTY_LEATHER,	-- Dirty Leather
						SymSelector.VENDOR_TATTERED_CLOTH,	-- Tattered Cloth
					},
					{ "pop" },
				},
			}),
			n(3159, {	-- Kzan Thornslash <Weaponsmith>
				coord = { 40.4, 68.0, MAP.DUROTAR },
				races = HORDE_ONLY,
				sym = {{ "select", "itemID",
					1194,	-- Bastard Sword
					2479,	-- Broad Axe
					2130,	-- Club
					2139,	-- Dirk
					2134,	-- Hand Axe
					2480,	-- Large Club
					2132,	-- Short Staff
					2131,	-- Shortsword
				}},
			}),
			n(3161, {	-- Rarc <Armorer & Shieldcrafter>
				coords = {
					{ 40.4, 67.8, MAP.DUROTAR },
					{ 40.6, 67.8, MAP.DUROTAR },
				},
				races = HORDE_ONLY,
				sym = {
					SymSelector.select("VENDOR_RUSTED_CHAIN"),	-- Rusted Chain
					{ "pop" },
					{ "select", "itemID",
						17183,	-- Dented Buckler
						1200,	-- Large Wooden Shield
					},
				},
			}),
			n(10369, {	-- Trayexir <Weapon Merchant>
				coord = { 56.4, 73.2, MAP.DUROTAR },
				races = HORDE_ONLY,
				sym = {{ "select", "itemID",
					2492,	-- Cudgel
					2488,	-- Gladius
					2506,	-- Hornwood Recurve Bow
					2507,	-- Laminated Recurve Bow
					2491,	-- Large Axe
					2494,	-- Stiletto
					2490,	-- Tomahawk
					2489,	-- Two-Handed Sword
					2495,	-- Walking Stick
					2493,	-- Wooden Mallet
				}},
			}),
			n(3163, {	-- Uhgar <Weaponsmith>
				coord = { 52.0, 40.4, MAP.DUROTAR },
				races = HORDE_ONLY,
				sym = {{ "select", "itemID",
					2492,	-- Cudgel
					2488,	-- Gladius
					2491,	-- Large Axe
					2494,	-- Stiletto
					2490,	-- Tomahawk
					2489,	-- Two-Handed Sword
					2495,	-- Walking Stick
					2493,	-- Wooden Mallet
				}},
			}),
			n(3167, {	-- Wuark <Armorer & Shieldcrafter>
				coord = { 52.0, 41.2, MAP.DUROTAR },
				races = HORDE_ONLY,
				sym = {
					SymSelector.select("VENDOR_LIGHT_CHAIN"),	-- Light Chain
					{ "pop" },
					{ "select", "itemID",
						2901,	-- Mining Pick
						17185,	-- Round Buckler
						2376,	-- Worn Heater Shield
					},
				},
			}),
			n(5942, {	-- Zansoa <Fishing Supplies>
				coord = { 56.0, 73.4, MAP.DUROTAR },
				races = HORDE_ONLY,
				sym = {{ "select", "itemID",
					6368,	-- Recipe: Rainbow Fin Albacore (RECIPE!)
				}},
				groups = {
					i(6326),	-- Recipe: Slitherskin Mackerel (RECIPE!)
				},
			}),
			n(7952, {	-- Zjolnir <Raptor Handler>
				coord = { 55.2, 75.6, MAP.DUROTAR },
				-- Available to Trolls without faction requirements.
				minReputation = { FACTION_DARKSPEAR_TROLLS, EXALTED },
				OnInit = [[function(t)
					if _.RaceIndex == ]] .. TROLL .. [[ then
						t.minReputation = nil;
					end
					return t;
				end]],
				races = HORDE_ONLY,
				groups = {
					i(8588),	-- Emerald Raptor (MOUNT!)
					i(18788),	-- Swift Blue Raptor (MOUNT!)
					i(18789),	-- Swift Olive Raptor (MOUNT!)
					i(18790),	-- Swift Orange Raptor (MOUNT!)
					i(8591),	-- Turquoise Raptor (MOUNT!)
					i(8592),	-- Violet Raptor (MOUNT!)
				},
			}),
		}),
		n(ZONE_DROPS, {
			i(4882, {	-- Benedict's Key
				coord = { 59.6, 58.2, MAP.DUROTAR },
				cr = 3192,	-- Lieutenant Benedict
			}),
			i(277661, {	-- Dull Storm Orb (QS!)
				coord = { 51.5, 21.6, MAP.DUROTAR },
				timeline = { TIMELINE.ADDED_1_60_1 },
				crs = {
					3118,	-- Dustwind Storm Witch
					276194,	-- Dustwind Eggtender
				},
			}),
			i(4903, {	-- Eye of Burning Shadow
				coord = { 51.78, 9.56, MAP.DUROTAR },
				cr = 3204,	-- Gazz'uz
			}),
			i(275724, {	-- Hexed Pendant
				description = "You can continue to Disenchant these to level your enchanting well beyond skill level 40.",
				timeline = { TIMELINE.ADDED_1_60_1 },
				crs = {
					3207,	-- Hexed Troll
					3206,	-- Voodoo Troll
				},
			}),
			i(5466, {	-- Scorpid Stinger
				maps = { MAP.DUROTAR },
				crs = {
					3126,	-- Armoured Scorpid
					3125,	-- Clattering Scorpid
					3226,	-- Corrupted Scorpid
					5823,	-- Death Flayer
					3127,	-- Venomtail Scorpid
				},
				description = "Only drops from scorpids in Durotar, excluding Echo Isles and Valley of Trials.",
			}),
			i(275722, {	-- Ukor's Lost Pack (QS!)
				coord = { 49.5, 56.4, MAP.DUROTAR },
				timeline = { TIMELINE.ADDED_1_60_1 },
				cr = 266851,	-- Ukorsbane
			}),
		}),
	},
});
