---------------------------------------------------
--          Z O N E S        M O D U L E         --
---------------------------------------------------

maproot(MAP.KALIMDOR, MAP.DARNASSUS, {
	lore = "The atmosphere inside the city is quiet and tranquil. It does not have the feeling of confinement that one would feel in Stormwind or Ironforge, where the buildings are grouped close together. Darnassus is open to the sky, and the graceful bridges spanning the lake around which it is built set the buildings wide apart. The elegant bridges, beautiful groves, and leaf-covered pathways that dot the city's landscape are testaments to the night elves' reverence for nature. One of Darnassus's most notable structures is the stunning Temple of the Moon, the center of worship for High Priestess Tyrande Whisperwind and her Sisters of Elune. The prime reason why the city's population is so low is that it is isolated: Teldrassil is a small island away from the main mass of Azeroth, and the only way to gain access from another continent is to fly or sail to Rut'theran Village, a small settlement at the base of Teldrassil, and from there step into the glowing portal to the city proper. Darnassus is home to night elves of all vocations and remains a symbol of the night elves' rich culture and glorious history.",
	icon = 255141,
	isRaid = true,
	groups = {
		n(FACTIONS, {
			faction(FACTION_DARNASSUS, {	-- Darnassus
				icon = 236449,
				OnTooltip = [[_.OnTooltipDB.RuneclothTurnIns]],
				races = ALLIANCE_ONLY,
			}),
		}),
		n(PROFESSIONS, {
			prof(ALCHEMY, {
				n(4160, {	-- Ainethil <Artisan Alchemist>
					coord = { 55.6, 24.6, MAP.DARNASSUS },
					races = ALLIANCE_ONLY,
					groups = ALCHEMY_RECIPES.EXPERT,
				}),
			}),
			prof(LEATHERWORKING, {
				n(4212, {	-- Telonis <Artisan Leatherworker>
					coord = { 64.6, 21.6, MAP.DARNASSUS },
					races = ALLIANCE_ONLY,
					groups = LEATHERWORKING_RECIPES.EXPERT,
				}),
			}),
		}),
		n(QUESTS, {
			q(7799, {	-- A Donation of Mageweave
				qg = 14725,	-- Raedon Duskstriker
				coord = { 64.0, 23.0, MAP.DARNASSUS },
				cost = { { "i", 4338, 60 } },	-- 60x Mageweave Cloth
				races = ALLIANCE_ONLY,
				lvl = 40,
			}),
			q(7800, {	-- A Donation of Runecloth
				qg = 14725,	-- Raedon Duskstriker
				coord = { 64.0, 23.0, MAP.DARNASSUS },
				cost = { { "i", 14047, 60 } },	-- 60x Runecloth
				races = ALLIANCE_ONLY,
				lvl = 50,
			}),
			q(7798, {	-- A Donation of Silk
				qg = 14725,	-- Raedon Duskstriker
				cost = { { "i", 4306, 60 } },	-- 60x Silk Cloth
				coord = { 64.0, 23.0, MAP.DARNASSUS },
				races = ALLIANCE_ONLY,
				lvl = 26,
			}),
			q(7792, {	-- A Donation of Wool
				qg = 14725,	-- Raedon Duskstriker
				cost = { { "i", 2592, 60 } },	-- 60x Wool Cloth
				coord = { 64.0, 23.0, MAP.DARNASSUS },
				races = ALLIANCE_ONLY,
				lvl = 12,
			}),
			q(5647, {	-- A Lack of Fear
				altQuests = {
					5641,	-- A Lack of Fear [Ironforge]
					5645,	-- A Lack of Fear [Stormwind City]
				},
				qg = 11401,	-- Priestess Alathea <Priest Trainer>
				coord = { 39.2, 81.0, MAP.DARNASSUS },
				maps = { MAP.IRONFORGE },
				classes = { PRIEST },
				races = { DWARF },
				lvl = 20,
				groups = {
					recipe(6346),	-- Fear Ward
				},
			}),
			q(7801, {	-- Additional Runecloth [Darnassus]
				sourceQuest = 7800,	-- A Donation of Runecloth
				qg = 14725,	-- Raedon Duskstriker
				coord = { 64.0, 23.0, MAP.DARNASSUS },
				maxReputation = { FACTION_DARNASSUS, EXALTED },
				cost = { { "i", 14047, 20 } },	-- 20x Runecloth
				races = ALLIANCE_ONLY,
				repeatable = true,
				lvl = 50,
			}),
			q(3763, {	-- Assisting Arch Druid Staghelm [Darnassus]
				qg = 6735,	-- Innkeeper Saelienne
				coord = { 67.4, 15.7, MAP.DARNASSUS },
				races = ALLIANCE_ONLY,
				isBreadcrumb = true,
				lvl = 47,
			}),
			q(3790, {	-- Assisting Arch Druid Staghelm [Ironforge]
				qg = 5111,	-- Innkeeper Firebrew
				coord = { 18.1, 51.5, MAP.IRONFORGE },
				races = ALLIANCE_ONLY,
				isBreadcrumb = true,
				lvl = 47,
			}),
			q(3789, {	-- Assisting Arch Druid Staghelm [Stormwind City]
				qg = 6740,	-- Innkeeper Allison
				coord = { 60.4, 75.3, MAP.STORMWIND_CITY },
				races = ALLIANCE_ONLY,
				isBreadcrumb = true,
				lvl = 47,
			}),
			q(4510, {	-- Calm Before the Storm (2/2)
				sourceQuest = 4508,	-- Calm Before the Storm (1/2)
				qg = 7740,	-- Gracina Spiritmight
				qi = 11843,	-- Bank Voucher
				coord = { 42.0, 85.8, MAP.DARNASSUS },
				races = ALLIANCE_ONLY,
				lvl = 50,
				groups = {
					i(11870),	-- Oblivion Orb
					i(11871),	-- Snarkshaw Spaulders
					i(11872),	-- Eschewal Greaves
				},
			}),
			q(5640, {	-- Desperate Prayer
				altQuests = {
					5634,	-- Desperate Prayer [Stormwind City #1]
					5635,	-- Desperate Prayer [Elwynn Forest]
					5636,	-- Desperate Prayer [Teldrassil]
					5637,	-- Desperate Prayer [Dun Morogh]
					5638,	-- Desperate Prayer [Stormwind City #2]
					5639,	-- Desperate Prayer [Ironforge]
				},
				qg = 11401,	-- Priestess Alathea <Priest Trainer>
				coord = { 39.6, 80.8, MAP.DARNASSUS },
				races = { HUMAN, DWARF },
				classes = { PRIEST },
				lvl = 10,
				groups = {
					{
						recipeID = 13908,	-- Desperate Prayer (Rank 1)
						rank = 1,
					},
				},
			}),
			q(2242, {	-- Destiny Calls
				sourceQuest = 2241,	-- The Apple Falls
				qg = 4163,	-- Syurna
				coord = { 37.0, 21.9, MAP.DARNASSUS },
				maps = { MAP.TELDRASSIL },
				races = ALLIANCE_ONLY,
				classes = { ROGUE },
				lvl = 10,
				groups = {
					objective(1, {	-- 0/1 Sethir's Journal
						provider = { "i", 7737 },	-- Sethir's Journal
						description = "This item can only be pickpocketed.",
						coord = { 37.6, 22.2, MAP.TELDRASSIL },
						cr = 6909,	-- Sethir the Ancient
					}),
					i(7298),	-- Blade of Cunning
				},
			}),
			q(5672, {	-- Elune's Grace [Darnassus]
				altQuests = {
					5675,	-- Elune's Grace [Ironforge]
					5673,	-- Elune's Grace [Stormwind City]
				},
				qg = 11401,	-- Priestess Alathea <Priest Trainer>
				coord = { 39.2, 81.0, MAP.DARNASSUS },
				classes = { PRIEST },
				races = { NIGHTELF },
				lvl = 20,
				groups = {
					{
						recipeID = 2651,	-- Elune's Grace (Rank 1)
						rank = 1,
					},
				},
			}),
			q(2260, {	-- Erion's Behest
				sourceQuest = 2259,	-- Erion Shadewhisper
				qg = 4214,	-- Erion Shadewhisper
				coord = { 34.6, 25.6, MAP.DARNASSUS },
				races = ALLIANCE_ONLY,
				classes = { ROGUE },
				isBreadcrumb = true,
				lvl = 16,
			}),
			q(98067, {	-- Eyes of the Sentinels
				qg = 8396,	-- Sentinel Dalia Sunblade
				coord = { 39.8, 89.3, MAP.DARNASSUS },
				timeline = { TIMELINE.ADDED_1_60_1 },
				maps = { MAP.TELDRASSIL },
				races = ALLIANCE_ONLY,
				groups = {
					objective(1, {	-- Cenarion Hold depths entrance
						provider = { "i", 279378 },	-- Lunar Pendant
						coord = { 33.7, 16.2, MAP.DARNASSUS },
					}),
					objective(2, {	-- Darnassus Bank
						provider = { "i", 279378 },	-- Lunar Pendant
						coord = { 41.0, 43.4, MAP.DARNASSUS },
					}),
					objective(3, {	-- Craftsman's Terrace Inn
						provider = { "i", 279378 },	-- Lunar Pendant
						coord = { 66.3, 15.6, MAP.DARNASSUS },
					}),
					objective(4, {	-- City Gate
						provider = { "i", 279378 },	-- Lunar Pendant
						coord = { 35.8, 54.2, MAP.TELDRASSIL },
					}),
				},
			}),
			q(952, {	-- Grove of the Ancients
				sourceQuest = 940,	-- Teldrassil
				qg = 3516,	-- Arch Druid Fandral Staghelm
				qi = 5390,	-- Fandral's Message
				coord = { 34.8, 8.8, MAP.DARNASSUS },
				races = ALLIANCE_ONLY,
				lvl = 6,
			}),
			q(97074, {	-- Learning to Ride
				qg = 4753,	-- Jartsam <Nightsaber Riding Instructor>
				coord = { 38.6, 16.0, MAP.DARNASSUS },
				races = { NIGHTELF },
				lvl = 40,
				timeline = { TIMELINE.ADDED_1_60_1 },
			}),
			q(4493, {	-- March of the Silithid (A)
				sourceQuest = 162,	-- Rise of the Silithid (A)
				qg = 7740,	-- Gracina Spiritmight
				coord = { 42.0, 85.8, MAP.DARNASSUS },
				maps = { MAP.TANARIS },
				races = ALLIANCE_ONLY,
				lvl = 50,
			}),
			q(1711, {	-- Mathiel's Armor
				sourceQuest = 1710,	-- Sunscorched Shells
				qg = 6142,	-- Mathiel
				coord = { 59.2, 45.4, MAP.DARNASSUS },
				classes = { WARRIOR },
				races = ALLIANCE_ONLY,
				lvl = 20,
				groups = {
					i(6973),	-- Fire hardened Leggings
				},
			}),
			q(1582, {	-- Moonglow Vest
				qg = 6034,	-- Lotherias
				coord = { 64.4, 22.2, MAP.DARNASSUS },
				cost = {
					{ "i", 2309, 5 },	-- 5x Embossed Leather Boots
					{ "i", 2310, 5 },	-- 5x Embossed Leather Cloak
					{ "i", 4239, 1 },	-- 1x Embossed Leather Gloves
				},
				requireSkill = LEATHERWORKING,
				races = ALLIANCE_ONLY,
				lvl = 8,
				groups = {
					i(6710),	-- Pattern: Moonglow Vest (RECIPE!)
				},
			}),
			q(3781, {	-- Morrowgrain Research (1/2)
				sourceQuest = 3764,	-- Un'Goro Soil
				qg = 3516,	-- Arch Druid Fandral Staghelm
				qi = 11103,	-- Seed Voucher
				coord = { 34.8, 8.8, MAP.DARNASSUS },
				races = ALLIANCE_ONLY,
				lvl = 47,
				groups = {
					i(11022),	-- Packet of Tharlendris Seeds
				},
			}),
			q(3785, {	-- Morrowgrain Research (2/2)
				sourceQuest = 3781,	-- Morrowgrain Research (1/2)
				qg = 4217,	-- Mathrengyl Bearwalker
				coord = { 35.2, 8.0, MAP.DARNASSUS },
				cost = { { "i", 11040, 10 } },	-- 10x Morrowgrain
				races = ALLIANCE_ONLY,
				lvl = 47,
				groups = {
					i(11887),	-- Cenarion Circle Cache
				},
			}),
			q(3803, {	-- Morrowgrain to Darnassus
				sourceQuest = 3785,	-- Morrowgrain Research (2/2)
				qg = 4217,	-- Mathrengyl Bearwalker
				coord = { 35.2, 8.0, MAP.DARNASSUS },
				cost = { { "i", 11040, 10 } },	-- 10x Morrowgrain
				races = ALLIANCE_ONLY,
				repeatable = true,
				lvl = 47,
				groups = {
					i(11887),	-- Cenarion Circle Cache
				},
			}),
			q(6344, {	-- Nessa Shadowsong / Reminders of Home [CATA+]
				qg = 4241,	-- Mydrannul
				coord = { 70.6, 45.3, MAP.DARNASSUS },
				maps = { MAP.TELDRASSIL },
				races = { NIGHTELF },
				isBreadcrumb = true,
				lvl = 10,
			}),
			q(2520, {	-- Sathrah's Sacrifice
				sourceQuest = 2518,	-- Tears of the Moon
				qg = 7313,	-- Priestess A'moora
				coord = { 36.4, 86.0, MAP.DARNASSUS },
				races = ALLIANCE_ONLY,
				lvl = 5,
				groups = {
					objective(1, {	-- Offer the sacrifice at the fountain
						provider = { "i", 8155 },	-- Sathrah's Sacrifice
					}),
					i(9600),	-- Lace Pants
					i(9601),	-- Cushioned Boots
				},
			}),
			q(1692, {	-- Smith Mathiel
				sourceQuest = 1686,	-- The Shade of Elura
				qg = 4088,	-- Elanaria
				qi = 6812,	-- Case of Elunite
				coord = { 57.4, 34.8, MAP.DARNASSUS },
				classes = { WARRIOR },
				races = ALLIANCE_ONLY,
				lvl = 10,
			}),
			q(5627, {	-- Stars of Elune / Returning Home [Darnassus]
				altQuests = {
					5629,	-- Returning Home [Teldrassil]
					5630,	-- Returning Home [Dun Morogh]
					5628,	-- Returning Home [Elwynn Forest]
					5633,	-- Returning Home [Ironforge]
					5631,	-- Returning Home [Stormwind City]
					5632,	-- Returning Home [Stormwind City]
				},
				qgs = {
					11401,	-- Priestess Alathea <Priest Trainer>
					3600,	-- Laurna Morninglight <Priest Trainer>
					1226,	-- Maxan Anvol <Priest Trainer>
					377,	-- Priestess Josetta <Priest Trainer>
					5142,	-- Braenna Flintcrag <Priest Trainer>
					5489,	-- Brother Joshua <Priest Trainer>
					11397,	-- Nara Meideros <Priest Trainer>
				},
				coords = {
					{ 39.2, 81.0, MAP.DARNASSUS },
					{ 55.6, 56.8, MAP.TELDRASSIL },
					{ 47.2, 52.2, MAP.DUN_MOROGH },
					{ 43.4, 65.6, MAP.ELWYNN_FOREST },
					{ 24.6, 9.2, MAP.IRONFORGE },
					{ 38.6, 26.8, MAP.STORMWIND_CITY },
					{ 20.8, 50.2, MAP.STORMWIND_CITY },
				},
				classes = { PRIEST },
				races = { NIGHTELF },
				lvl = 10,
				groups = {
					{
						recipeID = 10797,	-- Starshards (Rank 1)
						rank = 1,
					},
				},
			}),
			q(1710, {	-- Sunscorched Shells
				sourceQuest = 1703,	-- Mathiel
				qg = 6142,	-- Mathiel
				coord = { 59.2, 45.4, MAP.DARNASSUS },
				maps = { MAP.THOUSAND_NEEDLES },
				classes = { WARRIOR },
				races = ALLIANCE_ONLY,
				lvl = 20,
				groups = {
					objective(1, {	-- 0/20 Sunscorched Shell
						providers = {
							{ "i", 6849 },	-- Sunscorched Shell
							{ "o", 89635 },	-- Sunscorched Shell
						},
						coord = { 11.7, 37.1, MAP.THOUSAND_NEEDLES },
					}),
				},
			}),
			q(99205, {	-- Swift as the Wind
				qg = 4753,	-- Jartsam
				coord = { 38.4, 15.8, MAP.DARNASSUS },
				timeline = { TIMELINE.ADDED_1_60_1 },
				races = { NIGHTELF },
				lvl = 60,
				groups = {
					objective(1),	-- 0/1 Learn: Journeyman Riding
				},
			}),
			q(2518, {	-- Tears of the Moon
				sourceQuest = 2519,	-- The Temple of the Moon
				qg = 7313,	-- Priestess A'moora
				coord = { 36.4, 86.0, MAP.DARNASSUS },
				maps = { MAP.TELDRASSIL },
				races = ALLIANCE_ONLY,
				lvl = 5,
				groups = {
					objective(1, {	-- 0/1 Silvery Spinnerets
						provider = { "i", 8344 },	-- Silvery Spinnerets
						cr = 7319,	-- Lady Sathrah
						coords = {
							{ 38.8, 26.0, MAP.TELDRASSIL },
							{ 42.0, 25.6, MAP.TELDRASSIL },
							{ 48.0, 25.6, MAP.TELDRASSIL },
						},
					}),
				},
			}),
			q(942, {	-- The Absent Minded Prospector (4/5)
				sourceQuest = 741,	-- The Absent Minded Prospector (3/5) (Darkshore)
				qg = 2912,	-- Chief Archaeologist Greywhisker
				qi = 6812,	-- Mysterious Fossil
				coord = { 31.2, 84.2, MAP.DARNASSUS },
				maps = { MAP.WETLANDS },
				races = ALLIANCE_ONLY,
				lvl = 15,
			}),
			q(1039, {	-- The Barrens Port
				sourceQuest = 1038,	-- Velinde's Effects
				qg = 8026,	-- Thyn'tel Bladeweaver
				coord = { 61.8, 39.4, MAP.DARNASSUS },
				maps = { MAP.THE_BARRENS },
				races = ALLIANCE_ONLY,
				lvl = 25,
			}),
			q(1686, {	-- The Shade of Elura
				sourceQuest = 1683,	-- Vorlus Vilehoof
				qg = 4088,	-- Elanaria
				coord = { 57.8, 34.4, MAP.DARNASSUS },
				maps = { MAP.DARKSHORE },
				classes = { WARRIOR },
				races = ALLIANCE_ONLY,
				lvl = 10,
				groups = {
					objective(1, {	-- 0/8 Elunite Ore
						providers = {
							{ "i", 6808 },	-- Elunite Ore
							{ "o", 86492 },	-- Crate of Elunite
						},
						coord = { 33.1, 46.3, MAP.DARKSHORE },
					}),
					objective(2, {	-- 0/1 Elura's Medallion
						provider = { "i", 6809 },	-- Elura's Medallion
						coord = { 31.6, 44.8, MAP.DARKSHORE },
						cr = 6133,	-- Shade of Elura
					}),
				},
			}),
			q(2519, {	-- The Temple of the Moon
				sourceQuest = 98391,	-- The Sisterhood of Elune
				qg = 7316,	-- Sister Aquinne
				coord = { 29.0, 45.4, MAP.DARNASSUS },
				races = ALLIANCE_ONLY,
				isBreadcrumb = true,
				lvl = 5,
			}),
			q(730, {	-- Trouble In Darkshore?
				qg = 2912,	-- Chief Archaeologist Greywhisker
				coord = { 31.2, 84.2, MAP.DARNASSUS },
				races = ALLIANCE_ONLY,
				isBreadcrumb = true,
				lvl = 14,
			}),
			q(3764, {	-- Un'Goro Soil
				sourceQuests = {
					3763,	-- Assisting Arch Druid Staghelm [Darnassus]
					3790,	-- Assisting Arch Druid Staghelm [Ironforge]
					3789,	-- Assisting Arch Druid Staghelm [Stormwind City]
				},
				qg = 3516,	-- Arch Druid Fandral Staghelm
				coord = { 35.2, 9.0, MAP.DARNASSUS },
				maps = { MAP.UNGORO_CRATER },
				cost = { { "i", 11018, 20 } },	-- 20x Un'Goro Soil
				races = ALLIANCE_ONLY,
				lvl = 47,
			}),
			q(1038, {	-- Velinde's Effects
				sourceQuest = 1037,	-- Velinde Starsong (Ashenvale)
				qg = 8026,	-- Thyn'tel Bladeweaver
				coord = { 61.8, 39.4, MAP.DARNASSUS },
				races = ALLIANCE_ONLY,
				lvl = 25,
				groups = {
					objective(1, {	-- 0/1 Velinde's Journal
						providers = {
							{ "i", 5520 },	-- Velinde's Journal
							{ "o", 19877 },	-- Velinde's Locker
							{ "i", 5521 },	-- Velinde's Key
						},
						coord = { 62.5, 83.1, MAP.DARNASSUS },
					}),
				},
			}),
			q(1683, {	-- Vorlus Vilehoof
				sourceQuests = {
					1638,	-- A Warrior's Training
					1684,	-- Elanaria
					1679,	-- Muren Stormpike
				},
				qg = 4088,	-- Elanaria
				coord = { 57.3, 34.6, MAP.DARNASSUS },
				maps = { MAP.TELDRASSIL },
				classes = { WARRIOR },
				races = ALLIANCE_ONLY,
				lvl = 10,
				groups = {
					objective(1, {	-- 0/1 Horn of Vorlus
						provider = { "i", 6805 },	-- Horn of Vorlus
						coord = { 47.2, 63.6, MAP.TELDRASSIL },
						cr = 6128,	-- Vorlus Vilehoof
					}),
					recipe(71),	-- Defensive Stance
					--recipe(7386),	-- Sunder Armor	[TODO: Users are reporting they can't collect this.]
					recipe(355),	-- Taunt
				},
			}),
			q(1693, {	-- Weapons of Elunite
				sourceQuest = 1692,	-- Smith Mathiel
				qg = 6142,	-- Mathiel
				coord = { 59.2, 45.4, MAP.DARNASSUS },
				classes = { WARRIOR },
				races = ALLIANCE_ONLY,
				lvl = 10,
				groups = {
					i(6966),	-- Elunite Axe
					i(6967),	-- Elunite Sword
					i(6968),	-- Elunite Hammer
					i(6969),	-- Elunite Dagger
				},
			}),
		}),
		n(RIDING_TRAINER, {
			n(4753, {	-- Jartsam <Nightsaber Riding Instructor>
				coord = { 38.6, 16.0, MAP.DARNASSUS },
				races = ALLIANCE_ONLY,
				-- Available to Night Elves without faction requirements.
				minReputation = { FACTION_DARNASSUS, EXALTED },
				OnInit = [[function(t)
					if _.RaceIndex == ]] .. NIGHTELF .. [[ then
						t.minReputation = nil;
					end
					return t;
				end]],
				groups = {
					recipe(828, {	-- Tiger Riding
						cost = 200000,
						lvl = 40,
					}),
				},
			}),
		}),
		n(VENDORS, {
			n(4234, {	-- Andrus <Staff Merchant>
				coord = { 54.6, 83.2, MAP.DARNASSUS },
				races = ALLIANCE_ONLY,
				sym = {{ "select", "itemID",
					2527,	-- Battle Staff
					2535,	-- War Staff
				}},
			}),
			n(4172, {	-- Anadyia
				coord = { 54.6, 83.6, MAP.DARNASSUS },
				races = ALLIANCE_ONLY,
				sym = {
					SymSelector.select("VENDOR_ROBES"),	-- Robes
					{ "pop" },
				},
			}),
			n(4203, {	-- Ariyell Skyshadow <Weapon Merchant>
				coord = { 58.8, 44.5, MAP.DARNASSUS },
				races = ALLIANCE_ONLY,
				sym = {{ "select", "itemID",
				-- all done
					2025,	-- Bearded Axe
					15905,	-- Brass Knuckles
					1198,	-- Claymore
					2029,	-- Cleaver
					851,	-- Cutlass
					922,	-- Dacian Falx
					15904,	-- Deadly Fist Blades
					927,	-- Double Axe
					2024,	-- Espadon
					925,	-- Flail
					1197,	-- Giant Mace
					2030,	-- Gnarled Staff
					2028,	-- Hammer
					853,	-- Hatchet
					2207,	-- Jambiya
					2209,	-- Kris
					2507,	-- Laminated Recurve Bow
				15909,	-- Left-Handed Blades
				15906,	-- Left-Handed Brass Knuckles
				15907,	-- Left-Handed Claw
					928,	-- Long Staff
					852,	-- Mace
					924,	-- Maul
					854,	-- Quarter Staff
					3026,	-- Reinforced Bow
					2026,	-- Rock Hammer
					2027,	-- Scimitar
					15903,	-- Slicing Claw
					1196,	-- Tabar
				}},
			}),
			n(4240, {	-- Caynrus
				coord = { 55.4, 74.6, MAP.DARNASSUS },
				races = ALLIANCE_ONLY,
				sym = {{ "select", "itemID",
					2451,	-- Crested Heater Shield
					1201,	-- Dull Heater Shield
					2448,	-- Heavy Pavise
					2446,	-- Kite Shield
					2445,	-- Large Metal Shield
					2129,	-- Large Round Shield
					17189,	-- Metal Buckler
					17190,	-- Ornate Buckler
					17192,	-- Reinforced Targe
					17188,	-- Ringed Buckler
					17184,	-- Small Shield
					17186,	-- Small Targe
				}},
			}),
			n(4216, {	-- Chardryn <Herbalism Supplies>
				coord = { 49.55, 69.44, MAP.DARNASSUS },
				races = ALLIANCE_ONLY,
				groups = {
					i(22250, {	-- Herb Pouch
						description = "Only select Herbalism Suppliers sells this pouch.",
						providers = {
							{ "n", 4216 },	-- Chardryn <Herbalism Supplies>
							{ "n", 5503 },	-- Eldraeith <Herbalism Supplies> [TBC+] / <Herbalism Supplier>
							{ "n", 5138 },	-- Gwina Stonebranch <Herbalism Supplies> [TBC+] / <Herbalism Supplier>
							{ "n", 4615 },	-- Katrina Alliestar <Herbalism Supplies> [TBC+] / <Herbalism Supplier>
							{ "n", 3548 },	-- Selina Weston <Alchemy & Herbalism Supplies>
							{ "n", 3405 },	-- Zeal'aya <Herbalism Supplies>
						},
					}),
				},
			}),
			n(4164, {	-- Cylania
				coord = { 56.8, 53.6, MAP.DARNASSUS },
				races = ALLIANCE_ONLY,
				sym = {
					{ "select", "symselector",
						SymSelector.VENDOR_CHAINMAIL,	-- Chainmail
						SymSelector.VENDOR_HEAVY_WEAVE,	-- Heavy Weave
						SymSelector.VENDOR_KNITTED,	-- Knitted
						SymSelector.VENDOR_LIGHT_MAIL,	-- Light Mail
						SymSelector.VENDOR_ROUGH_LEATHER,	-- Rough Leather
						SymSelector.VENDOR_TANNED_LEATHER,	-- Tanned Leather
					},
					{ "pop" },
				},
			}),
			n(4236, {	-- Cyridan
				coord = { 52.6, 77.0, MAP.DARNASSUS },
				races = ALLIANCE_ONLY,
				sym = {
					{ "select", "symselector",
						SymSelector.VENDOR_CRACKED_LEATHER,	-- Cracked Leather
						SymSelector.VENDOR_CUIRBOULLI,	-- Cuirboulli
						SymSelector.VENDOR_CURED_LEATHER,	-- Cured Leather
						SymSelector.VENDOR_REINFORCED_LEATHER,	-- Reinforced Leather
						SymSelector.VENDOR_ROUGH_LEATHER,	-- Rough Leather
						SymSelector.VENDOR_STUDDED,	-- Studded
						SymSelector.VENDOR_TANNED_LEATHER,	-- Tanned Leather
					},
					{ "pop" },
					{ "select", "itemID",
						2463,	-- Studded Doublet
					},
				},
			}),
			n(4180, {	-- Ealyshia Dewwhisper
				coord = { 57.8, 71.6, MAP.DARNASSUS },
				races = ALLIANCE_ONLY,
				sym = {{ "select", "itemID",
					2523,	-- Bullova
					2521,	-- Flamberge
					2531,	-- Great Axe
					2525,	-- War Hammer
					2533,	-- War Maul
					2529,	-- Zweihander
				}},
			}),
			n(4168, {	-- Elynna <Tailoring Supplies>
				coord = { 64.6, 21.6, MAP.DARNASSUS },
				races = ALLIANCE_ONLY,
				groups = {
					i(6272, {	-- Pattern: Blue Linen Robe (RECIPE!)
						isLimited = true,
					}),
					i(6275, {	-- Pattern: Greater Adept's Robe (RECIPE!)
						isLimited = true,
					}),
					i(10311, {	-- Pattern: Orange Martial Shirt (RECIPE!)
						isLimited = true,
					}),
				},
			}),
			n(4223, {	-- Fyldan <Cooking Supplies> [TBC+] / Fyldan <Cooking Supplier>
				coord = { 48.5, 21.6, MAP.DARNASSUS },
				races = ALLIANCE_ONLY,
				sym = {{ "select", "itemID",
					2692,	-- Hot Spices
					2678,	-- Mild Spices
					159,	-- Refreshing Spring Water
					4536,	-- Shiny Red Apple
					10284,	-- Simple Flour
					4470,	-- Simple Wood
					3713,	-- Soothing Spices
					11291,	-- Star Wood
					272941,	-- Thick Logs
				}},
				groups = {
					i(21219),	-- Recipe: Sagefish Delight (RECIPE!)
					i(21099),	-- Recipe: Smoked Sagefish (RECIPE!)
				},
			}),
			n(4232, {	-- Glorandiir <Axe Merchant>
				coord = { 64.2, 59.0, MAP.DARNASSUS },
				races = ALLIANCE_ONLY,
				sym = {{ "select", "itemID",
					926,	-- Battle Axe
					2025,	-- Bearded Axe
					2523,	-- Bullova
					2029,	-- Cleaver
					2522,	-- Crescent Axe
					927,	-- Double Axe
					2530,	-- Francisca
					2531,	-- Great Axe
					853,	-- Hatchet
					12249,	-- Merciless Axe
					1196,	-- Tabar
				}},
				groups = {
					i(12249, {	-- Merciless Axe
						isLimited = true,
					}),
				},
			}),
			n(6735, {	-- Innkeeper Saelienne <Innkeeper>
				coord = { 67.2, 15.8, MAP.DARNASSUS },
				races = ALLIANCE_ONLY,
				sym = {
					{ "select", "symselector",
						SymSelector.VENDOR_FOOD_DRINK,	-- Drink
						SymSelector.VENDOR_FOOD_FRUIT,	-- Fruit
					},
					{ "pop" },
				},
			}),
			n(4231, {	-- Kieran <Weapon Merchant>
				coord = { 61.0, 63.6, MAP.DARNASSUS },
				races = ALLIANCE_ONLY,
				sym = {{ "select", "itemID",
					1194,	-- Bastard Sword
					2025,	-- Bearded Axe
					2479,	-- Broad Axe
					1198,	-- Claymore
					2029,	-- Cleaver
					2130,	-- Club
					2492,	-- Cudgel
					851,	-- Cutlass
					2139,	-- Dirk
					2024,	-- Espadon
					1197,	-- Giant Mace
					2488,	-- Gladius
					2030,	-- Gnarled Staff
					2134,	-- Hand Axe
					2028,	-- Hammer
					853,	-- Hatchet
					2207,	-- Jambiya
					2491,	-- Large Axe
					2480,	-- Large Club
					852,	-- Mace
					2208,	-- Poniard
					854,	-- Quarter Staff
					2026,	-- Rock Hammer
					2027,	-- Scimitar
					2131,	-- Shortsword
					2132,	-- Short Staff
					2494,	-- Stiletto
					1196,	-- Tabar
					2490,	-- Tomahawk
					2495,	-- Walking Stick
					2493,	-- Wooden Mallet
				}},
			}),
			n(3561, {	-- Kyrai
				coord = { 38.8, 35.4, MAP.DARNASSUS },
				races = ALLIANCE_ONLY,
			}),
			n(4173, {	-- Landria <Bow Merchant>
				coord = { 63.3, 66.3, MAP.DARNASSUS },
				races = ALLIANCE_ONLY,
				sym = {{ "select", "itemID",
					3027,	-- Heavy Recurve Bow
					3026,	-- Reinforced Bow
				}},
				groups = {
					i(11303, {	-- Fine Shortbow
						isLimited = true,
					}),
					i(287063, {	-- Serrated Knife
						isLimited = true,
						timeline = { TIMELINE.ADDED_1_60_1 },
					}),
					i(11306, {	-- Sturdy Recurve
						isLimited = true,
					}),
					i(11308, {	-- Sylvan Shortbow
						isLimited = true,
					}),
				},
			}),
			n(4730, {	-- Lelanai <Saber Handler>
				coord = { 38.3, 15.3, MAP.DARNASSUS },
				-- Available to Night Elves without faction requirements.
				minReputation = { FACTION_DARNASSUS, EXALTED },
				OnInit = [[function(t)
					if _.RaceIndex == ]] .. NIGHTELF .. [[ then
						t.minReputation = nil;
					end
					return t;
				end]],
				races = ALLIANCE_ONLY,
				groups = {
					i(8632),	-- Spotted Frostsaber (MOUNT!)
					i(8629),	-- Striped Nightsaber (MOUNT!)
					i(8631),	-- Striped Frostsaber (MOUNT!)
					i(274706, {	-- Striped Dawnsaber (MOUNT!)
						timeline = { TIMELINE.ADDED_1_60_1 },
					}),
					i(18766),	-- Swift Frostsaber (MOUNT!)
					i(18767),	-- Swift Mistsaber (MOUNT!)
					i(18902),	-- Swift Stormsaber (MOUNT!)
				},
			}),
			n(4177, {	-- Melea
				coord = { 55.6, 75.0, MAP.DARNASSUS },
				races = ALLIANCE_ONLY,
				sym = {
					{ "select", "symselector",
						SymSelector.VENDOR_AUGMENTED_CHAIN,	-- Augmented Chain
						SymSelector.VENDOR_BRIGANDINE,	-- Brigandine
						SymSelector.VENDOR_CHAINMAIL,	-- Chainmail
						SymSelector.VENDOR_LIGHT_MAIL,	-- Light Mail
						SymSelector.VENDOR_PLATEMAIL,	-- Platemail
						SymSelector.VENDOR_POLISHED_SCALE,	-- Polished Scale
						SymSelector.VENDOR_SCALEMAIL,	-- Scalemail
						SymSelector.VENDOR_TARNISHED_CHAIN,	-- Tarnished Chain
					},
					{ "pop" },
					{ "select", "itemID",
						2451,	-- Crested Heater Shield
						2448,	-- Heavy Pavise
						17189,	-- Metal Buckler
						17190,	-- Ornate Buckler
					},
				},
			}),
			n(4171, {	-- Merelyssa
				coord = { 61.6, 63.8, MAP.DARNASSUS },
				races = ALLIANCE_ONLY,
				sym = {{ "select", "itemID",
				-- added all
					2520,	-- Broadsword
					1198,	-- Claymore
					851,	-- Cutlass
					922,	-- Dacian Falx
					2024,	-- Espadon
					2528,	-- Falchion
					2207,	-- Jambiya
					2209,	-- Kris
					923,	-- Longsword
					2526,	-- Main Gauche
					2208,	-- Poniard
					2534,	-- Rondel
					2027,	-- Scimitar
				}},
			}),
			n(4233, {	-- Mythidan
				coord = { 60.4, 63.4, MAP.DARNASSUS },
				races = ALLIANCE_ONLY,
				sym = {{ "select", "itemID",
					925,	-- Flail
					1197,	-- Giant Mace
					2030,	-- Gnarled Staff
					2028,	-- Hammer
					928,	-- Long Staff
					852,	-- Mace
					924,	-- Maul
					854,	-- Quarter Staff
					2026,	-- Rock Hammer
				}},
			}),
			n(4229, {	-- Mythrin'dir <Trade Supplies> [TBC+] / Mythrin'dir <General Trade Supplier>
				coord = { 61.0, 17.7, MAP.DARNASSUS },
				races = ALLIANCE_ONLY,
				groups = {
					i(11223, {	-- Formula: Enchant Bracer - Deflection (RECIPE!)
						isLimited = true,
					}),
					i(16217, {	-- Formula: Enchant Shield - Greater Stamina (RECIPE!)
						isLimited = true,
					}),
				},
			}),
			n(4225, {	-- Saenorion <Leatherworking Supplies>
				coord = { 63.7, 22.3, MAP.DARNASSUS },
				races = ALLIANCE_ONLY,
				groups = {
					i(18949, {	-- Pattern: Barbaric Bracers (RECIPE!)
						isLimited = true,
					}),
					i(7451, {	-- Pattern: Green Whelp Bracers (RECIPE!)
						isLimited = true,
					}),
					i(252812, {	-- Pattern: Forceful Heavy Armor Kit (RECIPE!)
						timeline = { TIMELINE.ADDED_1_60_1 },
					}),
					i(252784, {	-- Pattern: Forceful Medium Armor Kit (RECIPE!)
						timeline = { TIMELINE.ADDED_1_60_1 },
					}),
					i(277716, {	-- Pattern: Light Leather Reagent Bag (RECIPE!)
						timeline = { TIMELINE.ADDED_1_60_1 },
					}),
					i(252811, {	-- Pattern: Mystic Heavy Armor Kit (RECIPE!)
						timeline = { TIMELINE.ADDED_1_60_1 },
					}),
					i(252783, {	-- Pattern: Mystic Medium Armor Kit (RECIPE!)
						timeline = { TIMELINE.ADDED_1_60_1 },
					}),
				},
			}),
			n(5191, {	-- Shalumon <Tabard Vendor>
				coord = { 70.4, 23.2, MAP.DARNASSUS },
				races = ALLIANCE_ONLY,
				sym = {{ "select", "itemID", 5976 }},	-- Guild Tabard
			}),
			n(8665, {	-- Shylenai <Owl Trainer>
				coord = { 69.8, 45.4, MAP.DARNASSUS },
				races = ALLIANCE_ONLY,
				groups = {
					i(8500),	-- Great Horned Owl (PET!)
					i(8501),	-- Hawk Owl (PET!)
					i(280803, {	-- Eagle Owl (PET!)
						timeline = { TIMELINE.ADDED_1_60_1 },
					}),
				},
			}),
			n(4235, {	-- Turian <Thrown Weapons Merchant>
				coord = { 62.7, 65.6, MAP.DARNASSUS },
				races = ALLIANCE_ONLY,
				groups = {
					i(12247, {	-- Broad Bladed Knife
						isLimited = true,
					}),
				},
			}),
			n(4226, {	-- Ulthir <Alchemy Supplies>
				coord = { 55.8, 24.5, MAP.DARNASSUS },
				races = ALLIANCE_ONLY,
				groups = {
					i(5642, {	-- Recipe: Free Action Potion (RECIPE!)
						isLimited = true,
					}),
					i(5643, {	-- Recipe: Great Rage Potion (RECIPE!)
						isLimited = true,
					}),
					i(13477),	-- Recipe: Superior Mana Potion (RECIPE!)
				},
			}),
			n(4228, {	-- Vaean <Enchanting Supplies>
				coord = { 58.6, 14.7, MAP.DARNASSUS },
				races = ALLIANCE_ONLY,
				sym = {{ "select", "itemID",
					20753,	-- Formula: Lesser Wizard Oil (RECIPE!)
					20752,	-- Formula: Minor Mana Oil (RECIPE!)
					20758,	-- Formula: Minor Wizard Oil (RECIPE!)
					6342,	-- Formula: Enchant Chest - Minor Intellect (RECIPE!)
					22307,	-- Pattern: Enchanted Mageweave Pouch (RECIPE!)
				}},
			}),
			n(4175, {	-- Vinasia <Cloth Armor Merchant>
				coord = { 60.7, 72.5, MAP.DARNASSUS },
				races = ALLIANCE_ONLY,
				sym = {
					{ "select", "symselector",
						SymSelector.VENDOR_EMBROIDERED,	-- Embroidered
						SymSelector.VENDOR_HEAVY_WEAVE,	-- Heavy Weave
						SymSelector.VENDOR_KNITTED,	-- Knitted
						SymSelector.VENDOR_PADDED,	-- Padded
						SymSelector.VENDOR_RUSSET,	-- Russet
						SymSelector.VENDOR_THICK_CLOTH,	-- Thick Cloth
						SymSelector.VENDOR_THIN_CLOTH,	-- Thin Cloth
					},
					{ "pop" },
				},
				groups = {
					i(12256, {	-- Cindercloth Leggings
						isLimited = true,
					}),
				},
			}),
		}),
	},
});
