---------------------------------------------------
--          Z O N E S        M O D U L E         --
---------------------------------------------------

maproot(MAP.KALIMDOR, MAP.MULGORE, {
	lore = "A land of windswept mesas and grassy plains, Mulgore is the tauren's ancestral homeland. Centaur often send raiding parties into Mulgore, and the tauren, now with the help of their Horde allies, beat them back. Tauren are naturally a nomadic people, and their tent cities are scattered across the landscape and change with the seasons and the weather.\n\nNow that they are members of the Horde, the tauren have constructed several permanent settlements, including fortified Dalsh-Beran and their capital of Thunder Bluff.",
	icon = 236809,
	groups = {
		m(CAMP_NARACHE, {
			lore = "Camp Narache is the starting area and town for the Tauren, which is located in southern Mulgore at the northern edge of the Red Cloud Mesa. Tauren Shamans will find their first totem quest here for the Earth Totem. Camp Narache is the main village of the Hawkwind Tribe, and its Chief is a member of that Tribe.",
			icon = 236454,
			zoneTextAreaIDs = {
				221,	-- Camp Narache
			},
			groups = {
				n(QUESTS, {
					q(752, {	-- A Humble Task (1/2)
						qg = 2981,	-- Chief Hawkwind
						coord = { 44.2, 76.0, MAP.MULGORE },
						races = HORDE_ONLY,
						groups = {
							i(247840, {	-- Mining for Dummies
								timeline = { TIMELINE.ADDED_1_60_1 },
							}),
							i(247841, {	-- Wild Harvest
								timeline = { TIMELINE.ADDED_1_60_1 },
							}),
							i(247846, {	-- Pelt Collecting for Beginners
								timeline = { TIMELINE.ADDED_1_60_1 },
							}),
						},
					}),
					q(753, {	-- A Humble Task (2/2)
						sourceQuest = 752,	-- A Humble Task (1/2)
						qg = 2991,	-- Greatmother Hawkwind
						coord = { 50.0, 81.0, MAP.MULGORE },
						races = HORDE_ONLY,
						groups = {
							objective(1, {	-- 0/1 Water Pitcher
								providers = {
									{ "i", 4755 },	-- Water Pitcher
									{ "o", 2907 },	-- Water Pitcher
								},
								coord = { 50.2, 81.3, MAP.MULGORE },
							}),
						},
					}),
					q(781, {	-- Attack on Camp Narache
						qs = 4851,	-- Dirt-stained Map (QS!)
						qi = 4850,	-- Bristleback Attack Plans (PQI!)
						provider = { "o", 3076 },	-- Dirt-stained Map
						coord = { 63.3, 82.6, MAP.MULGORE },
						races = HORDE_ONLY,
						groups = {
							i(4911),	-- Thick Bark Buckler
						},
					}),
					q(3376, {	-- Break Sharptusk!
						qg = 3209,	-- Brave Windfeather
						coord = { 44.8, 76.6, MAP.MULGORE },
						races = HORDE_ONLY,
						lvl = 3,
						groups = {
							objective(1, {	-- 0/1 Chief Sharptusk Thornmantle's Head
								provider = { "i", 10459 },	-- Chief Sharptusk Thornmantle's Head
								coord = { 64.6, 77.8, MAP.MULGORE },
								cr = 8554,	-- Chief Sharptusk Thornmantle
							}),
							i(10635),	-- Painted Chain Leggings
							i(10636),	-- Nomadic Gloves
						},
					}),
					q(1519, {	-- Call of Earth (1/3)
						altQuests = { 1516 },	-- Call of Earth (1/3 Durotar)
						qg = 5888,	-- Seer Ravenfeather
						coord = { 44.8, 76.2, MAP.MULGORE },
						races = HORDE_ONLY,
						classes = { SHAMAN },
						lvl = 4,
						groups = {
							objective(1, {	-- 0/2 Ritual Salve
								provider = { "i", 6634 },	-- Ritual Salve
								cr = 2953,	-- Bristleback Shaman
							}),
						},
					}),
					q(1520, {	-- Call of Earth (2/3)
						sourceQuest = 1519,	-- Call of Earth (1/3)
						altQuests = { 1517 },	-- Call of Earth (2/3 Durotar)
						qg = 5888,	-- Seer Ravenfeather
						qi = 6635,	-- Earth Sapta
						coord = { 44.8, 76.2, MAP.MULGORE },
						races = HORDE_ONLY,
						classes = { SHAMAN },
						lvl = 4,
					}),
					q(1521, {	-- Call of Earth (3/3)
						sourceQuest = 1520,	-- Call of Earth (2/3)
						altQuests = { 1518 },	-- Call of Earth (3/3 Durotar)
						qg = 5891,	-- Minor Manifestation of Earth
						qi = 6656,	-- Rough Quartz
						coord = { 53.8, 80.4, MAP.MULGORE },
						races = HORDE_ONLY,
						classes = { SHAMAN },
						lvl = 4,
						groups = {
							recipe(8071),	-- Stoneskin Totem
							i(5175, {	-- Earth Totem
								description = "You must keep this in your bags forever.",
							}),
						},
					}),
					q(1462, {	-- Earth Sapta
						sourceQuest = 1519,	-- Call of Earth (1/3)
						altQuests = { 1463 },	-- Earth Sapta (Durotar)
						qg = 5888,	-- Seer Ravenfeather
						coord = { 44.8, 76.2, MAP.MULGORE },
						races = HORDE_ONLY,
						classes = { SHAMAN },
						repeatable = true,
						lvl = 4,
						groups = {
							i(6635),	-- Earth Sapta
						},
					}),
					q(3092, {	-- Etched Note
						sourceQuest = 747,	-- The Hunt Begins
						qg = 2980,	-- Grull Hawkwind
						qi = 9565,	-- Etched Note
						coord = { 44.9, 77.1, MAP.MULGORE },
						races = { TAUREN },
						classes = { HUNTER },
					}),
					q(95805, {	-- Grace of An'she and Mu'sha
						qg = 2982,	-- Seer Graytongue
						coord = { 42.5, 90.1, MAP.MULGORE },
						timeline = { TIMELINE.ADDED_1_60_1 },
						races = HORDE_ONLY,
						groups = {
							objective(1, {	-- Use Pouch of Smoldering Incense at the Ritual Fire
								providers = {
									{ "i", 277199 },	-- Pouch of Smoldering Incense
									{ "o", 660739 },	-- Ritual Fire
								},
								coord = { 56.6, 88.7, MAP.MULGORE },
							}),
							i(277200),	-- Scorched Leather Pouch
						},
					}),
					q(757, {	-- Rite of Strength
						sourceQuest = 755,	-- Rites of the Earthmother (1/3)
						qg = 2982,	-- Seer Graytongue
						coord = { 42.6, 92.0, MAP.MULGORE },
						races = HORDE_ONLY,
						groups = {
							objective(1, {	-- 0/12 Bristleback Belt
								provider = { "i", 4770 },	-- Bristleback Belt
								crs = {
									2952,	-- Bristleback Quilboar
									2953,	-- Bristleback Shaman
								},
							}),
							i(12448, {	-- Light Hunting Rifle
								timeline = { REMOVED_1_7_0 },	-- CRIEVE NOTE: Might want to check this one.
							}),
							i(1382),	-- Rock Mace
							i(1383),	-- Stone Tomahawk
							i(2137),	-- Whittling Knife
							i(5776),	-- Elder's Cane
							i(5777),	-- Brave's Axe
						},
					}),
					q(755, {	-- Rites of the Earthmother (1/3)
						sourceQuest = 753,	-- A Humble Task (2/2)
						qg = 2981,	-- Chief Hawkwind
						coord = { 44.2, 76.1, MAP.MULGORE },
						races = HORDE_ONLY,
					}),
					q(763, {	-- Rites of the Earthmother (2/3)
						sourceQuest = 757,	-- Rite of Strength
						qg = 2981,	-- Chief Hawkwind
						qi = 4783,	-- Totem of Hawkwind
						coord = { 44.2, 76.1, MAP.MULGORE },
						races = HORDE_ONLY,
					}),
					q(3093, {	-- Rune-Inscribed Note
						sourceQuest = 747,	-- The Hunt Begins
						qg = 2980,	-- Grull Hawkwind
						qi = 9552,	-- Rune-Inscribed Note
						coords = { 44.9, 77.1, MAP.MULGORE },
						races = { TAUREN },
						classes = { SHAMAN },
					}),
					q(3091, {	-- Simple Note
						sourceQuest = 747,	-- The Hunt Begins
						qg = 2980,	-- Grull Hawkwind
						qi = 9547,	-- Simple Note
						coords = { 44.9, 77.1, MAP.MULGORE },
						races = { TAUREN },
						classes = { WARRIOR },
					}),
					q(96659, {	-- The Adventurer [Mulgore]
						altQuests = {
							96627,	-- The Adventurer [Elwynn Forest]
							96628,	-- The Adventurer [Dun Morogh]
							96630,	-- The Adventurer [Teldrassil]
							96638,	-- The Adventurer [Zephras Isle]
							96652,	-- The Adventurer [Durotar]
							96656,	-- The Adventurer [Tirisfal Glades]
						},
						qg = 2981,	-- Chief Hawkwind
						coord = { 44.2, 76.0, MAP.MULGORE },
						races = HORDE_ONLY,
						lvl = 4,
						isBreadcrumb = true,
						timeline = { TIMELINE.ADDED_1_60_1 },
						qi = 275019,	-- Supply Bundle (QI!)
					}),
					q(780, {	-- The Battleboars
						sourceQuest = 750,	-- The Hunt Continues
						qg = 2980,	-- Grull Hawkwind
						coord = { 44.9, 77.1, MAP.MULGORE },
						races = HORDE_ONLY,
						groups = {
							objective(1, {	-- 0/8 Battleboar Snout
								provider = { "i", 4848 },	-- Battleboar Snout
								crs = {
									2966,	-- Battleboar
									2954,	-- Bristleback Battleboar
								},
							}),
							objective(2, {	-- 0/8 Battleboar Flank
								provider = { "i", 4849 },	-- Battleboar Flank
								crs = {
									2966,	-- Battleboar
									2954,	-- Bristleback Battleboar
								},
							}),
							i(6059),	-- Nomadic Vest
						},
					}),
					q(747, {	-- The Hunt Begins
						qg = 2980,	-- Grull Hawkwind
						coord = { 44.9, 77.1, MAP.MULGORE },
						races = HORDE_ONLY,
						groups = {
							objective(1, {	-- 0/7 Plainstrider Meat
								provider = { "i", 4739 },	-- Plainstrider Meat
								cr = 2955,	-- Plainstrider
							}),
							objective(2, {	-- 0/7 Plainstrider Feather
								provider = { "i", 4740 },	-- Plainstrider Feather
								cr = 2955,	-- Plainstrider
							}),
							i(4954),	-- Nomadic Belt
							i(4910),	-- Painted Chain Gloves
						},
					}),
					q(750, {	-- The Hunt Continues
						sourceQuest = 747,	-- The Hunt Begins
						qg = 2980,	-- Grull Hawkwind
						coord = { 44.9, 77.1, MAP.MULGORE },
						races = HORDE_ONLY,
						groups = {
							objective(1, {	-- 0/10 Mountain Cougar Pelt
								provider = { "i", 4742 },	-- Mountain Cougar Pelt
								cr = 2961,	-- Mountain Cougar
							}),
							i(4908),	-- Nomadic Bracers
							i(4913),	-- Painted Chain Belt
						},
					}),
					q(3094, {	-- Verdant Note
						sourceQuest = 747,	-- The Hunt Begins
						qg = 2980,	-- Grull Hawkwind
						qi = 9581,	-- Verdant Note
						coord = { 44.9, 77.1, MAP.MULGORE },
						races = { TAUREN },
						classes = { DRUID },
					}),
				}),
				n(ZONE_DROPS, {
					i(1388, {	-- Crooked Staff
						cr = 2953,	-- Bristleback Shaman
					}),
					i(1384, {	-- Dull Blade
						cr = 2952,	-- Bristleback Quilboar
					}),
					i(4951, {	-- Squealer's Belt
						cr = 3229,	-- "Squealer" Thornmantle
					}),
				}),
			},
		}),
		n(ACHIEVEMENTS, {
			ach(736),	-- Explore Mulgore
		}),
		explorationHeader({
			exploration(404),	-- Bael'dun Digsite
			exploration(222),	-- Bloodhoof Village
			exploration(358, {	-- Brambleblade Ravine
				timeline = { TIMELINE.ADDED_1_60_1 },
			}),
			exploration(221),	-- Camp Narache
			exploration(818),	-- Palemane Rock
			exploration(224),	-- Ravaged Caravan
			exploration(220),	-- Red Cloud Mesa
			exploration(225),	-- Red Rocks
			exploration(17045, {	-- Skywatcher Plateau
				timeline = { TIMELINE.ADDED_1_60_1 },
			}),
			exploration(820),	-- The Golden Plains
			visit_exploration(821, {coord={61.9, 64.1, MAP.MULGORE}}),	-- The Rolling Plains
			exploration(360),	-- The Venture Co. Mine
			exploration(1638),	-- Thunder Bluff
			exploration(397),	-- Thunderhorn Water Well
			exploration(398),	-- Wildmane Water Well
			exploration(819),	-- Windfury Ridge
			exploration(396),	-- Winterhoof Water Well
		}),
		n(FACTIONS, {
			faction(FACTION_FOREVER_EARTHEN_RING, {	-- Earthen Ring
				icon = 456567,
				timeline = { TIMELINE.ADDED_1_60_1 },
			}),
		}),
		n(QUESTS, {
			q(96294, {	-- A Darker Truth
				qs = 273658,	-- Bloody Parchment (QS!)
				qg = 259118,	-- Muln Earthfury (quest recipient)
				coord = { 33.4, 22.4, MAP.MULGORE },
				timeline = { TIMELINE.ADDED_1_60_1 },
				races = exclude(TAUREN, HORDE_ONLY),
				lvl = 23,	-- Required level; quest level 30.
				groups = {
					objective(1, {	-- 0/1 Bloody Parchment
						provider = { "i", 273659 },	-- Bloody Parchment (delivery item)
					}),
				},
			}),
			q(99198, {	-- A Donation of Mageweave [H]
				qg = 276171,	-- Oura Stormspinner
				coord = { 34.2, 22.4, MAP.MULGORE },
				timeline = { TIMELINE.ADDED_1_60_1 },
				cost = {{ "i", 4338, 60 }},	-- Mageweave Cloth
				races = HORDE_ONLY,
				lvl = 40,
			}),
			q(99199, {	-- A Donation of Runecloth
				qg = 276171,	-- Oura Stormspinner
				coord = { 34.2, 22.4, MAP.MULGORE },
				timeline = { TIMELINE.ADDED_1_60_1 },
				cost = {{ "i", 14047, 60 }},	-- Runecloth
				races = HORDE_ONLY,
				lvl = 50,
			}),
			q(99197, {	-- A Donation of Silk
				-- Not yet available in game.
				timeline = { TIMELINE.CREATED_1_60_1 },
				races = HORDE_ONLY,
				lvl = 26,
			}),
			q(99196, {	-- A Donation of Wool
				qg = 276171,	-- Oura Stormspinner
				coord = { 34.2, 22.4, MAP.MULGORE },
				timeline = { TIMELINE.ADDED_1_60_1 },
				cost = {{ "i", 2592, 60 }},	-- Wool Cloth
				races = HORDE_ONLY,
				lvl = 12,
			}),
			q(833, {	-- A Sacred Burial
				qg = 3233,	-- Lorekeeper Raintotem
				coord = { 57.0, 34.6, MAP.MULGORE },
				races = HORDE_ONLY,
				lvl = 7,
				groups = {
					objective(1, {	-- 0/8 Bristleback Interloper slain
						provider = { "n", 3232 },	-- Bristleback Interloper
						coord = { 58.8, 29.8, MAP.MULGORE },
					}),
				},
			}),
			q(1656, {	-- A Task Unfinished
				qg = 6775,	-- Antur Fallow
				qi = 7626,	-- Bundle of Furs
				coord = { 38.6, 81.6, MAP.MULGORE },
				races = HORDE_ONLY,
			}),
			q(97927, {	-- Camping 101: Alchemy [Mulgore]
				sourceQuest = 96605,	-- The Great Outdoors [Mulgore]
				altQuests = {
					96045,	-- Camping 101: Alchemy [Dun Morogh]
					97899,	-- Camping 101: Alchemy [Durotar]
					97915,	-- Camping 101: Alchemy [Elwynn Forest]
					97938,	-- Camping 101: Alchemy [Teldrassil]
					97951,	-- Camping 101: Alchemy [Tirisfal Glades]
					97963,	-- Camping 101: Alchemy
				},
				qg = 265810,	-- Kaga Wildhoof <Adventurer>
				coord = { 46.2, 67.2, MAP.MULGORE },
				maps = { MAP.THUNDER_BLUFF },
				requireSkill = ALCHEMY,
				races = HORDE_ONLY,
				lvl = 4,
				lockCriteria = { 1, "spellID", 1230564 },
				timeline = { TIMELINE.ADDED_1_60_1 },
				groups = {
					recipe(1230564),	-- Alchemy: Mana Well
				},
			}),
			q(97928, {	-- Camping 101: Blacksmithing [Mulgore]
				sourceQuest = 96605,	-- The Great Outdoors [Mulgore]
				altQuests = {
					96044,	-- Camping 101: Blacksmithing [Dun Morogh]
					97900,	-- Camping 101: Blacksmithing [Durotar]
					97916,	-- Camping 101: Blacksmithing [Elwynn Forest]
					97939,	-- Camping 101: Blacksmithing [Teldrassil]
					97952,	-- Camping 101: Blacksmithing [Tirisfal Glades]
					97964,	-- Camping 101: Blacksmithing
				},
				qg = 265810,	-- Kaga Wildhoof <Adventurer>
				coord = { 46.2, 67.2, MAP.MULGORE },
				maps = { MAP.THUNDER_BLUFF },
				requireSkill = BLACKSMITHING,
				races = HORDE_ONLY,
				lvl = 4,
				lockCriteria = { 1, "spellID", 1230171 },
				timeline = { TIMELINE.ADDED_1_60_1 },
				groups = {
					recipe(1230171),	-- Blacksmithing: Sharpening Wheel
				},
			}),
			q(96661, {	-- Camping 101: Cooking [Mulgore]
				sourceQuest = 96605,	-- The Great Outdoors [Mulgore]
				altQuests = {
					96626,	-- Camping 101: Cooking [Elwynn Forest]
					96629,	-- Camping 101: Cooking [Dun Morogh]
					96634,	-- Camping 101: Cooking [Teldrassil]
					96646,	-- Camping 101: Cooking
					96655,	-- Camping 101: Cooking [Durotar]
					96658,	-- Camping 101: Cooking [Tirisfal Glades]
				},
				qg = 265810,	-- Kaga Wildhoof <Adventurer>
				coord = { 46.2, 67.2, MAP.MULGORE },
				races = HORDE_ONLY,
				lvl = 4,
				timeline = { TIMELINE.ADDED_1_60_1 },
			}),
			q(97929, {	-- Camping 101: Enchanting [Mulgore]
				sourceQuest = 96605,	-- The Great Outdoors [Mulgore]
				altQuests = {
					96059,	-- Camping 101: Enchanting [Dun Morogh]
					97901,	-- Camping 101: Enchanting [Durotar]
					97917,	-- Camping 101: Enchanting [Elwynn Forest]
					97940,	-- Camping 101: Enchanting [Teldrassil]
					97953,	-- Camping 101: Enchanting [Tirisfal Glades]
					98284,	-- Camping 101: Enchanting
					98286,	-- Camping 101: Enchanting
				},
				qg = 265810,	-- Kaga Wildhoof <Adventurer>
				coord = { 46.2, 67.2, MAP.MULGORE },
				requireSkill = ENCHANTING,
				races = HORDE_ONLY,
				lvl = 4,
				lockCriteria = { 1, "spellID", 1230643 },
				timeline = { TIMELINE.ADDED_1_60_1 },
				groups = {
					recipe(1230643),	-- Enchanting: Enchanted Lute
				},
			}),
			q(97930, {	-- Camping 101: Engineering [Mulgore]
				sourceQuest = 96605,	-- The Great Outdoors [Mulgore]
				altQuests = {
					96058,	-- Camping 101: Engineering [Dun Morogh]
					97902,	-- Camping 101: Engineering [Durotar]
					97918,	-- Camping 101: Engineering [Elwynn Forest]
					97941,	-- Camping 101: Engineering [Teldrassil]
					97954,	-- Camping 101: Engineering [Tirisfal Glades]
					98285,	-- Camping 101: Engineering
					98287,	-- Camping 101: Engineering
				},
				qg = 265810,	-- Kaga Wildhoof <Adventurer>
				coord = { 46.2, 67.2, MAP.MULGORE },
				requireSkill = ENGINEERING,
				races = HORDE_ONLY,
				lvl = 4,
				lockCriteria = { 1, "spellID", 1230656 },
				timeline = { TIMELINE.ADDED_1_60_1 },
				groups = {
					recipe(1230656),	-- Engineering: Reagent Bot
				},
			}),
			q(97931, {	-- Camping 101: First Aid [Mulgore]
				sourceQuest = 96605,	-- The Great Outdoors [Mulgore]
				altQuests = {
					96047,	-- Camping 101: First Aid [Dun Morogh]
					97903,	-- Camping 101: First Aid [Durotar]
					97919,	-- Camping 101: First Aid [Elwynn Forest]
					97942,	-- Camping 101: First Aid [Teldrassil]
					97955,	-- Camping 101: First Aid [Tirisfal Glades]
					97965,	-- Camping 101: First Aid
				},
				qg = 265810,	-- Kaga Wildhoof <Adventurer>
				coord = { 46.2, 67.2, MAP.MULGORE },
				requireSkill = FIRST_AID,
				races = HORDE_ONLY,
				lvl = 4,
				lockCriteria = { 1, "spellID", 1230117 },
				timeline = { TIMELINE.ADDED_1_60_1 },
				groups = {
					recipe(1230117),	-- First Aid: First Aid Kit
				},
			}),
			q(97932, {	-- Camping 101: Fishing [Mulgore]
				sourceQuest = 96605,	-- The Great Outdoors [Mulgore]
				altQuests = {
					96050,	-- Camping 101: Fishing [Dun Morogh]
					97904,	-- Camping 101: Fishing [Durotar]
					97920,	-- Camping 101: Fishing [Elwynn Forest]
					97943,	-- Camping 101: Fishing [Teldrassil]
					97956,	-- Camping 101: Fishing [Tirisfal Glades]
					97967,	-- Camping 101: Fishing
				},
				qg = 265810,	-- Kaga Wildhoof <Adventurer>
				coord = { 46.2, 67.2, MAP.MULGORE },
				requireSkill = FISHING,
				races = HORDE_ONLY,
				lvl = 4,
				lockCriteria = { 1, "spellID", 1229745 },
				timeline = { TIMELINE.ADDED_1_60_1 },
				groups = {
					recipe(1229745),	-- Fishing: Fish Bowl
				},
			}),
			q(97933, {	-- Camping 101: Herbalism [Mulgore]
				sourceQuest = 96605,	-- The Great Outdoors [Mulgore]
				altQuests = {
					96055,	-- Camping 101: Herbalism [Dun Morogh]
					97905,	-- Camping 101: Herbalism [Durotar]
					97921,	-- Camping 101: Herbalism [Elwynn Forest]
					97944,	-- Camping 101: Herbalism [Teldrassil]
					97957,	-- Camping 101: Herbalism [Tirisfal Glades]
					97968,	-- Camping 101: Herbalism
				},
				qg = 265810,	-- Kaga Wildhoof <Adventurer>
				coord = { 46.2, 67.2, MAP.MULGORE },
				maps = { MAP.THUNDER_BLUFF },
				requireSkill = HERBALISM,
				races = HORDE_ONLY,
				lvl = 4,
				lockCriteria = { 1, "spellID", 1229705 },
				timeline = { TIMELINE.ADDED_1_60_1 },
				groups = {
					recipe(1229705),	-- Herbalism: Incense Candle
				},
			}),
			q(97934, {	-- Camping 101: Leatherworking [Mulgore]
				sourceQuest = 96605,	-- The Great Outdoors [Mulgore]
				altQuests = {
					96031,	-- Camping 101: Leatherworking [Dun Morogh]
					97906,	-- Camping 101: Leatherworking [Durotar]
					97922,	-- Camping 101: Leatherworking [Elwynn Forest]
					97946,	-- Camping 101: Leatherworking [Teldrassil]
					97958,	-- Camping 101: Leatherworking [Tirisfal Glades]
					97969,	-- Camping 101: Leatherworking
				},
				qg = 265810,	-- Kaga Wildhoof <Adventurer>
				coord = { 46.2, 67.2, MAP.MULGORE },
				requireSkill = LEATHERWORKING,
				races = HORDE_ONLY,
				lvl = 4,
				lockCriteria = { 1, "spellID", 1229432 },
				timeline = { TIMELINE.ADDED_1_60_1 },
				groups = {
					recipe(1229432),	-- Leatherworking: Camp Tent
				},
			}),
			q(97935, {	-- Camping 101: Mining [Mulgore]
				sourceQuest = 96605,	-- The Great Outdoors [Mulgore]
				altQuests = {
					96046,	-- Camping 101: Mining [Dun Morogh]
					97907,	-- Camping 101: Mining [Durotar]
					97923,	-- Camping 101: Mining [Elwynn Forest]
					97948,	-- Camping 101: Mining [Teldrassil]
					97959,	-- Camping 101: Mining [Tirisfal Glades]
					97970,	-- Camping 101: Mining
				},
				qg = 265810,	-- Kaga Wildhoof <Adventurer>
				coord = { 46.2, 67.2, MAP.MULGORE },
				maps = { MAP.THUNDER_BLUFF },
				requireSkill = MINING,
				races = HORDE_ONLY,
				lvl = 4,
				lockCriteria = { 1, "spellID", 1230161 },
				timeline = { TIMELINE.ADDED_1_60_1 },
				groups = {
					recipe(1230161),	-- Mining: Lodestone
				},
			}),
			q(97936, {	-- Camping 101: Skinning [Mulgore]
				sourceQuest = 96605,	-- The Great Outdoors [Mulgore]
				altQuests = {
					96056,	-- Camping 101: Skinning [Dun Morogh]
					97908,	-- Camping 101: Skinning [Durotar]
					97924,	-- Camping 101: Skinning [Elwynn Forest]
					97949,	-- Camping 101: Skinning [Teldrassil]
					97960,	-- Camping 101: Skinning [Tirisfal Glades]
					97971,	-- Camping 101: Skinning
				},
				qg = 265810,	-- Kaga Wildhoof <Adventurer>
				coord = { 46.2, 67.2, MAP.MULGORE },
				requireSkill = SKINNING,
				races = HORDE_ONLY,
				lvl = 4,
				lockCriteria = { 1, "spellID", 1229517 },
				timeline = { TIMELINE.ADDED_1_60_1 },
				groups = {
					recipe(1229517),	-- Skinning: Camp Chair
				},
			}),
			q(97937, {	-- Camping 101: Tailoring [Mulgore]
				sourceQuest = 96605,	-- The Great Outdoors [Mulgore]
				altQuests = {
					96057,	-- Camping 101: Tailoring [Dun Morogh]
					96102,	-- Camping 101: Tailoring [Durotar]
					97925,	-- Camping 101: Tailoring [Elwynn Forest]
					97950,	-- Camping 101: Tailoring [Teldrassil]
					97961,	-- Camping 101: Tailoring [Tirisfal Glades]
					97972,	-- Camping 101: Tailoring
					97973,	-- Camping 101: Tailoring
				},
				qg = 265810,	-- Kaga Wildhoof <Adventurer>
				coord = { 46.2, 67.2, MAP.MULGORE },
				requireSkill = TAILORING,
				races = HORDE_ONLY,
				lvl = 4,
				lockCriteria = { 1, "spellID", 1229504 },
				timeline = { TIMELINE.ADDED_1_60_1 },
				groups = {
					recipe(1229504),	-- Faction Banner (Horde)
				},
			}),
			q(98427, {	-- Ceasing Operations
				sourceQuest = 98424,	-- Fizsprocket's Notes
				qg = 2988,	-- Morin Cloudstalker
				coord = { 54.4, 60.4, MAP.MULGORE },
				timeline = { TIMELINE.ADDED_1_60_1 },
				races = { UNDEAD, TAUREN },
				lvl = 5,
				groups = {
					objective(1, {	-- 0/1 Clearcutter Key
						provider = { "i", 281048 },	-- Clearcutter Key
						coord = { 56.8, 43.0, MAP.MULGORE },
						cr = 272173,	-- Venture Co. Clearclutter
					}),
					i(281059),	-- Loose Clearcutter Blade
					i(282285),	-- Clearcutter Key
				},
			}),
			q(96130, {	-- Chakuyak
				qg = 3065,	-- Yaw Sharpmane
				coord = { 46.9, 59.6, MAP.MULGORE },
				timeline = { TIMELINE.ADDED_1_60_1 },
				races = HORDE_ONLY,
				lvl = 5,
				groups = {
					objective(1, {	-- Chakuyak's Pelt
						provider = { "i", 270302 },	-- Chakuyak's Pelt
						cr = 268558,	-- Chakuyak
						coord = { 38.5, 63.1, MAP.MULGORE },
					}),
					i(281266),	-- Furred Belt
				},
			}),
			q(94911, {	-- Child of Nature
				qg = 259118,	-- Muln Earthfury <Earthen Ring>
				coord = { 33.4, 22.5, MAP.MULGORE },
				races = { SKYBORNE_HORDE },
				classes = { DRUID },
				lvl = 10,
				timeline = { TIMELINE.ADDED_1_60_1 },
			}),
			q(743, {	-- Dangers of the Windfury
				qg = 2985,	-- Ruul Eagletalon
				coord = { 47.4, 62.0, MAP.MULGORE },
				races = HORDE_ONLY,
				lvl = 5,
				groups = {
					objective(1, {	-- 0/8 Windfury Talon
						provider = { "i", 4751 },	-- Windfury Talon
						crs = {
							2962,	-- Windfury Harpy
							2963,	-- Windfury Wind Witch
						},
					}),
				},
			}),
			q(96259, {	-- Defending the Dead
				qg = 259118,	-- Muln Earthfury
				coord = { 33.4, 22.4, MAP.MULGORE },
				timeline = { TIMELINE.ADDED_1_60_1 },
				races = exclude(TAUREN, HORDE_ONLY),
				lvl = 23,	-- Required level; quest level 30.
				groups = {
					objective(1, {	-- 0/10 Gloomrise Hatchling slain
						provider = { "n", 264079 },	-- Gloomrise Hatchling
					}),
					objective(2, {	-- 0/5 Gloomrise Soldier slain
						provider = { "n", 264083 },	-- Gloomrise Soldier
					}),
				},
			}),
			q(99080, {	-- Drive Them Out
				sourceQuests = {
					99101,	-- Our Ancient Enemy
				},
				qg = 2993,	-- Baine Bloodhoof
				coord = { 47.4, 60.2, MAP.MULGORE },
				timeline = { TIMELINE.ADDED_1_60_1 },
				races = HORDE_ONLY,
				lvl = 4,
				groups = {
					objective(1, {	-- Galak Centaur slain
						provider = { "n", 2967 },	-- Galak Centaur
						coord = { 59.3, 57.3, MAP.MULGORE },
					}),
					objective(2, {	-- Galak Outrunner slain
						provider = { "n", 2968 },	-- Galak Outrunner
						coord = { 59.8, 59.4, MAP.MULGORE },
					}),
					objective(3, {	-- Herak's Head
						provider = { "i", 286075 },	-- Herak's Head
						cr = 275767,	-- Herak the Pillager
						coord = { 60.5, 59.7, MAP.MULGORE },
					}),
				},
			}),
			q(746, {	-- Dwarven Digging
				qg = 2993,	-- Baine Bloodhoof
				coord = { 47.5, 60.2, MAP.MULGORE },
				races = HORDE_ONLY,
				lvl = 6,
				groups = {
					objective(1, {	-- 0/5 Broken Tools
						providers = {
							{ "i", 4703 },	-- Broken Tools
							{ "o", 1685 },	-- Forge
						},
						cost = { { "i", 4702, 5 } },	-- Prospector's Pick
						coord = { 34.0, 46.0, MAP.MULGORE },
						crs = {
							2990,	-- Bael'dun Appraiser
							2989,	-- Bael'dun Digger
						},
					}),
					i(4969),	-- Fortified Bindings
					i(4970),	-- Rough-hewn Kodo Leggings
				},
			}),
			q(98424, {	-- Fizsprocket's Notes
				qs = 281031,	-- Mulgore Expansion Plans (QS!)
				coord = { 64.4, 43.6, MAP.MULGORE },
				timeline = { TIMELINE.ADDED_1_60_1 },
				races = HORDE_ONLY,
				lvl = 5,
				groups = {
					objective(1, {	-- 0/1 Shredder Operation Instructions
						providers = {
							{ "i", 281035 },	-- Shredder Operation Instructions
							{ "o", 673494 },	-- Shredder Operation Instructions
						},
					}),
					objective(2, {	-- 0/1 Barrens Operations Best Practices
						providers = {
							{ "i", 281036 },	-- Barrens Operations Best Practices
							{ "o", 673496 },	-- Barrens Operations Best Practices
						},
					}),
					objective(3, {	-- 0/1 One "Gerenzo", of Stonetalon
						providers = {
							{ "i", 281037 },	-- One "Gerenzo", of Stonetalon
							{ "o", 673497 },	-- One "Gerenzo", of Stonetalon
						},
					}),
				},
			}),
			q(99081, {	-- Grim Tidings
				sourceQuests = {
					99079,	-- Longwalker Malah
				},
				qg = 275789,	-- Malah Longwind
				qi = 286104,	-- Longwalker Malah's Report
				coord = { 57.6, 63.2, MAP.MULGORE },
				timeline = { TIMELINE.ADDED_1_60_1 },
				races = HORDE_ONLY,
				lvl = 4,
			}),
			q(5655, {	-- Hex of Weakness [Mulgore]
				altQuests = {
					5652,	-- Hex of Weakness [Orgrimmar]
					5654,	-- Hex of Weakness [Durotar]
					5656,	-- Hex of Weakness [Thunder Bluff]
					5657,	-- Hex of Weakness [Undercity]
				},
				qg = 11407,	-- Var'jun
				coord = { 47.0, 58.8, MAP.MULGORE },
				classes = { PRIEST },
				races = { TROLL },
				lvl = 10,
				groups = {
					{
						recipeID = 9035,	-- Hex of Weakness (Rank 1)
						rank = 1,
					},
				},
			}),
			q(775, {	-- Journey into Thunder Bluff
				sourceQuest = 773,	-- Rite of Wisdom
				qg = 2994,	-- Ancestral Spirit
				coord = { 61.4, 21.0, MAP.MULGORE },
				maps = { MAP.THUNDER_BLUFF },
				races = HORDE_ONLY,
				lvl = 3,
			}),
			q(99411, {	-- Kyle's Gone Missing!
				qg = 277182,	-- Ahab Wheathoof
				coord = { 47.2, 57.6, MAP.MULGORE },
				timeline = { TIMELINE.ADDED_1_60_1 },
				races = HORDE_ONLY,
				lvl = 5,
				groups = {
					objective(1, {	-- 0/1 Kyle Fed
						providers = {
							{ "n", 277154 },	-- Kyle the Frenzied
							{ "i", 287505 },	-- Tender Strider Meat
						},
						coord = { 46.2, 63.2, MAP.MULGORE },
						crs = {
							2956,	-- Adult Plainstrider
							2957,	-- Elder Plainstrider
							3068,	-- Mazzranache
						},
					}),
				},
			}),
			q(97204, {	-- Learning to Ride
				qg = 3690,	-- Kar Stormsinger <Kodo Riding Instructor>
				coord = { 47.6, 58.4, MAP.MULGORE },
				races = { TAUREN },
				lvl = 40,
				timeline = { TIMELINE.ADDED_1_60_1 },
			}),
			q(99079, {	-- Longwalker Malah
				qg = 3222,	-- Brave Wildrunner
				coord = { 46.6, 63.0, MAP.MULGORE },
				timeline = { TIMELINE.ADDED_1_60_1 },
				races = HORDE_ONLY,
				lvl = 4,
				groups = {
					objective(1, {	-- Find Longwalker Malah
						provider = { "n", 275789 },	-- Malah Longwind
						coord = { 57.6, 63.2, MAP.MULGORE },
					}),
				},
			}),
			q(766, {	-- Mazzranache
				qg = 3055,	-- Maur Raincaller
				coord = { 47.0, 57.0, MAP.MULGORE },
				races = HORDE_ONLY,
				lvl = 5,
				groups = {
					objective(1, {	-- 0/1 Prairie Wolf Heart
						provider = { "i", 4804 },	-- Prairie Wolf Heart
						crs = {
							2959,	-- Prairie Stalker
							2958,	-- Prairie Wolf
							2960,	-- Prairie Wolf Alpha
						},
					}),
					objective(2, {	-- 0/1 Flatland Cougar Femur
						provider = { "i", 4805 },	-- Flatland Cougar Femur
						cr = 3035,	-- Flatland Cougar
					}),
					objective(3, {	-- 0/1 Plainstrider Scale
						provider = { "i", 4806 },	-- Plainstrider Scale
						crs = {
							2956,	-- Adult Plainstrider
							2957,	-- Elder Plainstrider
							3068,	-- Mazzranache
						},
					}),
					objective(4, {	-- 0/1 Swoop Gizzard
						provider = { "i", 4807 },	-- Swoop Gizzard
						crs = {
							2970,	-- Swoop
							2971,	-- Taloned Swoop
							2969,	-- Wiry Swoop
						},
					}),
					i(4972),	-- Cliff Runner Boots
					i(4973),	-- Plains Hunter Wristguards
				},
			}),
			q(99101, {	-- Our Ancient Enemy
				sourceQuests = {
					99081,	-- Grim Tidings
				},
				qg = 3222,	-- Brave Wildrunner
				qi = 286104,	-- Longwalker Malah's Report
				coord = { 46.6, 63.0, MAP.MULGORE },
				timeline = { TIMELINE.ADDED_1_60_1 },
				races = HORDE_ONLY,
				lvl = 4,
				groups = {
					objective(1, {	-- Bring Longwalker Malah's Report to Baine Bloodhoof
						provider = { "n", 2993 },	-- Baine Bloodhoof
						coord = { 47.4, 60.2, MAP.MULGORE },
					}),
				},
			}),
			q(748, {	-- Poison Water
				qg = 2948,	-- Mull Thunderhorn
				coord = { 48.5, 60.4, MAP.MULGORE },
				races = { TAUREN },
				lvl = 4,
				groups = {
					objective(1, {	-- 0/6 Prairie Wolf Paw
						provider = { "i", 4758 },	-- Prairie Wolf Paw
						crs = {
							2959,	-- Prairie Stalker
							2958,	-- Prairie Wolf
							2960,	-- Prairie Wolf Alpha
						},
					}),
					objective(2, {	-- 0/4 Plainstrider Talon
						provider = { "i", 4759 },	-- Plainstrider Talon
						crs = {
							2956,	-- Adult Plainstrider
							2957,	-- Elder Plainstrider
							3068,	-- Mazzranache
						},
					}),
				},
			}),
			q(744, {	-- Preparation for Ceremony
				qg = 2987,	-- Eyahn Eagletalon
				coord = { 37.6, 59.8, MAP.THUNDER_BLUFF },
				races = HORDE_ONLY,
				lvl = 7,
				groups = {
					objective(1, {	-- 0/6 Azure Feather
						provider = { "i", 4752 },	-- Azure Feather
						cr = 2964,	-- Windfury Sorceress
					}),
					objective(2, {	-- 0/6 Bronze Feather
						provider = { "i", 4753 },	-- Bronze Feather
						cr = 2965,	-- Windfury Matriarch
					}),
					i(4968),	-- Bound Harness
					i(4967),	-- Tribal Warrior's Shield
				},
			}),
			q(767, {	-- Rite of Vision (1/3)
				sourceQuest = 763,	-- Rites of the Earthmother (2/3)
				qg = 2993,	-- Baine Bloodhoof
				coord = { 47.5, 60.2, MAP.MULGORE },
				races = HORDE_ONLY,
				lvl = 3,
			}),
			q(771, {	-- Rite of Vision (2/3)
				sourceQuest = 767,	-- Rite of Vision (1/3)
				qg = 3054,	-- Zarlman Two-Moons
				coord = { 47.8, 57.5, MAP.MULGORE },
				races = HORDE_ONLY,
				lvl = 3,
				groups = {
					objective(1, {	-- 0/2 Well Stone
						providers = {
							{ "i", 4808 },	-- Well Stone
							{ "o", 2910 },	-- Well Stone
						},
					}),
					objective(2, {	-- 0/2 Ambercorn
						providers = {
							{ "i", 4809 },	-- Ambercorn
							{ "o", 2912 },	-- Ambercorn
						},
					}),
				},
			}),
			q(772, {	-- Rite of Vision (3/3)
				sourceQuest = 771,	-- Rite of Vision (2/3)
				qg = 3054,	-- Zarlman Two-Moons
				qi = 4823,	-- Water of the Seers
				coord = { 47.8, 57.5, MAP.MULGORE },
				races = HORDE_ONLY,
				lvl = 3,
				groups = {
					i(4906),	-- Rainwalker Boots
					i(4958),	-- Sun-beaten Cloak
				},
			}),
			q(773, {	-- Rite of Wisdom
				sourceQuest = 772,	-- Rite of Vision (3/3)
				qgs = 2984,	-- Seer Wiserunner
				coord = { 32.8, 36.0, MAP.MULGORE },
				races = HORDE_ONLY,
				lvl = 3,
			}),
			q(776, {	-- Rites of the Earthmother (3/3)
				sourceQuest = 775,	-- Journey into Thunder Bluff
				qg = 3057,	-- Cairne Bloodhoof <High Chieftain>
				coord = { 59.8, 51.6, MAP.THUNDER_BLUFF },
				races = HORDE_ONLY,
				lvl = 3,
				groups = {
					objective(1, {	-- 0/1 Horn of Arra'chea
						provider = { "i", 4841 },	-- Horn of Arra'chea
						coords = {
							{ 48.4, 15.6, MAP.MULGORE },
							{ 53.0, 13.2, MAP.MULGORE },
							{ 55.0, 22.0, MAP.MULGORE },
							{ 56.4, 29.0, MAP.MULGORE },
							{ 52.2, 31.2, MAP.MULGORE },
							{ 51.0, 25.8, MAP.MULGORE },
							{ 49.6, 20.8, MAP.MULGORE },
						},
						cr = 3058,	-- Arra'chea
					}),
					i(4909),	-- Kodo Hunter's Leggings
				},
			}),
			q(745, {	-- Sharing the Land
				qg = 2993,	-- Baine Bloodhoof
				coord = { 47.5, 60.2, MAP.MULGORE },
				races = HORDE_ONLY,
				groups = {
					objective(1, {	-- 0/10 Palemane Tanner slain
						provider = { "n", 2949 },	-- Palemane Tanner
					}),
					objective(2, {	-- 0/8 Palemane Skinner slain
						provider = { "n", 2950 },	-- Palemane Skinner
					}),
					objective(3, {	-- 0/5 Palemane Poacher slain
						provider = { "n", 2951 },	-- Palemane Poacher
					}),
					i(4960),	-- Flash Pellet
				},
			}),
			q(99108, {	-- Sparring Match
				qg = 3063,	-- Krang Stonehoof
				coord = { 49.4, 60.4, MAP.MULGORE },
				timeline = { TIMELINE.ADDED_1_60_1 },
				races = HORDE_ONLY,
				lvl = 4,
				groups = {
					objective(1, {	-- Novice Warrior slain
						provider = { "n", 10721 },	-- Novice Warrior
						coord = { 49.0, 62.0, MAP.MULGORE },
					}),
				},
			}),
			q(76156, {	-- Stalk With The Earthmother 1/3
				qg = 205729,	-- Boarton Shadetotem <Rogue Trainer?>
				coord = { 39.6, 65.6, MAP.THUNDER_BLUFF },
				races = { ORC, TAUREN, TROLL },
				classes = { WARRIOR, SHAMAN, DRUID },
				lvl = 4,
				timeline = { TIMELINE.ADDED_1_60_1 },
				qi = 206159,	-- Venture Co Disguise (QI!)
				groups = {
					objective(1, {	-- 0/5 Seaforium Mining Charge
						provider = { "i", 206157 },	-- Seaforium Mining Charge (QI!)
					}),
				},
			}),
			q(76160, {	-- Stalk With The Earthmother 2/3
				sourceQuest = 76156,	-- Stalk With The Earthmother
				qg = 205729,	-- Boarton Shadetotem
				qi = 206176,	-- Mortar and Pestle
				coord = { 39.6, 65.6, MAP.THUNDER_BLUFF },
				timeline = { TIMELINE.ADDED_1_60_1 },
				races = { ORC, TAUREN, TROLL },
				classes = { WARRIOR, SHAMAN, DRUID },
				lvl = 4,
				groups = {
					objective(1, {	-- 0/1 Pine Salve
						providers = {
							{ "i", 206175 },	-- Pine Salve
							{ "o", 403105 },	-- Windfury Cone
						},
						costs = {
							{ { "i", 206176, 1 } },	-- Mortar and Pestle
							{ { "i", 206170, 8 } },	-- Windfury Cone
						},
					}),
					i(206177),	-- Pine Nut Butter
				},
			}),
			q(76240, {	-- Stalk With The Earthmother 3/3
				sourceQuest = 76160,	-- Stalk With The Earthmother
				qg = 205729,	-- Boarton Shadetotem <Rogue Trainer?>
				qi = 206344,	-- Knife Set (QI!)
				coord = { 39.6, 65.6, MAP.THUNDER_BLUFF },
				races = { ORC, TAUREN, TROLL },
				classes = { WARRIOR, SHAMAN, DRUID },
				lvl = 4,
				timeline = { TIMELINE.ADDED_1_60_1 },
				groups = {
					objective(1, {	-- 0/1 Fish Chunks
						provider = { "i", 206345 },	-- Fish Chunks (QI!)
						costs = {
							{ { "i", 206344, 1 } },	-- Knife Set (QI!)
							{ { "i", 6291, 1 } },	-- Raw Brilliant Smallfish
						},
					}),
					i(277988),	-- Hoof-Holstered Blade
					i(278002),	-- Valley Cosh
				},
			}),
			q(96260, {	-- Stronger than Steel
				qg = 264072,	-- Yorn Grimtotem
				coord = { 32.4, 20.0, MAP.MULGORE },
				timeline = { TIMELINE.ADDED_1_60_1 },
				races = exclude(TAUREN, HORDE_ONLY),
				lvl = 23,	-- Required level; quest level 30.
				groups = {
					objective(1, {	-- 0/3 Crystalline Silk
						provider = { "i", 273181 },	-- Crystalline Silk
						cr = 264081,	-- Gloomrise Spinner
					}),
					i(276892),	-- Spidersilk Sack
					i(276891),	-- Spidersilk Pouch
					i(273654),	-- Crystal Thread Cloak
				},
			}),
			q(765, {	-- Supervisor Fizsprocket
				sourceQuest = 751,	-- The Ravaged Caravan (2/2)
				qg = 2988,	-- Morin Cloudstalker
				coord = { 54.4, 60.4, MAP.MULGORE },
				races = HORDE_ONLY,
				lvl = 5,
				groups = {
					objective(1, {	-- 0/1 Fizsprocket's Clipboard
						provider = { "i", 4819 },	-- Fizsprocket's Clipboard
						coord = { 64.8, 43.4, MAP.MULGORE },
						cr = 3051,	-- Supervisor Fizsprocket
					}),
					i(4974),	-- Compact Fighting Knife
					i(4964),	-- Goblin Smasher
				},
			}),
			q(99202, {	-- Swift as the Wind
				qg = 3690,	-- Kar Stormsinger <Kodo Riding Instructor>
				coord = { 46.8, 61.8, MAP.MULGORE },
				timeline = { TIMELINE.ADDED_1_60_1 },
				races = { TAUREN },
				lvl = 60,
				groups = {
					objective(1),	-- 0/1 Learn: Journeyman Riding
				},
			}),
			q(761, {	-- Swoop Hunting
				qg = 2947,	-- Harken Windtotem
				coord = { 48.7, 59.3, MAP.MULGORE },
				races = HORDE_ONLY,
				lvl = 4,
				groups = {
					objective(1, {	-- 0/8 Trophy Swoop Quill
						provider = { "i", 4769 },	-- Swoop Hunting
						crs = {
							2970,	-- Swoop
							2969,	-- Wiry Swoop
						},
					}),
				},
			}),
			q(96241, {	-- Talkin' bout Toxins, Mon
				qg = 264074,	-- Mazu'kon
				qi = 273015,	-- Toxin Extractor
				coord = { 32.4, 20.6, MAP.MULGORE },
				timeline = { TIMELINE.ADDED_1_60_1 },
				races = exclude(TAUREN, HORDE_ONLY),
				lvl = 23,	-- Required level; quest level 30.
				groups = {
					objective(1, {	-- 0/5 Gloomrise Toxin Sample
						description = "Use the provided Toxin Extractor on Gnawed Corpses at Gloomrise.",
						provider = { "i", 273001 },	-- Gloomrise Toxin Sample
						cr = 264096,	-- Gnawed Corpse
					}),
				},
			}),
			q(6061, {	-- Taming the Beast (1/3)
				sourceQuests = {
					6065,	-- The Hunter's Path [Thunder Bluff]
					6066,	-- The Hunter's Path [Mulgore]
					6067,	-- The Hunter's Path [Durotar]
				},
				qg = 3065,	-- Yaw Sharpmane <Hunter Trainer>
				coord = { 47.8, 55.6, MAP.MULGORE },
				races = { TAUREN },
				classes = { HUNTER },
				lvl = 10,
				groups = {
					objective(1, {	-- Tame an Adult Plainstrider
						providers = {
							{ "n", 2956 },	-- Adult Plainstrider
							{ "i", 15914 },	-- Taming Rod
						},
					}),
				},
			}),
			q(6087, {	-- Taming the Beast (2/3)
				sourceQuest = 6061,	-- Taming the Beast (1/3)
				qg = 3065,	-- Yaw Sharpmane <Hunter Trainer>
				coord = { 47.8, 55.6, MAP.MULGORE },
				races = { TAUREN },
				classes = { HUNTER },
				lvl = 10,
				groups = {
					objective(1, {	-- Tame a Prairie Stalker
						providers = {
							{ "n", 2959 },	-- Prairie Stalker
							{ "i", 15915 },	-- Taming Rod
						},
					}),
				},
			}),
			q(6088, {	-- Taming the Beast (3/3)
				sourceQuest = 6087,	-- Taming the Beast (2/3)
				qg = 3065,	-- Yaw Sharpmane <Hunter Trainer>
				coord = { 47.8, 55.6, MAP.MULGORE },
				races = { TAUREN },
				classes = { HUNTER },
				lvl = 10,
				groups = {
					objective(1, {	-- Tame a Swoop
						providers = {
							{ "n", 2970 },	-- Swoop
							{ "i", 15916 },	-- Taming Rod
						},
					}),
					recipe(883),	-- Call Pet
					recipe(2641),	-- Dismiss Pet
					recipe(1515),	-- Tame Beast
				},
			}),
			q(96261, {	-- The Broodmother
				qg = 259118,	-- Muln Earthfury
				coord = { 33.4, 22.4, MAP.MULGORE },
				timeline = { TIMELINE.ADDED_1_60_1 },
				races = HORDE_ONLY,
				lvl = 23,	-- Required level; level 31 elite quest.
				groups = {
					objective(1, {	-- 0/1 Broodmother Valraxx slain
						provider = { "n", 264082 },	-- Broodmother Valraxx
						coords = {
							{ 33.6, 6.8, MAP.MULGORE },
							{ 33.4, 7.2, MAP.MULGORE },
						},
					}),
					i(276895),	-- Transformative Cocoon
				},
			}),
			q(770, {	-- The Demon Scarred Cloak
				qs = 4854,	-- Demon Scarred Cloak (QS!)
				races = HORDE_ONLY,
				lvl = 6,
				groups = {
					i(4971),	-- Skorn's Hammer
					i(3079),	-- Skorn's Rifle
				},
			}),
			q(96605, {	-- The Great Outdoors [Mulgore]
				sourceQuest = 96659,	-- The Adventurer [Mulgore]
				altQuests = {
					95998,	-- The Great Outdoors [Elwynn Forest]
					96101,	-- The Great Outdoors [Zephras Isle]
					96604,	-- The Great Outdoors [Durotar]
					96606,	-- The Great Outdoors [Teldrassil]
					96607,	-- The Great Outdoors [Tirisfal Glades]
					96608,	-- The Great Outdoors [Dun Morogh]
				},
				qg = 265810,	-- Kaga Wildhoof <Adventurer>
				coord = { 46.2, 67.2, MAP.MULGORE },
				races = HORDE_ONLY,
				lvl = 4,
				timeline = { TIMELINE.ADDED_1_60_1 },
			}),
			q(99082, {	-- The High Chieftain
				sourceQuests = {
					99080,	-- Drive Them Out
				},
				qg = 2993,	-- Baine Bloodhoof
				coord = { 47.4, 60.2, MAP.MULGORE },
				timeline = { TIMELINE.ADDED_1_60_1 },
				races = HORDE_ONLY,
				lvl = 4,
				groups = {
					i(286740),	-- Proud Brave's Guard
					i(286741),	-- Centaur Skull Basher
				},
			}),
			q(6067, {	-- The Hunter's Path [Durotar]
				qg = 3171,	-- Thotar <Hunter Trainer>
				coord = { 51.9, 43.5, MAP.DUROTAR },
				races = { TAUREN },
				classes = { HUNTER },
				isBreadcrumb = true,
				lvl = 10,
			}),
			q(6066, {	-- The Hunter's Path [Mulgore]
				qg = 3061,	-- Lanka Farshot <Hunter Trainer>
				coord = { 44.3, 75.7, MAP.MULGORE },
				races = { TAUREN },
				classes = { HUNTER },
				isBreadcrumb = true,
				lvl = 10,
			}),
			q(6065, {	-- The Hunter's Path [Thunder Bluff]
				qg = 3038,	-- Kary Thunderhorn <Hunter Trainer>
				coord = { 58.4, 88.0, MAP.THUNDER_BLUFF },
				races = { TAUREN },
				classes = { HUNTER },
				isBreadcrumb = true,
				lvl = 10,
			}),
			q(861, {	-- The Hunter's Way
				altQuests = {
					860,	-- Sergra Darkthorn
					844,	-- Plainstrider Menace
				},
				qg = 3052,	-- Skorn Whitecloud
				coord = { 46.76, 60.22, MAP.MULGORE },
				races = HORDE_ONLY,
				lvl = 10,
				groups = {
					objective(1, {	-- 0/4 Flatland Prowler Claw
						provider = { "i", 5203 },	-- Flatland Prowler Claw
						cr = 3566,	-- Flatland Prowler
					}),
				},
			}),
			q(98430, {	-- The Longwalkers
				qg = 272203,	-- Perith Stormhoof
				coord = { 33.0, 65.8, MAP.MULGORE },
				timeline = { TIMELINE.ADDED_1_60_1 },
				races = { UNDEAD, TAUREN },
				groups = {
					objective(1, {	-- Escort Perith Stormhoof out of Palemane Rock
						provider = { "n", 272203 },	-- Perith Stormhoof
					}),
				},
			}),
			q(749, {	-- The Ravaged Caravan (1/2)
				qg = 2988,	-- Morin Cloudstalker
				coord = { 54.4, 60.4, MAP.MULGORE },
				races = HORDE_ONLY,
				lvl = 5,
			}),
			q(751, {	-- The Ravaged Caravan (2/2)
				sourceQuest = 749,	-- The Ravaged Caravan (1/2)
				provider = { "o", 2908 },	-- Sealed Supply Crate
				qi = 4834,	-- Venture Co. Documents (QI!)
				coords = { 53.8, 48.3, MAP.MULGORE },
				races = HORDE_ONLY,
				lvl = 5,
			}),
			q(764, {	-- The Venture Co.
				sourceQuest = 751,	-- The Ravaged Caravan (2/2)
				qg = 2988,	-- Morin Cloudstalker
				coord = { 54.4, 60.4, MAP.MULGORE },
				races = HORDE_ONLY,
				lvl = 5,
				groups = {
					objective(1, {	-- 0/14 Venture Co. Worker slain
						provider = { "n", 2978 },	-- Venture Co. Worker
					}),
					objective(2, {	-- 0/6 Venture Co. Supervisor slain
						provider = { "n", 2979 },	-- Venture Co. Supervisor
					}),
				},
			}),
			q(758, {	-- Thunderhorn Cleansing
				sourceQuest = 756,	-- Thunderhorn Totem
				qg = 2948,	-- Mull Thunderhorn
				coord = { 48.5, 60.4, MAP.MULGORE },
				races = { TAUREN },
				lvl = 4,
				groups = {
					objective(1, {	-- Cleanse the Thunderhorn Water Well
						provider = { "i", 5415 },	-- Thunderhorn Cleansing Totem
						coord = { 44.0, 45.0, MAP.MULGORE },
					}),
					i(4963),	-- Thunderhorn Cloak
				},
			}),
			q(756, {	-- Thunderhorn Totem
				sourceQuest = 754,	-- Winterhoof Cleansing
				qg = 2948,	-- Mull Thunderhorn
				coord = { 48.5, 60.4, MAP.MULGORE },
				races = { TAUREN },
				lvl = 4,
				groups = {
					objective(1, {	-- 0/6 Stalker Claws
						provider = { "i", 4801 },	-- Stalker Claws
						cr = 2959,	-- Prairie Stalker
					}),
					objective(2, {	-- 0/6 Cougar Claws
						provider = { "i", 4802 },	-- Cougar Claws
						cr = 3035,	-- Flatland Cougar
					}),
				},
			}),
			q(98435, {	-- Thunderhorn's Report
				sourceQuest = 760,	-- Wildmane Cleansing
				qg = 2948,	-- Mull Thunderhorn
				qi = 281139,	-- Thunderhorn's Report
				coord = { 48.5, 60.4, MAP.MULGORE },
				timeline = { TIMELINE.ADDED_1_60_1 },
				races = { TAUREN },
				lvl = 4,
				groups = {
					i(3443),	-- Ceremonial Tomahawk
					i(4961),	-- Dreamwatcher Staff
				},
			}),
			q(5661, {	-- Touch of Weakness [Mulgore]
				altQuests = {
					5658,	-- Touch of Weakness [Undercity]
					5660,	-- Touch of Weakness [Durotar]
					5662,	-- Touch of Weakness [Orgrimmar]
					5663,	-- Touch of Weakness [Thunder Bluff]
				},
				qg = 11407,	-- Var'jun
				coord = { 47.0, 58.8, MAP.MULGORE },
				classes = { PRIEST },
				races = { UNDEAD },
				lvl = 10,
				groups = {
					{
						recipeID = 2652,	-- Touch of Weakness (Rank 1)
						rank = 1,
					},
				},
			}),
			q(6089, {	-- Training the Beast
				sourceQuest = 6088,	-- Taming the Beast (3/3)
				qg = 3065,	-- Yaw Sharpmane <Hunter Trainer>
				coord = { 47.8, 55.6, MAP.MULGORE },
				races = { TAUREN },
				classes = { HUNTER },
				lvl = 10,
				groups = {
					recipe(6991),	-- Feed Pet
					recipe(982),	-- Revive Pet
				},
			}),
			q(98477, {	-- Unstable Magic
				qg = 272633,	-- Nuara Tremorhoof
				qi = 281371,	-- Elemental Attractor (PQI!)
				coord = { 33.4, 22.6, MAP.MULGORE },
				timeline = { TIMELINE.ADDED_1_60_1 },
				races = HORDE_ONLY,
				lvl = 48,
				groups = {
					objective(1, {	-- 0/10 Mote of Unstable Magic
						provider = { "i", 274964 },	-- Mote of Unstable Magic
					}),
				},
			}),
			q(760, {	-- Wildmane Cleansing
				sourceQuest = 759,	-- Wildmane Totem
				qg = 2948,	-- Mull Thunderhorn
				coord = { 48.5, 60.4, MAP.MULGORE },
				races = { TAUREN },
				lvl = 4,
				groups = {
					objective(1, {	-- Cleanse the Wildmane Well
						provider = { "i", 5416 },	-- Wildmane Cleansing Totem
						coord = { 43.0, 14.0, MAP.MULGORE },
					}),
					i(3443),	-- Ceremonial Tomahawk
					i(4961),	-- Dreamwatcher Staff
				},
			}),
			q(759, {	-- Wildmane Totem
				sourceQuest = 758,	-- Thunderhorn Cleansing
				qg = 2948,	-- Mull Thunderhorn
				coord = { 48.5, 60.4, MAP.MULGORE },
				races = { TAUREN },
				lvl = 4,
				groups = {
					objective(1, {	-- 0/8 Prairie Alpha Tooth
						provider = { "i", 4803 },	-- Prairie Alpha Tooth
						cr = 2960,	-- Prairie Wolf Alpha
					}),
				},
			}),
			q(754, {	-- Winterhoof Cleansing
				sourceQuest = 748,	-- Poison Water
				qg = 2948,	-- Mull Thunderhorn
				coord = { 48.5, 60.4, MAP.MULGORE },
				races = { TAUREN },
				lvl = 4,
				groups = {
					objective(1, {	-- Cleanse the Winterhoof Water Well
						provider = { "i", 5411 },	-- Winterhoof Cleansing Totem
						coord = { 53.0, 66.0, MAP.MULGORE },
					}),
				},
			}),
		}),
		n(RARES, {
			n(5787, {	-- Enforcer Emilgund
				coords = {
					{ 40.0, 13.4, MAP.MULGORE },
					{ 40.4, 15.8, MAP.MULGORE },
					{ 40.4, 25.4, MAP.MULGORE },
				},
				groups = {
					i(284361, {	-- Venture Company Legguards
						timeline = { TIMELINE.ADDED_1_60_1 },
					}),
				},
			}),
			n(3056, {	-- Ghost Howl
				description = "For this rare mob to appear at one of its random spawn points, you must first speak to Skorn Whitecloud in Bloodhoof Village. It will then appear within 5 to 30 minutes.",
				coords = {
					{ 39.5, 23.9, MAP.MULGORE },
					{ 48.0, 24.1, MAP.MULGORE },
					{ 13.0, 29.6, MAP.THUNDER_BLUFF },
					{ 15.2, 14.2, MAP.THUNDER_BLUFF },
					{ 23.2, 5.0, MAP.THUNDER_BLUFF },
					{ 25.4, 3.2, MAP.THUNDER_BLUFF },
					{ 33.6, 2.8, MAP.THUNDER_BLUFF },
					{ 35.4, 3.4, MAP.THUNDER_BLUFF },
				},
				groups = {
					i(4854, {	-- Demon Scarred Cloak (QS!)
						races = HORDE_ONLY,
					}),
				},
			}),
			n(3068, {	-- Mazzranache
				coords = {
					{ 35.4, 47.2, MAP.MULGORE },
					{ 37.1, 48.4, MAP.MULGORE },
					{ 38.2, 43.8, MAP.MULGORE },
					{ 40.0, 44.0, MAP.MULGORE },
					{ 40.6, 49.7, MAP.MULGORE },
					{ 54.2, 43.4, MAP.MULGORE },
				},
				groups = {
					i(4861),	-- Sleek Feathered Tunic
				},
			}),
			n(5785, {	-- Sister Hatelash
				coords = {
					{ 29.2, 20.6, MAP.MULGORE },
					{ 29.2, 22.8, MAP.MULGORE },
					{ 30.4, 21.8, MAP.MULGORE },
					{ 30.8, 19.2, MAP.MULGORE },
					{ 32.2, 30.2, MAP.MULGORE },
					{ 32.4, 31.8, MAP.MULGORE },
					{ 35.4, 12.4, MAP.MULGORE },
					{ 36.0, 10.0, MAP.MULGORE },
					{ 36.6, 11.4, MAP.MULGORE },
					{ 37.2, 22.4, MAP.MULGORE },
					{ 37.6, 20.6, MAP.MULGORE },
					{ 38.2, 23.8, MAP.MULGORE },
					{ 39.0, 22.4, MAP.MULGORE },
					{ 51.8, 23.6, MAP.MULGORE },
					{ 52.4, 21.4, MAP.MULGORE },
					{ 53.8, 13.8, MAP.MULGORE },
					{ 54.4, 9.4, MAP.MULGORE },
					{ 54.4, 11.4, MAP.MULGORE },
					{ 55.4, 16.2, MAP.MULGORE },
					{ 55.8, 12.8, MAP.MULGORE },
				},
				groups = {
					i(4772),	-- Warm Cloak
				},
			}),
			n(5786, {	-- Snagglespear
				coords = {
					{ 47.7, 72.9, MAP.MULGORE },
					{ 48.1, 70.9, MAP.MULGORE },
					{ 51.7, 74.2, MAP.MULGORE },
					{ 53.2, 72.2, MAP.MULGORE },
				},
			}),
			n(276109, {	-- Snarlsnout
				coords = {
					{ 32.2, 63.4, MAP.MULGORE },
					{ 32.6, 65.6, MAP.MULGORE },
				},
				timeline = { TIMELINE.ADDED_1_60_1 },
				groups = {
					i(286753),	-- Snarlsnout Shooter
				},
			}),
			n(276105, {	-- Stormherald Ukta
				coords = {
					{ 59.0, 59.0, MAP.MULGORE },
					{ 59.4, 55.8, MAP.MULGORE },
					{ 60.2, 58.4, MAP.MULGORE },
				},
				timeline = { TIMELINE.ADDED_1_60_1 },
				groups = {
					i(286754),	-- Ukta's Conduit
				},
			}),
			n(5807, {	-- The Rake
				coords = {
					{ 48.4, 17.0, MAP.MULGORE },
					{ 49.4, 15.0, MAP.MULGORE },
					{ 49.9, 26.3, MAP.MULGORE },
					{ 51.8, 30.8, MAP.MULGORE },
				},
				groups = {
					i(17922),	-- Lionfur Armor
				},
			}),
			n(276108, {	-- Thornstarter Igleg
				coords = {
					{ 58.8, 30.0, MAP.MULGORE },
					{ 59.6, 30.8, MAP.MULGORE },
				},
				timeline = { TIMELINE.ADDED_1_60_1 },
				groups = {
					i(286752),	-- Igleggings
				},
			}),
		}),
		n(RIDING_TRAINER, {
			n(3690, {	-- Kar Stormsinger <Kodo Riding Instructor>
				coord = { 47.6, 58.4, MAP.MULGORE },
				races = HORDE_ONLY,
				-- Available to Tauren without faction requirements.
				minReputation = { FACTION_THUNDER_BLUFF, EXALTED },
				OnInit = [[function(t)
					if _.RaceIndex == ]] .. TAUREN .. [[ then
						t.minReputation = nil;
					end
					return t;
				end]],
				groups = {
					recipe(18995, {	-- Kodo Riding
						cost = 200000,
						lvl = 40,
					}),
				},
			}),
		}),
		n(VENDORS, {
			n(3075, {	-- Bronk Steelrage <Armorer and Shieldcrafter>
				coords = {
					{ 43.8, 77.8, MAP.MULGORE },
					{ 44.2, 77.4, MAP.MULGORE },
				},
				races = HORDE_ONLY,
				sym = {
					SymSelector.select("VENDOR_RUSTED_CHAIN"),	-- Rusted Chain
					{ "pop" },
					{ "select", "itemID",
						17183,	-- Dented Buckler
						1200,	-- Large Wooden Shield
					},
				},
			}),
			n(3080, {	-- Harant Ironbrace <Armorer and Shieldcrafter>
				coords = {
					{ 45.4, 62.0, MAP.MULGORE },
					{ 45.8, 58.6, MAP.MULGORE },
				},
				races = HORDE_ONLY,
				sym = {
					SymSelector.select("VENDOR_LIGHT_CHAIN"),	-- Light Chain
					{ "pop" },
					{ "select", "itemID",
						17185,	-- Round Buckler
						2376,	-- Worn Heater Shield
					},
				},
			}),
			n(3685, {	-- Harb Clawhoof <Kodo Mounts>
				coord = { 47.6, 58.4, MAP.MULGORE },
				-- Available to Tauren without faction requirements.
				minReputation = { FACTION_THUNDER_BLUFF, EXALTED },
				OnInit = [[function(t)
					if _.RaceIndex == ]] .. TAUREN .. [[ then
						t.minReputation = nil;
					end
					return t;
				end]],
				races = HORDE_ONLY,
				groups = {
					i(15277),	-- Gray Kodo (MOUNT!)
					i(15290),	-- Brown Kodo (MOUNT!)
					i(275993, {	-- White Kodo (MOUNT!)
						timeline = { TIMELINE.ADDED_1_60_1 },
					}),
					i(18793),	-- Great White Kodo (MOUNT!)
					i(18794),	-- Great Brown Kodo (MOUNT!)
					i(18795),	-- Great Gray Kodo (MOUNT!)
				},
			}),
			n(5940, {	-- Harn Longcast <Fishing Supplies>
				coords = { 47.6, 55.0, MAP.MULGORE },
				races = HORDE_ONLY,
				groups = {
					i(6325),	-- Recipe: Brilliant Smallfish (RECIPE!)
					i(6328),	-- Recipe: Longjaw Mud Snapper (RECIPE!)
				},
			}),
			n(264078, {	-- Sutara Plainstalker <Quartermaster>
				coord = { 34.6, 22.8, MAP.MULGORE },
				timeline = { TIMELINE.ADDED_1_60_1 },
				groups = bubbleDownClassicRep(FACTION_FOREVER_EARTHEN_RING, {
					{	-- Neutral
					}, {	-- Friendly
						i(276978),	-- Pattern: Cloudy Gustwoven Hood (RECIPE!)
						i(276979),	-- Pattern: Cloudy Gustwoven Spaulders (RECIPE!)
						i(276982),	-- Pattern: Cloudy Stormsewn Cowl (RECIPE!)
						i(276983),	-- Pattern: Cloudy Stormsewn Epaulets (RECIPE!)
						i(276980),	-- Pattern: Cloudy Windraveled Cover (RECIPE!)
						i(276981),	-- Pattern: Cloudy Windraveled Drapes (RECIPE!)
						i(276976),	-- Plans: Cloudy Skyforged Helm (RECIPE!)
						i(276977),	-- Plans: Cloudy Skyforged Pauldrons (RECIPE!)
					}, {	-- Honored
					}, {	-- Revered
					}, {	-- Exalted
					},
				}),
			}),
			n(3079, {	-- Varg Windwhisper <Leather Armor Merchant>
				coords = {
					{ 45.2, 62.0, MAP.MULGORE },
					{ 45.8, 58.6, MAP.MULGORE },
				},
				races = HORDE_ONLY,
				sym = {
					SymSelector.select("VENDOR_BATTERED_LEATHER"),	-- Battered Leather
					{ "pop" },
				},
			}),
			n(3074, {	-- Varia Hardhide <Leather Armor Merchant>
				coords = {
					{ 43.8, 77.6, MAP.MULGORE },
					{ 44.2, 77.2, MAP.MULGORE },
				},
				races = HORDE_ONLY,
				sym = {
					SymSelector.select("VENDOR_DIRTY_LEATHER"),	-- Dirty Leather
					{ "pop" },
				},
			}),
			n(3081, {	-- Wunna Darkmane <Trade Goods>
				coord = { 46.2, 58.2, MAP.MULGORE },
				races = HORDE_ONLY,
				sym = {{ "select", "itemID",
					277113,	-- Apprentice's Herb Pouch
					277115,	-- Apprentice's Mining Pack
					277114,	-- Apprentice's Skinning Satchel
					5956,	-- Blacksmith Hammer
					2324,	-- Bleach
					6260,	-- Blue Dye
					2320,	-- Coarse Thread
					6217,	-- Copper Rod
					3371,	-- Empty Vial
					6256,	-- Fishing Pole
					2678,	-- Mild Spices
					2901,	-- Mining Pick
					2604,	-- Red Dye
					4289,	-- Salt
					6529,	-- Shiny Bauble
					4536,	-- Shiny Red Apple
					7005,	-- Skinning Knife
					2880,	-- Weak Flux
				}},
				groups = {
					i(5484),	-- Recipe: Roasted Kodo Meat (RECIPE!)
				},
			}),
		}),
		n(ZONE_DROPS, {
			i(273658, {	-- Bloody Parchment
				cr = 264082,	-- Broodmother Valraxx
				coords = {
					{ 33.6, 6.8, MAP.MULGORE },
					{ 33.4, 7.2, MAP.MULGORE },
				},
				timeline = { TIMELINE.ADDED_1_60_1 },
				lvl = 23,
			}),
			i(281031, {	-- Mulgore Expansion Plans
				cr = 3051,	-- Supervisor Fizsprocket
				timeline = { TIMELINE.ADDED_1_60_1 },
				lvl = 5,
			}),
		}),
	},
});
root(ROOTS.HiddenQuestTriggers, {
	q(99582, {	-- Obtained by acquiring the "Camp Benefits" buff for the first time while completing the tutorial quest 96605, "The Great Outdoors."
		timeline = { TIMELINE.ADDED_1_60_1 },
	}),
});
