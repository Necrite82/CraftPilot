---------------------------------------------------
--          Z O N E S        M O D U L E         --
---------------------------------------------------

maproot(MAP.KALIMDOR, MAP.SHENDRALAS, {
	--lore = "",
	icon = 132368,
	timeline = { TIMELINE.ADDED_1_60_1 },
	groups = {
		n(ACHIEVEMENTS, {
			ach(63684),	-- Explore Shen'dralas
		}),
		explorationHeader({
			exploration(16677),	-- Bristleback Retreat
			exploration(16678),	-- Evenshade's Overlook
			exploration(16742),	-- Forlorn Gardens
			exploration(16675),	-- Magram Front
			exploration(16676),	-- Outcast Hideaway
			exploration(2657),	-- Valley of Bones
		}),
		n(QUESTS, {
			q(93016, {	-- A Brief History Lesson
				qg = 253471,	-- Mordent Evenshade
				coord = { 35.0, 46.5, MAP.SHENDRALAS },
				lvl = 35,
			}),
			q(99257, {	-- A Heart of Crystal
				qg = 255486,	-- Historian Biraxas
				coord = { 45.8, 78.2, MAP.SHENDRALAS },
				lvl = 35,
				groups = {
					objective(1, {	-- 0/1 Depleted Crystal Heart
						provider = { "i", 286647 },	-- Depleted Crystal Heart
						coord = { 43.8, 34.4, MAP.SHENDRALAS },
						cr = 252711,	-- Decrepit Pylon Protector
					}),
				},
			}),
			q(93062, {	-- Bone Burying
				qg = 253177,	-- Nerlokh
				coords = {
					{ 58.4, 88.6, MAP.DESOLACE },
					{ 20.8, 22.6, MAP.SHENDRALAS },
				},
				minReputation = { FACTION_GELKIS_CLAN_CENTAUR, HONORED },
				lvl = 35,
				groups = {
					objective(1, {	-- 0/8 Haggard Bones laid to rest
						provider = { "i", 258661 },	-- Uthek's Draenethyst Staff
						cr = 253446,	-- Haggard Bones
						coord = { 38.6, 29.8, MAP.SHENDRALAS },
					}),
				},
			}),
			q(92894, {	-- Bone Raising
				sourceQuest = 92873,	-- Proof of Concept
				qg = 253136,	-- Orgrul
				coord = { 35.6, 12.0, MAP.SHENDRALAS },
				minReputation = { FACTION_MAGRAM_CLAN_CENTAUR, HONORED },
				races = ALLIANCE_ONLY,
				lvl = 35,
				groups = {
					objective(1, {	-- 0/10 Summon or Slay Haggard Bones
						provider = { "i", 255403 },	-- Enhanced Necromancy Staff
						cr = 253446,	-- Haggard Bones
						coord = { 38.6, 29.8, MAP.SHENDRALAS },
					}),
				},
			}),
			q(93066, {	-- Bristleback Retreat
				sourceQuests = {
					92893,	-- No Mercy for the Weak
					92894,	-- Bone Raising
				},
				qg = 253136,	-- Orgrul
				coord = { 35.6, 12.0, MAP.SHENDRALAS },
				minReputation = { FACTION_MAGRAM_CLAN_CENTAUR, HONORED },
				lvl = 35,
				groups = {
					objective(1, {	-- 0/4 Bristleback Nomad slain
						provider = { "n", 253524 },	-- Bristleback Nomad
						coord = { 58.4, 20.2, MAP.SHENDRALAS },
					}),
					objective(2, {	-- 0/6 Bristleback Thornweaver slain
						provider = { "n", 253525 },	-- Bristleback Thornweaver
						coord = { 69.2, 28.4, MAP.SHENDRALAS },
					}),
					objective(3, {	-- 0/6 Bristleback Skullcrusher slain
						provider = { "n", 253526 },	-- Bristleback Skullcrusher
						coord = { 57.0, 15.4, MAP.SHENDRALAS },
					}),
				},
			}),
			q(93122, {	-- Checking Things Out
				sourceQuests = {
					93058,	-- Saving Our Own
					93062,	-- Bone Burying
				},
				qg = 253177,	-- Nerlokh
				coords = {
					{ 58.4, 88.6, MAP.DESOLACE },
					{ 20.8, 22.6, MAP.SHENDRALAS },
				},
				minReputation = { FACTION_GELKIS_CLAN_CENTAUR, HONORED },
				lvl = 35,
				-- TODO: Wowhead doesn't list this quest's objectives yet (investigate centaur points of interest).
			}),
			q(93574, {	-- Corpsefeeder's Carapace
				qs = 259893,	-- Corpsefeeder's Carapace (QS!)
				lvl = 35,
				groups = {
					i(271810),	-- Corpsefeeder's Shedding
					i(271811),	-- Clacking Carapace Spaulders
					i(271812),	-- Discarded Circlet
				},
			}),
			q(92847, {	-- Corrupting Tears
				sourceQuests = {
					92844,	-- Mountain of Bones
					92846,	-- Outcast Necromancers
				},
				qg = 253136,	-- Orgrul
				coord = { 35.6, 12.0, MAP.SHENDRALAS },
				minReputation = { FACTION_MAGRAM_CLAN_CENTAUR, HONORED },
				races = ALLIANCE_ONLY,
				lvl = 35,
				groups = {
					objective(1, {	-- 0/3 Petrified Bark
						providers = {
							{ "i", 254841 },	-- Petrified Bark
							{ "o", 582187 },	-- Petrified Tree
						},
						coords = {
							{ 45.2, 37.8, MAP.SHENDRALAS },
							{ 46.7, 28.1, MAP.SHENDRALAS },
							{ 48.3, 39.5, MAP.SHENDRALAS },
							{ 50.5, 27.4, MAP.SHENDRALAS },
						},
					}),
					objective(2, {	-- 0/3 Imbued Tears
						provider = { "i", 254840 },	-- Imbued Tears
					}),
				},
			}),
			q(93041, {	-- Facing the Truth
				sourceQuests = {
					93035,	-- Ravaging Ravagers
					93037,	-- Outing Outcasts
				},
				qg = 253177,	-- Nerlokh
				coords = {
					{ 58.4, 88.6, MAP.DESOLACE },
					{ 20.8, 22.6, MAP.SHENDRALAS },
				},
				minReputation = { FACTION_GELKIS_CLAN_CENTAUR, HONORED },
				lvl = 35,
				groups = {
					objective(1, {	-- 0/1 Accursed Skull
						provider = { "i", 255945 },	-- Accursed Skull
					}),
					objective(2, {	-- 0/1 Gelkis Necromantic Garb
						provider = { "i", 255941 },	-- Gelkis Necromantic Garb
					}),
				},
			}),
			q(93341, {	-- Forlorn Gardens
				qg = 254578,	-- Mithera
				coord = { 53.0, 75.8, MAP.SHENDRALAS },
				lvl = 35,
			}),
			q(93609, {	-- Forlorn Necklace
				qs = 260247,	-- Forlorn Necklace (QS!)
				lvl = 35,
				groups = {
					i(272185),	-- Amulet of Forgiveness
					i(272184),	-- Amulet of Vengeance
				},
			}),
			q(96010, {	-- Fragments of the Pylons
				qg = 253471,	-- Mordent Evenshade
				coord = { 35.0, 46.5, MAP.SHENDRALAS },
				lvl = 35,
				groups = {
					objective(1, {	-- 0/1 Pylon Fragment
						provider = { "i", 255656 },	-- Pylon Fragment
					}),
					objective(2, {	-- 0/1 Pylon Shard
						provider = { "i", 255657 },	-- Pylon Shard
					}),
				},
			}),
			q(93125, {	-- Going Home
				sourceQuests = {
					93058,	-- Saving Our Own
					93062,	-- Bone Burying
				},
				qg = 254040,	-- Rokren
				coord = { 34.1, 78.0, MAP.SHENDRALAS },
				timeline = { TIMELINE.ADDED_1_60_1 },
				minReputation = { FACTION_GELKIS_CLAN_CENTAUR, HONORED },
				lvl = 35,
				-- TODO: Escort Rokren out of the Outcast Hideaway; Wowhead has no IDs for the escort yet.
			}),
			q(93072, {	-- Long-Term Solutions
				sourceQuest = 93066,	-- Bristleback Retreat
				qg = 253851,	-- Hagiak
				coord = { 59.2, 54.0, MAP.SHENDRALAS },
				timeline = { TIMELINE.ADDED_1_60_1 },
				minReputation = { FACTION_MAGRAM_CLAN_CENTAUR, HONORED },
				lvl = 35,
				groups = {
					objective(1, {	-- 0/2 Outcast Scout slain
						provider = { "n", 254283 },	-- Outcast Scout
						coord = { 37.4, 74.6, MAP.SHENDRALAS },
					}),
					objective(2, {	-- 0/6 Outcast Marauder slain
						provider = { "n", 254284 },	-- Outcast Marauder
						coord = { 29.6, 72.6, MAP.SHENDRALAS },
					}),
					objective(3, {	-- 0/8 Outcast Necromancer slain
						provider = { "n", 11559 },	-- Outcast Necromancer
						coord = { 22.6, 26.2, MAP.SHENDRALAS },
					}),
				},
			}),
			q(99258, {	-- Mana Mania
				qg = 255486,	-- Historian Biraxas
				qi = 286648,	-- Depleted Crystal Heart (PQI!)
				coord = { 45.8, 78.2, MAP.SHENDRALAS },
				lvl = 35,
				groups = {
					objective(1, {	-- 0/1 Nascent Pylon Protector slain
						provider = { "n", 276401 },	-- Nascent Pylon Protector
						coord = { 37.6, 52.8, MAP.SHENDRALAS },
					}),
				},
			}),
			q(93394, {	-- Meeting the Magister
				qg = 253471,	-- Mordent Evenshade
				coord = { 35.0, 46.5, MAP.SHENDRALAS },
				lvl = 35,
			}),
			q(92844, {	-- Mountain of Bones
				sourceQuest = 92841,	-- Valley of Bones (Magram)
				qg = 253136,	-- Orgrul
				coord = { 35.6, 12.0, MAP.SHENDRALAS },
				minReputation = { FACTION_MAGRAM_CLAN_CENTAUR, HONORED },
				races = ALLIANCE_ONLY,
				lvl = 35,
				groups = {
					objective(1, {	-- 0/426 Gently Cursed Bone
						provider = { "i", 254663 },	-- Gently Cursed Bone
						crs = {
							11561,	-- Undead Ravager
						},
					}),
				},
			}),
			q(92893, {	-- No Mercy for the Weak
				sourceQuest = 92873,	-- Proof of Concept
				qg = 253136,	-- Orgrul
				coord = { 35.6, 12.0, MAP.SHENDRALAS },
				minReputation = { FACTION_MAGRAM_CLAN_CENTAUR, HONORED },
				races = ALLIANCE_ONLY,
				lvl = 35,
				groups = {
					objective(1, {	-- 0/5 Gelkis Captive slain
						provider = { "n", 253431 },	-- Gelkis Captive
						coord = { 45.4, 30.2, MAP.SHENDRALAS },
					}),
				},
			}),
			q(93606, {	-- Not on Squealing Terms
				qg = 253527,	-- Kog'thug the Brave <Nomadic Bristleback Chief>
				coord = { 72.6, 31.4, MAP.SHENDRALAS },
				qi = 260237,	-- Virulent Blood of Agamaggan (PQI!)
				lvl = 35,
				groups = {
					objective(1, {	-- 0/1 Benevolent Bouquet
						provider = { "i", 260244 },	-- Benevolent Bouquet
					}),
					objective(2, {	-- 0/5 Vibrant Flower
						providers = {
							{ "i", 260245 },	-- Vibrant Flower
							{ "o", 649374 },	-- Vibrant Flower
						},
						coord = { 63.5, 74.6, MAP.SHENDRALAS },
						crs = {
							254566,	-- Rowdy Rose
							254567,	-- Terrible Tulip
						},
					}),
					i(260247),	-- Forlorn Necklace (QS!)
					i(271618),	-- Rejected Roses
				},
			}),
			q(92846, {	-- Outcast Necromancers
				sourceQuest = 92841,	-- Valley of Bones (Magram)
				qg = 253136,	-- Orgrul
				coord = { 35.6, 12.0, MAP.SHENDRALAS },
				minReputation = { FACTION_MAGRAM_CLAN_CENTAUR, HONORED },
				races = ALLIANCE_ONLY,
				lvl = 35,
				groups = {
					objective(1, {	-- 0/6 Outcast Necromancer slain
						provider = { "n", 11559 },	-- Outcast Necromancer
						coord = { 22.6, 26.2, MAP.SHENDRALAS },
					}),
				},
			}),
			q(93037, {	-- Outing Outcasts
				sourceQuest = 93034,	-- Valley of Bones (Gelkis)
				qg = 253177,	-- Nerlokh
				coords = {
					{ 58.4, 88.6, MAP.DESOLACE },
					{ 20.8, 22.6, MAP.SHENDRALAS },
				},
				minReputation = { FACTION_GELKIS_CLAN_CENTAUR, HONORED },
				lvl = 35,
				groups = {
					objective(1, {	-- 0/1 Necromantic Garb
						provider = { "i", 255875 },	-- Necromantic Garb
						cr = 11559,	-- Outcast Necromancer
						coord = { 22.6, 26.2, MAP.SHENDRALAS },
					}),
				},
			}),
			q(93568, {	-- Partially Digested Collar
				qs = 259461,	-- Partially Digested Collar (QS!)
				lvl = 35,
			}),
			q(93601, {	-- Passing the Blame
				sourceQuest = 93404,	-- Rot and Regret
				qg = 254674,	-- Woodwyrd
				coord = { 69.4, 71.8, MAP.SHENDRALAS },
				lvl = 35,
			}),
			q(93450, {	-- Phantasmal Problems
				qg = 254717,	-- Vindael
				coord = { 42.0, 78.8, MAP.SHENDRALAS },
				qi = 258734,	-- Unfinished Masterwork Sword (PQI!)
				lvl = 35,
				groups = {
					objective(1, {	-- 0/1 Phantasmal Blade
						provider = { "i", 258735 },	-- Phantasmal Blade
						-- TODO: Wowhead doesn't say yet how the sword is ushered into the spirit realm.
					}),
				},
			}),
			q(93451, {	-- Phantasmal Problems
				-- TODO: Wowhead doesn't list the quest giver yet. Wowhead's series lists it as an alternative to the other Phantasmal Problems (93450).
				lvl = 35,
				groups = {
					objective(1, {	-- 0/1 Phantasmal Blade
						provider = { "i", 258735 },	-- Phantasmal Blade
					}),
				},
			}),
			q(96018, {	-- Powering the Pylons
				qg = 253471,	-- Mordent Evenshade
				qi = 271882,	-- Pile of Pylon Parts (PQI!)
				coord = { 35.0, 46.5, MAP.SHENDRALAS },
				lvl = 35,
				groups = {
					objective(1, {	-- 0/1 Mana Sieve
						provider = { "i", 255662 },	-- Mana Sieve
					}),
					objective(4, {	-- 0/1 Coalesced Mana Crystal
						provider = { "i", 255667 },	-- Coalesced Mana Crystal
					}),
				},
			}),
			q(92873, {	-- Proof of Concept
				sourceQuest = 92847,	-- Corrupting Tears
				qg = 253136,	-- Orgrul
				coord = { 35.6, 12.0, MAP.SHENDRALAS },
				minReputation = { FACTION_MAGRAM_CLAN_CENTAUR, HONORED },
				races = ALLIANCE_ONLY,
				lvl = 35,
				groups = {
					objective(1, {	-- 0/426 Well Cursed Bone
						providers = {
							{ "i", 254842 },	-- Well Cursed Bone
							{ "i", 254870 },	-- Rudimentary Necromancy Staff
						},
						cr = 253360,	-- Nascent Undead Ravager
					}),
					i(271796),	-- Blade of the Magram Clan
					i(271797),	-- Staff of Revelations
					i(271798),	-- Desperate Barrier
				},
			}),
			q(93035, {	-- Ravaging Ravagers
				sourceQuest = 93034,	-- Valley of Bones (Gelkis)
				qg = 253177,	-- Nerlokh
				coords = {
					{ 58.4, 88.6, MAP.DESOLACE },
					{ 20.8, 22.6, MAP.SHENDRALAS },
				},
				minReputation = { FACTION_GELKIS_CLAN_CENTAUR, HONORED },
				lvl = 35,
				groups = {
					objective(1, {	-- 0/6 Undead Ravager slain
						provider = { "n", 11561 },	-- Undead Ravager
						coord = { 36.0, 23.7, MAP.SHENDRALAS },
					}),
				},
			}),
			q(93188, {	-- Return to Orgrul
				sourceQuests = {
					93072,	-- Long-Term Solutions
					93129,	-- Threat of Starvation
				},
				qg = 253851,	-- Hagiak
				coord = { 59.2, 54.0, MAP.SHENDRALAS },
				timeline = { TIMELINE.ADDED_1_60_1 },
				minReputation = { FACTION_MAGRAM_CLAN_CENTAUR, HONORED },
				lvl = 35,
			}),
			q(93058, {	-- Saving Our Own
				qg = 253177,	-- Nerlokh
				coord = { 20.8, 22.3, MAP.SHENDRALAS },
				minReputation = { FACTION_GELKIS_CLAN_CENTAUR, HONORED },
				lvl = 35,
				groups = {
					objective(1, {	-- 0/5 Gelkis Captive rescued
						provider = { "n", 254825 },	-- Gelkis Captive
					}),
				},
			}),
			q(93546, {	-- Spectral Iron Ore
				sourceQuests = {
					93450,	-- Phantasmal Problems
					93451,	-- Phantasmal Problems
				},
				sourceQuestNumRequired = 1,
				qg = 254717,	-- Vindael
				coord = { 42.0, 78.8, MAP.SHENDRALAS },
				qi = 259229,	-- Vindael's Spectral Pickaxe (PQI!)
				lvl = 35,
				groups = {
					objective(1, {	-- 0/10 Spectral Iron Ore
						provider = { "i", 259226 },	-- Spectral Iron Ore
						-- TODO: Mined from Spectral Iron Deposits around Shen'dralas; Wowhead doesn't list the object yet.
					}),
				},
			}),
			q(92914, {	-- Strange Pylons
				provider = { "o", 577959 },	-- Shen'dralar Pylon
				coord = { 43.5, 34.1, MAP.SHENDRALAS },
				lvl = 35,
			}),
			q(93644, {	-- Tattered Journal
				qs = 260347,	-- Tattered Journal (QS!)
				lvl = 35,
			}),
			q(96060, {	-- Tempered Expectations
				sourceQuest = 93546,	-- Spectral Iron Ore
				qg = 254717,	-- Vindael
				coord = { 42.0, 78.8, MAP.SHENDRALAS },
				qi = 271992,	-- Phantasmal Blade (PQI!)
				lvl = 35,
				groups = {
					objective(1, {	-- 0/8 Shen'dralas wildlife slain with the blade
						crs = {
							263681,	-- Bear
							255174,	-- Blind Screecher
							255207,	-- Prowler
						},
					}),
					i(272179),	-- Greatsword of Great Pasts
					i(272181),	-- Phantasmal Shiv
					i(272180),	-- Spectral Magister's Commission
				},
			}),
			q(93129, {	-- Threat of Starvation
				sourceQuest = 93066,	-- Bristleback Retreat
				qg = 253851,	-- Hagiak
				coord = { 59.2, 54.0, MAP.SHENDRALAS },
				timeline = { TIMELINE.ADDED_1_60_1 },
				minReputation = { FACTION_MAGRAM_CLAN_CENTAUR, HONORED },
				lvl = 35,
				groups = {
					objective(1, {	-- 0/6 Stolen Supplies
						provider = { "i", 256892 },	-- Stolen Supplies
					}),
				},
			}),
			q(93034, {	-- Valley of Bones (Gelkis)
				sourceQuest = 1373,	-- Ongeku
				qg = 5397,	-- Uthek the Wise
				coord = { 36.2, 79.2, MAP.DESOLACE },
				minReputation = { FACTION_GELKIS_CLAN_CENTAUR, HONORED },
				lvl = 35,
			}),
			q(92841, {	-- Valley of Bones (Magram)
				sourceQuest = 92743,	-- A Conqueror's Crown
				qg = 5398,	-- Warug
				coord = { 74.8, 68.0, MAP.DESOLACE },
				minReputation = { FACTION_MAGRAM_CLAN_CENTAUR, HONORED },
				races = ALLIANCE_ONLY,
				lvl = 35,
			}),
			q(93362, {	-- What They've Done to My Peonies
				sourceQuest = 93341,	-- Forlorn Gardens
				qg = 254578,	-- Mithera
				coord = { 53.0, 75.8, MAP.SHENDRALAS },
				lvl = 35,
				groups = {
					objective(1, {	-- 0/4 Rowdy Rose slain
						provider = { "n", 254566 },	-- Rowdy Rose
					}),
					objective(2, {	-- 0/4 Terrible Tulip slain
						provider = { "n", 254567 },	-- Terrible Tulip
					}),
					objective(3, {	-- 0/20 Malevolent Marigold slain
						provider = { "n", 254572 },	-- Malevolent Marigold
					}),
				},
			}),
			q(93594, {	-- Word of the Woods
				sourceQuest = 93341,	-- Forlorn Gardens
				qg = 254578,	-- Mithera
				coord = { 53.0, 75.8, MAP.SHENDRALAS },
				lvl = 35,
			}),
		}),
		n(ZONE_DROPS, {
			i(259893, {	-- Corpsefeeder's Carapace (QS!)
				cr = 253394,	-- Corpsefeeder
			}),
			i(259461, {	-- Partially Digested Collar (QS!)
				cr = 255207,	-- Prowler
			}),
			i(260347, {	-- Tattered Journal (QS!)
				crs = {
					253272,	-- Magram Necromancer
					11559,	-- Outcast Necromancer
				},
			}),
		}),
	},
});
root(ROOTS.HiddenQuestTriggers, {
	q(93653, {	-- TODO: unknown trigger; completed at 47.3, 67.4 in Shen'dralas (Contributor Report)
		timeline = { TIMELINE.ADDED_1_60_1 },
	}),
	q(93656, {	-- Completed together with Powering the Pylons (96018)
		timeline = { TIMELINE.ADDED_1_60_1 },
	}),
});
