-----------------------------------------------------
--  D U N G E O N S  &  R A I D S  M O D U L E    --
-----------------------------------------------------
instanceroot(78789, {	-- Hyjal Summit
	--lore = "",
	icon = 409547,
	--zoneTextAreaID = ,	-- Hyjal Summit
	--coord = { , MAP.MOUNT_HYJAL },
	timeline = { TIMELINE.ADDED_1_60_1 },
	isRaid = true,
	lvl = 60,
	groups = {
		n(ACHIEVEMENTS, {
			ach(62034),	-- Conqueror of the Wilds
		}),
		n(QUESTS, {

		}),
		--[[
		e(, {	--
			creatureID = ,	--
			groups = {
				--i(),	--
			},
		}),
		]]--
	},
});
