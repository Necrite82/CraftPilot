-- Map Constants
local mapMetatable = {
	--- Resolves and caches a legacy global map value; an unknown name raises an error.
	---@param t table # Map table being indexed.
	---@param mapKey string|number # Missing map key.
	---@return any # Existing truthy global value; unknown map names do not return normally.
	__index = function(t, mapKey)
		local globalMapID = _G[mapKey];
		if globalMapID then
			print("Non-MAP. prefixed map referenced for " .. mapKey .. ". Consider adding it to the MAP namespace.");
			t[mapKey] = globalMapID;
			return globalMapID;
		end
		error("Unknown map key MAP." .. mapKey .. ". You done messed up, A-aron!");
	end
};
local _MAP = setmetatable({
	-- Roots
	AZEROTH = 947;
	COSMIC = 947;

	-- Battlegrounds
	ALTERAC_VALLEY = 1459;
	ARATHI_BASIN = 1461;
	WARSONG_GULCH = 1460;
	DARKSPEAR_ISLANDS = 2524;

	-- Raids (Classic)
	BLACKWING_LAIR = 287;
	MOLTEN_CORE = 232;
	NAXXRAMAS = 162;
	ONYXIAS_LAIR = 248;
	RUINS_OF_AHNQIRAJ = 247;
	TEMPLE_OF_AHNQIRAJ = 320;
	ZULGURUB = 337;

	-- Dungeons (Classic)
	BLACKFATHOM_DEEPS = 221;
	BLACKROCK_DEPTHS = 242;
	BLACKROCK_SPIRE = 250;
	DEADMINES = 291;
	DIRE_MAUL = 234;
	DIRE_MAUL_WARPWOOD_QUARTER = 239;		-- Warpwood Quarter (main)
	DIRE_MAUL_GORDOK_COMMONS = 235;			-- Gordok Commons (main)
	DIRE_MAUL_CAPITAL_GARDENS = 236;		-- Capital Gardens (main)
	DIRE_MAUL_COURT_OF_THE_HIGHBORNE = 237;	-- Court of the Highborne
	DIRE_MAUL_PRISON_OF_IMMOLTHAR = 238;	-- Prison of Immol'Thar
	GNOMEREGAN = 226;
	MARAUDON = 280;
	RAGEFIRE_CHASM = 213;
	RAZORFEN_DOWNS = 300;
	RAZORFEN_KRAUL = 301;
	SCARLET_MONASTERY = 435;
	SCHOLOMANCE = 476;
	SHADOWFANG_KEEP = 310;
	STRATHOLME = 317;
	SUNKEN_TEMPLE = 220;
	THE_STOCKADE = 225;
	ULDAMAN = 230;
	ULDAMAN_OUTDOORS = 16;
	WAILING_CAVERNS = 279;
	ZULFARRAK = 219;

	-- Kalimdor
	KALIMDOR = 1414;
	ASHENVALE = 1440;
	AZSHARA = 1447;
	DARKSHORE = 1439;
	DARNASSUS = 1457;
	DESOLACE = 1443;
	DUROTAR = 1411;
	DUSTWALLOW_MARSH = 1445;
	FELWOOD = 1448;
	FERALAS = 1444;
	MOONGLADE = 1450;
	MULGORE = 1412;
	ORGRIMMAR = 1454;
	SILITHUS = 1451;
	STONETALON_MOUNTAINS = 1442;
	TANARIS = 1446;
	TELDRASSIL = 1438;
	THE_BARRENS = 1413;
	THOUSAND_NEEDLES = 1441;
	THUNDER_BLUFF = 1456;
	UNGORO_CRATER = 1449;
	WINTERSPRING = 1452;

	-- Eastern Kingdoms
	EASTERN_KINGDOMS = 1415;
	ALTERAC_MOUNTAINS = 1416;
	ARATHI_HIGHLANDS = 1417;
	BADLANDS = 1418;
	BLACKROCK_MOUNTAIN = 33;
	BLACKROCK_MOUNTAIN_LEVEL3 = 35;
	BLASTED_LANDS = 1419;
	BURNING_STEPPES = 1428;
	DEADWIND_PASS = 1430;
	DUN_MOROGH = 1426;
		COLDRIDGE_VALLEY = 427;
	DUSKWOOD = 1431;
	EASTERN_PLAGUELANDS = 1423;
	ELWYNN_FOREST = 1429;
		NORTHSHIRE_VALLEY = 425;
	HILLSBRAD_FOOTHILLS = 1424;
	IRONFORGE = 1455;
	LOCH_MODAN = 1432;
	REDRIDGE_MOUNTAINS = 1433;
	SEARING_GORGE = 1427;
	SILVERPINE_FOREST = 1421;
	STORMWIND_CITY = 1453;
	STRANGLETHORN_VALE = 1434;
	SWAMP_OF_SORROWS = 1435;
	THE_HINTERLANDS = 1425;
	TIRISFAL_GLADES = 1420;
	UNDERCITY = 1458;
	WESTERN_PLAGUELANDS = 1422;
	WESTFALL = 1436;
	WETLANDS = 1437;

	-- Forever
	ZEPHRAS_ISLE = 2521;
	MOUNT_HYJAL	= 2482;
	RIVERGLADES = 2548;
	SHENDRALAS = 2652;
}, mapMetatable);

-- Temporary solution forces the map globals to exist. Also apply to the MAP constant from shared
for mapConst, mapID in pairs(_MAP) do
	_G[mapConst] = mapID;
	MAP[mapConst] = mapID;
end
