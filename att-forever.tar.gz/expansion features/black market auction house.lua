-------------------------------------------------------------------
--     B L A C K   M A R K E T   A U C T I O N   H O U S E       --
-------------------------------------------------------------------
local BLACK_MARKET_AUCTION_HOUSE = createHeader({
	readable = "Black Market Auction House",
	icon = [[~_.asset("Category_Blackmarket")]],
	constant = "BLACK_MARKET_AUCTION_HOUSE",
	text = {
		en = [[~BLACK_MARKET_AUCTION_HOUSE]],
	},
	description = {
		en = "Instead of buying items from other players like the regular Auction House, items on the Black Market are generated and listed by NPCs. The items are listed for one day only. The items for sale vary from items that were difficulty to acquire to TCG items that have no other source. All items are listed infrequently, so it should not be seen as a reliable way to farm rarities.",
		-- TODO: de = "",
		-- TODO: es = "",
		-- TODO: mx = "",
		-- TODO: fr = "",
		-- TODO: it = "",
		-- TODO: ko = "",
		-- TODO: pt = "",
		-- TODO: ru = "",
		cn = "与普通拍卖行从其他玩家处购买物品不同，黑市中的物品由 NPC 生成并上架。物品仅上架一天。售卖物品涵盖难以获取的装备以及无其他获取途径的 TCG 卡牌物品。所有物品上架频率低，因此不应将其视作稳定刷取稀有物品的方式。",
		tw = "與一般拍賣場向其他玩家購買物品不同，黑市拍賣場的商品由 NPC 產生並上架，而且只會上架一天。販售內容包含難以取得的物品，以及沒有其他來源的 TCG 物品。商品上架頻率很低，因此不應將黑市拍賣場視為穩定取得稀有物品的管道。",	-- TODO: verify it.
	},
});
root(ROOTS.ExpansionFeatures, {
	n(BLACK_MARKET_AUCTION_HOUSE, {
		timeline = { TIMELINE.ADDED_1_60_1 },
		symselector=SymSelector.BMAH,
		u = BLACK_MARKET,
		groups = {
			n(ARMOR, {
				---- DUNGEON SET 1 ----
				-- Hunter
				i(16674),	-- Beaststalker's Tunic
				-- Mage
				i(16686),	-- Magister's Crown
				i(16688),	-- Magister's Robes
				-- Rogue
				i(16709),	-- Shadowcraft Pants
				-- Shaman
				i(16670),	-- Boots of Elements
				-- Warrior
				i(16733),	-- Spaulders of Valor
				-- Warlock
				i(16701),	-- Dreadmist Mantle
			}),
			filter(BATTLE_PETS, {
				i(11903),	-- Cat Carrier (Corrupted Kitten) (PET!)
				i(249897),	-- Flowery Lashling Bud
				i(249895),	-- Frosty Lashling Bud (PET!)
				i(23713),	-- Hippogryph Hatchling
				i(13342),	-- Pet Fish
				i(11474),	-- Sprite Darter Egg
				i(268503),	-- Tiny Azure Whelpling (PET!)
				i(268502),	-- Tiny Bronze Whelpling (PET!)
				i(249896),	-- Viridian Lashling Bud (PET!)
				i(249898),	-- Wilted Lashling Bud
			}),
			--[[
			filter(MOUNTS, {

			}),
			filter(SHIRTS, {

			}),
			]]--
			filter(TABARDS, {
				i(23705),	-- Tabard of Flame
			}),
			filter(TOYS, {
				i(23716),	-- Carved Ogre Idol
			}),
		},
	}),
});
