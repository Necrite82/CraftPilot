local i = GetRecipeHelperForProfession(FIRST_AID);
---------------
-- FIRST AID --
---------------
--- TRAINER ---
i(0, 3273);			-- First Aid (Apprentice)
i(0, 3274);			-- First Aid (Journeyman)
i(0, 3275);			-- Linen Bandage
i(0, 3276);			-- Heavy Linen Bandage
i(0, 1244431);		-- Minor Healing Potion
i(0, 7934);			-- Anti-Venom
i(0, 3277);			-- Wool Bandage
i(0, 1244432);		-- Lesser Healing Potion
i(0, 1259342);		-- Simple Poultice
i(0, 3278);			-- Heavy Wool Bandage
i(0, 1259347);		-- Woolen Tourniquet
i(0, 1244433);		-- Healing Potion
i(0, 7928);			-- Silk Bandage
i(0, 10841);		-- Heavy Mageweave Bandage
i(0, 18629);		-- Runecloth Bandage
i(0, 18630);		-- Heavy Runecloth Bandage
--- QUEST ---
i(0, 10846);		-- First Aid (Artisan)
i(0, 1230117);		-- First Aid Kit
--- ITEM ---
i(16084, 7924);		-- First Aid (Expert)
i(255731, 1259345);	-- Powerful Poultice
i(6454, 7935);		-- Strong Anti-Venom
i(273105, 1262996);	-- Toxin Study
i(16112, 7929);		-- Heavy Silk Bandage
i(255723, 1244434);	-- Greater Healing Potion
i(255724, 1259343);	-- Clever Poultice
i(16113, 10840);	-- Mageweave Bandage
i(255727, 1259344);	-- Superior Poultice
i(255728, 1259341);	-- Potent Anti-Venom
i(255729, 1244436);	-- Major Healing Potion
i(255726, 1259348);	-- Leather Tourniquet
i(255725, 1244435);	-- Superior Healing Potion
i(255730, 1259349);	-- Surgical Tourniquet
i(273118, 1263001);	-- Plague Doctor's Laboratory
i(19442, 23787);	-- Powerful Anti-Venom
--- UNKNOWN ---
--[[
--- UNRELEASED CONTENT ---
--]]
