local _,CP=...
local L=CP.L
function CP:PlanPageCards(key,page)
  if page=="leftovers" then return self:LeftoverCards(key) end
  if page=="projects" then return self.ProjectCards and self:ProjectCards(key) or {} end
  local plan=self:PlanFor(key);local route=self:AutoRouteShopping(key)
  if self:RouteBuildPending(key) then return {{title=L("Route wird berechnet"),detail=L("Skillfarben, Folgebedarf und Einkauf werden verglichen. Das Spiel bleibt bedienbar."),footer=L("Anklicken: Berechnung abbrechen"),color="blue",action=function() CP:CancelRouteBuild(key);CP:Render() end}} end
  local c=self:CostCalculation("plan",key)
  if page=="details" then
    local cards={self:CostSummaryCard("plan",key),self:PlanReviewCard(key),{title=L("Vorräte und Preise"),detail=self:BankStatus(),footer=L("Scanpreise und Skillfarben sind Schätzungen. Ausbildungsränge und Wege ggf. zusätzlich."),color="blue"}}
    if c.stale>0 or c.unknownAge>0 then cards[#cards+1]={title=L("Preiswarnungen"),detail=c.stale..L(" veraltet · ")..c.unknownAge..L(" mit unbekanntem Scan-Alter"),footer=L("Vor Einkäufen Auctionator erneut scannen; Preise variieren."),color="gold"} end
    if route and route.ignoredPreferences and route.ignoredPreferences>0 then cards[#cards+1]={title=L("Nicht passende Vorgaben übersprungen"),detail=L("Für inzwischen ungeeignete Rezepte wurde wieder eine gültige Alternative vorgeschlagen."),color="gold"} end
    if next(plan.preferences or {}) or next(plan.materialPreferences or {}) then cards[#cards+1]={title=L("Alle eigenen Vorgaben zurücksetzen"),detail=L("Wieder automatisch Rezepte und Zwischenprodukte vorschlagen."),action=function() plan.preferences=nil;plan.materialPreferences=nil;CP:RequestRouteBuild(key);CP:Render() end,color="gold"} end
    cards[#cards+1]={title=L("Priorität der Vorräte ändern"),detail=L("Bestände zwischen Berufs- und Campingplänen aufteilen."),action=function() CP:OpenTab("reservations") end,color="blue"}
    -- Price age along the plan: one targeted scan instead of a full one.
    local items={}
    for _,m in ipairs(c.materials) do if (m.missing or 0)>0 then items[#items+1]=m.id end end
    if #items>0 then
      local p=self:PriceSummary(items)
      local doubtful=p.stale+p.unknown+p.missing
      cards[#cards+1]={title=doubtful>0 and string.format(L("Preise prüfen · %d von %d unsicher"),doubtful,p.items) or L("Preise aktuell"),
        detail=doubtful>0 and string.format(L("%d älter als 3 Tage · %d ohne Datum · %d ohne Preis"),p.stale,p.unknown,p.missing) or L("Alle Zukäufe haben einen Scan der letzten 3 Tage."),
        footer=L("Klick am Auktionshaus: Auctionator scannt genau diese Materialien"),color=doubtful>0 and "gold" or "green",
        action=function()
          if not CP:AuctionHouseOpen() then CP:Say(L("Am Auktionshaus scannt Auctionator genau diese Materialien neu."));return end
          local list={};for _,id in ipairs(items) do list[#list+1]={id=id,quantity=1} end
          CP:SearchItems(list,L("Preise"),L("Auctionator scannt die Materialien deines Plans."))
        end}
    end
    for _,card in ipairs(self:RouteCompareCards(key,plan.start,plan.target)) do cards[#cards+1]=card end
    for _,card in ipairs(self:SecondProfessionCards(key)) do cards[#cards+1]=card end
    for _,card in ipairs(self:BuyTimingCards(key)) do cards[#cards+1]=card end
    for _,card in ipairs(self:BudgetCards(key)) do cards[#cards+1]=card end
    cards[#cards+1]={sectionHeader=true,title=L("PLAN TEILEN")}
    cards[#cards+1]={title=L("Plan als Text teilen"),detail=L("Rezepte und Mengen als kurzer Text, z. B. für Gildenmitglieder, die für dich sammeln."),footer=L("Klick: Text anzeigen"),color="blue",
      action=function() CP:OpenShareWindow(key,"export") end}
    cards[#cards+1]={title=L("Plan importieren"),detail=L("Text eines anderen CraftPilot einfügen; ersetzt deinen Plan für diesen Beruf."),footer=L("Klick: Text einfügen"),color="blue",
      action=function() CP:OpenShareWindow(key,"import") end}
    return cards
  end
  local cards={}
  -- Skill points beyond the current cap need the next rank; warn before anything is bought for them.
  local gate=self.RankGateWarning and self:RankGateWarning(key,plan.target)
  if gate then cards[#cards+1]={title=L("Achtung: nächster Rang noch nicht lernbar"),detail=gate.text.."\n"..string.format(L("Der Plan geht bis %d, deine Ausbildung endet bei %d."),plan.target,(self.db.professions[key] or {}).cap or 0),color="red"} end
  if self:PlanNeedsReview(key) then cards[#cards+1]=self:PlanReviewCard(key) end
  if route and route.plannerVersion~=3 then cards[#cards+1]={title=L("Gespeicherte Route aktualisieren"),detail=L("Oben Plan erstellen wählen, um Lernkosten und neue Routenvorgaben vollständig neu zu berechnen."),color="gold"} end
  if route and route.blocked then cards[#cards+1]={title=L("Route unvollständig"),detail=string.format(L("Berechnet bis %d statt %d · Rezeptdaten oder Bereich prüfen."),route.reached,route.target).."\n"..L("Auch die erlaubten Skillfarben und Punktgrenzen in den Einstellungen prüfen."),color="gold"} end
  if page=="crafts" then
    if route and route.forwardPlan and route.forwardPlan.enabled then
      local f=route.forwardPlan
      cards[#cards+1]={title=L("Vorausschau für diesen Skillbereich"),detail=f.missingPrices and L("Fehlende Preise verhindern einen verlässlichen Vergleich der Folgeschritte.") or string.format(L("Ersparnis zum direkten Weg: %s · %d zusätzliche Herstellungen vermieden"),self:FormatCostMoney(f.saved or 0),math.max(0,f.craftsSaved or 0)),footer=L("Folgebedarf wird nur innerhalb des gewählten Bereichs verglichen; kein garantiertes globales Optimum."),color="blue"}
    end
    local rows={}
    if route then
      local roots={}
      for _,s in ipairs(route.steps) do roots[s.id]=true;rows[#rows+1]={id=s.id,quantity=s.crafts,first=s.first,last=s.last,name=s.name,preferred=s.preferred,forward=s.forward,automatic=true} end
      for _,s in ipairs(route.intermediates or {}) do if not roots[s.id] then rows[#rows+1]={id=s.id,key=s.key,quantity=s.count,first=s.skill,last=s.skill and s.skill+1,name=s.name,automatic=true,materialID=s.output,units=s.units,intermediate=true} end end
    else
      for _,s in ipairs(self:PlanShopping(key).steps) do rows[#rows+1]={id=s.id,quantity=s.quantity,name=s.name} end
    end
    if #rows==0 then return {{title=L("Noch keine Herstellungen geplant"),detail=L("Oben einen Bereich planen oder in Jetzt skillen ein Rezept wählen und hier hinzufügen."),color="blue"}} end
    if route and ((route.preferencesApplied or 0)>0 or next(plan.materialPreferences or {})) then
      local reference=route.automaticReference
      cards[#cards+1]={title=L("Deine Rezeptwahl · Rest der Route neu berechnet"),
        detail=reference and reference.complete and c.cashComplete and not self:PlanNeedsReview(key) and (L("Mehr-/Minderkosten zum automatischen Vorschlag: ")..self:FormatCostMoney(c.cash-reference.cash)) or L("Preisvergleich unvollständig · Details prüfen"),
        footer=L("Empfehlung bleibt eine Schätzung, kein garantiertes globales Optimum."),color="gold"}
    end
    cards[#cards+1]={productionRows=rows,recipeKey=key}
    for _,card in ipairs(self:KeepCards(key)) do cards[#cards+1]=card end
    return cards
  end
  if not route and not next(plan.crafts) then return {{title=L("1. Bereich wählen · 2. Plan erstellen · 3. Einkaufen"),
    detail=L("Die Route und alle fehlenden Zutaten werden für den gewählten Skillbereich berechnet."),footer=L("Unter Herstellen kannst du die Rezeptschritte anschließend austauschen."),color="blue"}} end
  local rows,missingRows={},{}
  for _,m in ipairs(c.materials) do
    if m.missing>0 then missingRows[#missingRows+1]=m end
    if m.missing>0 or m.fromBank>0 or m.alts>0 then
      m.showPickup=true
      rows[#rows+1]=m
    end
  end
  if #rows==0 then cards[#cards+1]={title=L("Alles für diesen Plan vorhanden"),detail=L("Keine zusätzlichen Materialkäufe erkannt. Unbekannte Angaben unter Details beachten."),color="green"}
  else cards[#cards+1]={materialTable=rows} end
  if not c.cashComplete then cards[#cards+1]={title=L("Kalkulation unvollständig"),detail=L("Fehlende Preise oder Rezeptangaben unter Details prüfen."),color="gold"} end
  if self.FarmCards and #missingRows>0 then
    local priced={}
    for _,m in ipairs(missingRows) do local p=self:PriceDetails(m.id).price;priced[#priced+1]={id=m.id,missing=m.missing,cost=p and p*m.missing} end
    for _,card in ipairs(self:FarmCards(priced)) do cards[#cards+1]=card end
    local ids={};for _,m in ipairs(missingRows) do ids[#ids+1]=m.id end
    for _,card in ipairs(self:PriceLimitCards(key,ids)) do cards[#cards+1]=card end
  end
  return cards
end
function CP:DrawProductionTable(parent,rows,key,width)
  parent.productionRows=rawget(parent,"productionRows") or {};parent.productionHeaders=rawget(parent,"productionHeaders") or {}
  local cols={{L("Rezept"),.43},{L("Skill"),.15},{L("Menge"),.12},{L("Status"),.19},{"",.11}}
  local x=8
  for i,c in ipairs(cols) do local t=parent.productionHeaders[i] or self:DisplayLabel(parent,"GameFontNormalSmall",0,0,50,"");parent.productionHeaders[i]=t;t:ClearAllPoints();t:SetPoint("TOPLEFT",parent,"TOPLEFT",x,-4);t:SetWidth(width*c[2]-8);t:SetText(c[1]);t:Show();x=x+width*c[2] end
  for _,r in ipairs(parent.productionRows) do r:Hide() end
  local y=28
  for i,row in ipairs(rows) do
    local r=parent.productionRows[i]
    if not r then r=self:CreateFlatAction(parent,width,52,function() end);r.cells={};r.edit=CreateFrame("Button",nil,r,"BackdropTemplate");self:StyleActionButton(r.edit);r.edit:SetSize(68,24);r.edit:SetPoint("RIGHT",r,"RIGHT",-6,0);parent.productionRows[i]=r end
    local recipeKey=row.key or key
    local native=(self.db.recipes[recipeKey] or {})[row.id]
    local values={row.name,row.intermediate and L("Zwischenprodukt") or (row.first and (row.first.."–"..row.last) or "—"),tostring(row.quantity),row.preferred and L("Deine Wahl") or (row.forward and L("Folgebedarf") or (native and native.learned and L("Erlernt") or L("Noch lernen")))}
    x=8
    for j=1,4 do local t=r.cells[j] or self:DisplayLabel(r,"GameFontHighlightSmall",0,0,50,"");r.cells[j]=t;t:ClearAllPoints();t:SetPoint("TOPLEFT",r,"TOPLEFT",x,-12);t:SetWidth(width*cols[j][2]-8);t:SetText(values[j]);x=x+width*cols[j][2] end
    local measured=r.cells[1]:GetStringHeight();local h=math.max(52,(type(measured)=="number" and measured or 16)+24)
    r:ClearAllPoints();r:SetPoint("TOPLEFT",parent,"TOPLEFT",0,-y);r:SetSize(width,h);r:Show()
    local record=row
    r:SetScript("OnClick",function() if native and native.learned then CP:OpenLearnedRecipe(recipeKey,record.id) else CP:OpenCostCalculation("recipe",recipeKey,record.id,record.quantity) end end)
    r:SetScript("OnEnter",function() CP:ShowCraftTooltip(r,recipeKey,record.id) end);r:SetScript("OnLeave",function() if GameTooltip then GameTooltip:Hide() end end)
    r.edit:SetText(row.automatic and L("Ändern") or L("Entfernen"))
    r.edit:SetEnabled(not record.intermediate or record.materialID~=nil)
    r.edit:SetScript("OnClick",function() if record.automatic then CP:OpenRouteAlternatives(key,record.first,record.last,record.materialID,record.units) else CP:ClearPlanCraft(key,record.id);CP:Render() end end)
    y=y+h+4
  end
  parent:SetSize(width,y);return y
end
function CP:ChooseRouteRecipe(key,first,last,id)
  local p=self:PlanFor(key)
  local valid=id==nil
  for _,c in ipairs(self:CatalogCandidateRecipes(key,first)) do if c.id==id then valid=true end end
  if not valid then return false end
  local previous=p.preferences;local prefs={};for s,r in pairs(previous or {}) do prefs[s]=r end
  for s=math.max(p.start,first),math.min(p.target,last)-1 do prefs[s]=id end
  p.preferences=prefs
  local ok=self:RequestRouteBuild(key)
  if not ok then p.preferences=previous;return false end
  return true
end
function CP:ChooseMaterialRecipe(key,item,id,skill)
  local valid=id==nil or id==0
  for _,c in ipairs(self:RecipesMaking(item,key,skill)) do if c.id==id then valid=true end end
  if not valid then return false end
  local p=self:PlanFor(key);local old=p.materialPreferences;local prefs={};for k,v in pairs(old or {}) do prefs[k]=v end
  prefs[item]=id;p.materialPreferences=prefs
  if not self:RequestRouteBuild(key) then p.materialPreferences=old;return false end
  return true
end
function CP:OpenRouteAlternatives(key,first,last,materialItem,units)
  local f=self.routeChooser
  if not f then
    f=CreateFrame("Frame","CraftPilotProRouteChooser",UIParent,"BackdropTemplate");f:SetSize(780,590);f:SetPoint("CENTER");f:SetFrameStrata("DIALOG");f:SetClampedToScreen(true);f:EnableMouse(true)
    f:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8",edgeFile="Interface\\Buttons\\WHITE8X8",edgeSize=1});f:SetBackdropColor(.035,.055,.075,.99);f:SetBackdropBorderColor(.3,.45,.55,1)
    f.title=self:DisplayLabel(f,"GameFontNormalLarge",22,20,710,"")
    self:DisplayLabel(f,"GameFontDisableSmall",22,55,710,L("Rezept wählen: Der Rest der Route und der Einkauf werden neu berechnet. Preise für diesen Schritt sind nur eine Vorschau."))
    local scroll=CreateFrame("ScrollFrame",nil,f,"UIPanelScrollFrameTemplate");scroll:SetPoint("TOPLEFT",f,"TOPLEFT",22,-100);scroll:SetPoint("BOTTOMRIGHT",f,"BOTTOMRIGHT",-44,68)
    f.list=CreateFrame("Frame",nil,scroll);f.list:SetSize(710,100);scroll:SetScrollChild(f.list);f.rows={}
    f.reset=CreateFrame("Button",nil,f,"BackdropTemplate");self:StyleActionButton(f.reset);f.reset:SetSize(260,26);f.reset:SetPoint("BOTTOMLEFT",f,"BOTTOMLEFT",22,20);f.reset:SetText(L("Automatische Empfehlung verwenden"))
    local close=CreateFrame("Button",nil,f,"UIPanelCloseButton");close:SetPoint("TOPRIGHT",-5,-5);close:SetScript("OnClick",function() f:Hide() end)
    UISpecialFrames[#UISpecialFrames+1]="CraftPilotProRouteChooser";self.routeChooser=f
  end
  f.title:SetText(materialItem and (L("Zwischenprodukt: ")..self:ItemName(materialItem)) or string.format(L("Rezept für Skill %d–%d austauschen"),first,last))
  f.reset:SetScript("OnClick",function() if materialItem then CP:ChooseMaterialRecipe(key,materialItem,nil,first) else CP:ChooseRouteRecipe(key,first,last,nil) end;f:Hide();CP:Render() end)
  for _,r in ipairs(f.rows) do r:Hide() end
  local entries={}
  local candidates=materialItem and self:RecipesMaking(materialItem,key,first) or self:CatalogCandidateRecipes(key,first)
  for _,c in ipairs(candidates) do
    local recipeKey=c.key or key
    local count,reached=self:ExpectedCrafts(recipeKey,c.id,c.recipe,first,last)
    if materialItem then count=math.max(1,math.ceil((units or 1)/math.max(1,c.recipe.count or c.recipe.yield or 1)));reached=first end
    local req={};for id,n in pairs(c.recipe.mats or {}) do req[id]=n*count end
    local fee,unknown,age,auction,book=self:RecipeAcquisitionCost(recipeKey,c.id,key,first);if book then req[book]=(req[book] or 0)+1 end
    local estimate=self:CalculateMaterialCosts(req,fee,unknown,key)
    entries[#entries+1]={id=c.id,key=recipeKey,name=self:RecipeName(recipeKey,c.id,c.recipe.name),chance=c.chance,count=count,reached=reached,cost=estimate}
  end
  if materialItem then
    local p=self:PriceDetails(materialItem);local n=math.max(1,units or 1)
    entries[#entries+1]={id=0,key=key,name=L("Kaufen statt herstellen"),count=n,reached=first,cost={cash=(p.price or 0)*n,cashComplete=p.price~=nil}}
  end
  table.sort(entries,function(a,b) if a.cost.cashComplete~=b.cost.cashComplete then return a.cost.cashComplete end;if a.cost.cash~=b.cost.cash then return a.cost.cash<b.cost.cash end;return a.id<b.id end)
  for i,c in ipairs(entries) do
    local r=f.rows[i]
    if not r then r=self:CreateFlatAction(f.list,710,68,function() end);r.title=self:DisplayLabel(r,"GameFontHighlight",12,10,680,"");r.note=self:DisplayLabel(r,"GameFontDisableSmall",12,36,680,"");f.rows[i]=r end
    r:ClearAllPoints();r:SetPoint("TOPLEFT",f.list,"TOPLEFT",0,-(i-1)*72);r.title:SetText(c.name)
    r.note:SetText(c.id==0 and (c.count..L(" Stück · Zukauf: ")..self:DisplayMoney(c.cost.cash)..(c.cost.cashComplete and "" or " + ?")) or ((c.chance and (math.floor(c.chance*100).."% · ") or "")..c.count..L(" Herstellungen · Zukauf + Lernen: ")..self:DisplayMoney(c.cost.cash)..(c.cost.cashComplete and "" or " + ?")..L(" · Vorschau bis Skill ")..c.reached))
    local id=c.id;local candidateKey=c.key;r:SetScript("OnClick",function()
      local ok;if materialItem then ok=CP:ChooseMaterialRecipe(key,materialItem,id,first) else ok=CP:ChooseRouteRecipe(key,first,last,id) end
      if ok then f:Hide();CP:Render() end
    end)
    r:SetScript("OnEnter",function() CP:ShowCraftTooltip(r,candidateKey,id~=0 and id or nil,materialItem) end);r:SetScript("OnLeave",function() if GameTooltip then GameTooltip:Hide() end end);r:Show()
  end
  f.list:SetHeight(math.max(80,#entries*72));f:Show()
end
